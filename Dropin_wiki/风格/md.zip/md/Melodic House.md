#Melodic House
##基本信息
###发源时间：
###风格类型：House
##详情
Melodic House是一种House音乐子类型，具有令人陶醉、旋律优美、并有大量琶音器的声音。该类型与Melodic
Techno有着密切的联系，二者之间的差异主要体现在 house 和 techno 之间的差异。这两种流派都源自Progressive
House，而Melodic House也源于 2010 年代早期的Deep House场景，因此仍然更加以节拍为导向，保留了浩室结构。



Melodic House流派的节奏保持在 120 bpm 左右，以制作这种流派而闻名的Melodic House艺术家包括
Dixon、Solomun、Kidnap Kid、Lane 8、Bicep 和 CamelPhat。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=75
