#Acidcore
##基本信息
###发源时间：1990年代中期
###风格类型：Hardcore
##详情
Acidcore是一种融合了Acid
Techno、Gabber和Darkcore音乐元素的风格，1990年代中期在比利时、荷兰等地开始发展。这类音乐的案例可参考Search &
Destroy, Cellblock X, Buzz Fuzz等艺术家或厂牌Drop Bass Network等早期的作品。



在当时，Acidcore 是 teknival 中演奏和舞蹈最多的音乐类型之一，有 Furious、Architek 和 Total Resistance
等艺术家和团体参加。著名音乐家 Lasse Steen (DJ Choose)  也创作了许多 acidcore 版本。有些相关作品也可以在 gabber
版本中找到，例如 Thunderdome XIX 上的 Underground Warriors Progressive Hardcore - Cursed
By Evil Sickness。



**特征**

Acidcore 的特点是由 Roland TB-303 合成器产生的典型 Acid 音色和短促失真的底鼓，伴随着持续快速的节拍（大约 155 到 170
BPM）。同时，其也具有Acid Techno的特征即尖锐的高音。表征该类型的厂牌包括 Drop Bass Network、Neurotrope
Records 和 Acid Anonymous。 1998 年，这种风格更频繁地出现在自由派对中，以 DJ Set和现场表演的形式出现，如 WoXo 和
Capsule corps。在 2000 年代，新的艺术家出现了，例如 Ignite5、Mr. Gasmask6 或 Ruffneck（将
Industrial Hardcore 和 Acidcore 混合在一起）。也出现了一些致力于 Acidcore 活动的组织，例如比利时的 Retro
Acid。



**代表作品**

  * Buzz Fuzz -  _D-Leria_  (1993)
  * Buzz Fuzz -  _Vienna Bass_  (1993)
  * DJ Gizmo -  _Monological Destruction_  (1993)
  * Unknown Structure -  _Helixcoid_  (1993)
  * Son Of A Bitch -  _Alien Ate My Bassline_  (1994)
  * B.C.Kid -  _Short Chaos_  (1995)
  * Cellblock X -  _303  Kibutz_ (1996)
  * Underground Warriors -  _Canvas_  (1997)
  * Old School Terrorists -  _Acieeed_  (1997)
  * Corrosion of Conformity -  _King Of The Rotten (The D.O.A. Mix)_  
  * Cixx vs. The Vinyl Junk -  _Bounce 'n Shake_  (1998)

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://fr.wikipedia.org/wiki/Acidcore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=195
