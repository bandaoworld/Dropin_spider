#Deathstep
##基本信息
###发源时间：
###风格类型：Brostep
##详情
Deathstep是Dubstep子风格中最为硬核的类型之一，它结合了死亡金属乐和Dubstep音乐的特色元素。



**音乐特征**

Deathstep是死亡金属音乐和dubstep音乐的结合。Deathstep艺术家们希望从这两种音乐类型中取其精华并作结合。Deathstep歌曲的开头通常是听起来令人不安的吉他演奏，可能伴随很多合唱的元素。鼓组通常选用非常厚实和强硬的底鼓和一个高度"pan"的强调的军鼓组成，并带有很多即兴演奏段落。与流行乐的审美不同，Deathstep贝司往往也与常见的
dubstep wobble bass不同，常选用所谓的Machine Gun
Basses（机枪贝斯），通常以三连音的形式出现，并伴随更为失真的Growl和啸叫元素。



**历史**

"Deathstep"这个描述首次出现是Mobthrow在2009年3月发布的 Mutant dubstep EP
中的同名曲目"Deathstep"，被用作描述他受死亡金属和 dubstep 影响的新音乐风格的术语。同年，波兰制作人 Substep Infrabass
也将其用于名为"Voices From God (Deathstep
VIP)"的曲目中。还有许多像Chrispy这样的艺人都选择了这个名称并制作了自己的曲子（例如，Chrispy 的 Suicide Silence
remix系列）。



2011 年，Bratkilla 发布了他的 Deathstep LP----将 Deathstep 巩固为独立的一个风格分类。自此Deathstep
开始稳步发展。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://electronicmusic.fandom.com/wiki/Deathstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=152
