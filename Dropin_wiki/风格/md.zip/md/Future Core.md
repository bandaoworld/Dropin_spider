#Future Core
##基本信息
###发源时间：2010s后期
###风格类型：Future Bass
##详情
Future Core是将Hardcore与Future Bass的旋律内容和声音设计特征相结合的一种子流派。自 2017 年初中期发行"FÜGENE"
----Future core合辑以来，SoundCloud 已将其视为日本电子音乐制作人的一种流派。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://electronicmusic.fandom.com/wiki/Future_Bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=160
