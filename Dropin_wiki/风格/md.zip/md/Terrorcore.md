#Terrorcore
##基本信息
###发源时间：
###风格类型：Hardcore
##详情
Terrorcore--硬核音乐的次流派，创建于1995年。这个流派起源于鹿特丹，那里也是gabber的发源地。这些歌曲的特点是：



非常高的节奏（大约250BPM或更高）。

恐怖电影的采样（通常是非常扭曲的）。

Terror歌曲中不存在人声，但如果加入一些话语样本，它们大多非常短，由粗俗的话语组成。





Drokz被认为是 terrorcore这一名称的创造者。



**艺人**

Noisekick  
Drokz  
Akira  
The Destroyer  
Delta 9  
Diabarha  
Quato  
Gabba Front Berlin  
NigelL12  
DJ fauski  
Daby Dynamite  
Suicide Rage  
Extreme Rage  
Dissoactive  
Frankentek  
Tank  
Striker  
KlereHerrieKrew  
DGTP



###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://electronicmusic.fandom.com/wiki/Terrorcore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=216
