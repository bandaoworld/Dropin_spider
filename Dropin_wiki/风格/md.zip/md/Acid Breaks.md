#Acid Breaks
##基本信息
###发源时间：
###风格类型：Breakbeat
##详情
在电子音乐舞曲中，Acid Breaks是Breakbeat、Acid House和其它一些电子舞曲形式融合的产物。Acid
Breaks音乐的鼓组通常模仿自Breakbeat，不采用其它舞曲风格的标志性底鼓。Roland
TB-303是最早应用于Acid音乐的合成器之一，它充分利用了低通阻尼滤波器的效果来突出声音的泛音音色。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Breakbeat#Acid_breaks
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=93
