#Sambass
##基本信息
###发源时间：Early 2000s (decade)
###风格类型：Drum and Bass
##详情
Sambass，又称drum 'n' bossa或drum 'n' Sambass（"桑巴"和"贝斯"的组合），是一种具有地域性特点的Drum and
Bass音乐的子流派，主要源自巴西，它将Drum and Bass节奏与拉丁美洲音乐相结合。

  
该流派的流行艺术家包括DJ Marky、DJ Patife、XRS Land、Drumagick、Bungle、Marcelinho da
Lua、Kaleidoscopio和DJ Roots。由意大利唱片公司Cuadra发行的四张合辑《Sambass Vol.1》至《Sambass
Vol.4》受到国际好评。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Sambass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=117
