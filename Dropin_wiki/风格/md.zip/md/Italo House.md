#Italo House
##基本信息
###发源时间：Late 1980s
###风格类型：House
##详情
Italo house（在英国通常简称为" Italian house"或" Italian house"）是一种起源于意大利的浩室音乐。
自20世纪80年代末在意大利、英国和美国流行，它融合了house音乐和Italo
disco。该流派的主要音乐特点是以电子钢琴和弦为主，形式上比经典的芝加哥House唱片更加抒情。最著名的例子是Black Box的 "Ride on
Time"，但在80年代末和90年代初，该流派因在独立舞曲的背景下，以振奋的和颂歌式的曲调流行起来。



**历史**

"Italo-House "在90年代初被称为是一种快乐、兴奋的声音，主要由Gianfranco
Bortolotti的制作团队开创，他的另一个自我包括Cappella、R.A.F.、East Side
Beat和49ers。意大利制作的唱片在1990/91年的英国舞曲排行榜上占据了主导地位，其中包括Asha的 "JJ Tribute"、DJ H的
"Think About"、Last Rhythm的 "Last Rhythm "和Jinny的 "Keep Warm
"等歌曲，这些歌曲象征着愉悦的氛围。K-Klass、Bassheads和Felix等艺术家在意大利钢琴声的基础上创造出了振奋人心的曲子，至今仍在播放，不过DJ
Sasha等音乐先锋早已离开了钢琴的快乐氛围，专注创造其他风格。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Italo_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=72
