#Electrogrind
##基本信息
###发源时间：Mid-1980s
###风格类型：Hardcore
##详情
Electrogrind（Cybergrind）是重金属的 Grindcore 风格与 Electro/Hardcore 电子元素结合形成的子风格



Electrogrind 主要发展于21世纪，由 The Berzerker、Gigantic Brain 和 Genghis Tron
等艺术家将电子音乐中的硬核元素与 Grindcore 相结合而形成。这些团体在 Agoraphobic Nosebleed、Enemy Soil 和 The
Locust 以及其它 Industrial Metal 的作品之上进行探索。Berzerker 还采用了 Gabber 种制作人常用的高度扭曲失真的
Roland TR-909 Kick。在视觉形象上，许多后来的 Electrogrind 艺术家因其时髦的造型搭配而被漫画化。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Grindcore#Electrogrind
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=199
