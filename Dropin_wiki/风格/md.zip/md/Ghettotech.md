#Ghettotech
##基本信息
###发源时间：Early – mid-1990s
###风格类型：Ghetto House
##详情
Ghettotech（又称Detroit club）是一种源自底特律的电子音乐流派。它结合了芝加哥Ghetto House与底特律Techno、Miami
Bass和UK Garage的元素。



**概述**

前《底特律都市时报》的底特律音乐记者霍比-埃克林（Hobey Echlin）将ghettotech描述为一种结合了
"techno的快速节拍与说唱的呼唤和响应"相结合的流派。"它具有四层节奏，通常比大多数其他舞蹈音乐流派更快，大约在145到160
BPM。人声通常是重复的、粗糙的、色情的。正如DJ Godfather所说的那样，"节拍真的很粗糙，很生硬，没有任何打磨"。



Ghettotech作为一种DJ风格诞生于20世纪80年代末，其灵感来自于The Electrifying Mojo的折衷主义和Jeff "The
Wizard "Mills的快节奏混音和转鼓演奏。DJ们将混合多种风格，包括丛林、Ghetto house、Hip
Hop、R&B、电音和底特律Techno等。



底特律的贫民窟的舞蹈被称为jit，这种舞蹈风格主要依靠快速的脚步组合、跌落、旋转和即兴表演。jit的根源可以追溯到20世纪70年代的底特律Jitterbugs。芝加哥对应的舞蹈风格是Juke，其重点是步法，可以追溯到20世纪80年代末。



Ghettotech是一年一度的盛会底特律电子音乐节的一个组成部分。



Ghettotech在2007年左右出现了衰退，因为一些关键的艺术家与这种风格保持了距离。然而，近年来，Ghettotech的姊妹风格Footwork（芝加哥步法）的普及激增，催生了新的听众群体。Ghettotech最新一波的制作人经常以160
BPM的速度制作曲目，以更好地适应芝加哥步法和其他类型的音乐。



重要厂牌

  * Twilight 76
  * Databass
  * Electrofunk
  * Jefferson Ave
  * Motor City Electro Company
  * Intuit-Solar

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Ghettotech
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=68
