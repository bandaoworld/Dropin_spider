#Soulful House
##基本信息
###发源时间：
###风格类型：House
##详情
Soulful House 是一种 House 音乐的子流派，其特点是流畅而深情的人声、轻松的氛围和旋律结构，以及来自灵魂、爵士和放克元素的影响。



Soulful House 曲目的特点是速度较慢（122 到 127 bpm），通过键盘/合成器发出深沉的声音，类似于Chill-out和Lounge
Music常用的音色。歌曲采用4/4 House
节奏，通常伴随着钢琴、吉他、贝斯、低音提琴等乐器。因此，这类风格的制作人经常与歌手和现场音乐家合作。这些曲目通常以典型的爵士管乐器独奏为特色，例如萨克斯管或小号。



Soulful House 因其沿用 House
的节拍节奏而被认为是一种电子舞曲类型，但由于其轻松、随和的节奏和精致的声音，也可以在餐厅和商店以及高级时装秀中作为背景音乐听到。有时这种流派被认为是Nu-
Jazz和Lounge等流派的舞曲版本。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=83
