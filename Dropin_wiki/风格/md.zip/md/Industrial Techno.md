#Industrial Techno
##基本信息
###发源时间：1990s
###风格类型：Techno
##详情
Industrial techno
是起源于20世纪90年代的Techno的一个子流派。其特点是融合了早期Industrial音乐艺术家风格中的凄凉、嘈杂的声音和美学的影响，尤其是Cabaret
Voltaire和Throbbing Gristle。美国Industrial音乐厂牌Wax Trax！也对该流派的发展产生了深远的影响。



2010年代，在Adam X、Orphx和Ancient
Methods等乐队的带领下，以及后来的Blawan和Karenn等其他乐队的带动下，该流派又迎来了复兴，也因此俘获了大量的年轻爱好者。它与Techno
Industrial不可同日而语，Techno Industrial在本质上类似于power noise/rhythmic
noise的子流派。不同的术语取决于是从Techno的角度还是Industrial的角度，Industrial
Techno的节奏部分更多的是来自Techno的影响，有很多混响、噪音墙或科幻效果，而Techno
Industrial在创作上更接近于节奏噪音，使用失真的节奏部分。



其他与ndustrial techno相关的艺术家包括Cut Hands、Helena Hauff、Forward Strategy
Group、Surgeon、Michael Forshaw、Jeff Mills、Regis、Dominick Fernow和Mike
Banks。厂牌Perc Trax被认为是该流派在英国复兴的功臣，旗下艺人有Perc、Truss、Hppa和Ansome等。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Industrial_techno
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=145
