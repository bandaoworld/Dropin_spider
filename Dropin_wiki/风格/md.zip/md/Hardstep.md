#Hardstep
##基本信息
###发源时间：1994
###风格类型：Drum and Bass
##详情
Hardstep是1994年兴起的Drum and
Bass的一个子流派。它的特点是粗犷的制作风格，并有一种都市中心的氛围。它的breaks比起老派Jungle，少了一些切割的声音，而是有更快速、更硬朗的简单电子旋律。它的特点是突出而又稀疏的打击节拍。



这种风格受到了丛林主义者（Junglists）的青睐，虽然它的流行程度已经被techstep所取代，但这种风格的粉丝仍然存在。早期的Hardstep艺术家包括DJ
Hype和DJ Zinc。



###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Hardstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=111
