#Afro Trap
##基本信息
###发源时间：années 2010 ;
###风格类型：Trap
##详情
Afro trap是一种融合了说唱和非洲音乐各种元素的音乐流派。在说唱歌手MHD的推动下，Afro trap于2010年中期在法国兴起，他是该流派的先驱。



**描述**

Afro trap是非洲音乐中说唱和各种元素的混合物。主要是法国大城市郊区的非洲裔青年进行的。法德电视频道Arte曾将Afro Trap
music风格描述为 "在非洲和美国的声音之间成长起来的一代人的音乐。"在歌词方面，Afro
Trap的特点是刺耳、不妥协、以自我为中心的歌词。由于世界足球的缘故，这一流派的作品得到了普及。阿德里安-拉比奥特、保罗-博格巴、亚历山大-
拉卡泽特、塞缪尔-乌姆蒂蒂等球员以及其他非洲、欧洲和中国的球员，都曾用Afro trap舞步庆祝他们的进球。以及足球和其他球类运动都是Afro
Trap艺术家的灵感来源，因为这些运动往往是他们生活的一部分。几内亚-塞内加尔说唱歌手MHD被认为是这一流派的先驱，他被称为 "afro
trap"。这种流派的其他创作者包括来自刚果的艺术家Niska和Naza。其他包括Y du V、Afrojuice 195、Junior
Bvndo、Brazza和DOXMV。





###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://nl.wikipedia.org/wiki/Afrotrap
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=296
