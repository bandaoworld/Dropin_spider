#Chillstep
##基本信息
###发源时间：
###风格类型：Dubstep
##详情
Chillstep是Dubstep的一种子风格，是带有舒适情感的Dubstep，通常有爵士乐般的节奏和80年代的合成器音色的组合。它不仅仅是一个子流派，而是一个打开你的思想和触动你的灵魂的Subbass领域的旅行。Chillstep的特点是比主流Dubstep更深沉、更稳定的低音，Chillstep受到了Future
Garage的影响，Future Garage是UK Garage的一个变种，普遍受到Dubstep和Ambient的影响。



值得一提的艺术家是早年的Blackmill。CoMa、EvenS、Killigrew和SizzleBird多年来也为chillstep的声音做出了贡献。其他几位艺术家也帮助了这个流派的成长和发展，如Eminus、Sacred、Vexaic、Faux
Tales、Sappheiros、Jacoo和Electus等等。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/chillstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=161
