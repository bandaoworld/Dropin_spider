#Martial industrial
##基本信息
###发源时间：Late 20th century
###风格类型：Industrial
##详情
Martial industrial是industrial music的混合分支，其特征是noise，dark
ambient的氛围，neofolk的旋律，dark
wave的曲调和neoclassical的音乐编排，以及军事游行，历史演讲和政治，非政治或超政治歌词的音频的结合。与其他post-
industrial流派不同，martial industrial通常对特定的世界观或哲学更感兴趣，而不是纯粹的实验主义。



**历史**

Laibach是最早将军事进行曲融入其工业音乐并展示政治挑衅美学的乐队之一。 Noise Music的先驱Boyd
Rice和Neofolk的先驱Douglas
P，在数次场合中将Laibach的这种态度发挥到了极致。奥地利组合Allerseelen遵循着同样的脉络，通过他们特色的仪式赞歌或炼金民间传唱形式延续着探索。
ACTUS标志性的英勇合唱输出有着同样的激进，但不那么挑衅，使之更为深奥。Les Joyaux de la
Princesse进一步发展了这一流派，提供了一种特别迷人的黑暗Ambient氛围，并混合了与历史关联的采样、演讲和战时香颂。 The Moon Lay
Hidden Beeath a Cloud / Der Blutharsch 丰富了这一传统，在mix中加入了黑暗的中世纪旋律。最后，In
Slaughter Natives 和 Puissance 分别将流派扩展到管弦乐和新古典主义的方向。



**特点**

"Martial"一词不一定仅指军事击鼓，而通常指不祥/剧烈的气氛以及特定的主题，风格，美学和世界观。同样，"industrial"一词不仅表示old-
school的industrial music，还表示广泛的post-industrial（从neofolk到noise）。因此，诸如Genocide
Organ（power electronics），Oda Relicta（sacral），Stahlwerk
9（industrial），N.K.V.D.（industrial black metal），Die Weisse Rose（darkwave），Axon
Neuron / Vagwa（dark ambient），Feindflug（EBM），Gae
Bolg和Fand教堂（medieval），H.E.R.R.（neoclassical）和Scivias（neofolk）都可以归类为"martial
industrial"。 Martial industrial music经常使用与战争，极权政权，欧洲民族主义，军事表演和政治群众集会有关的主题-
简而言之，个人是由历史和群众意志所包容的。一系列带有自由主义，反世界主义和反平等主义偏见的哲学，政治或宗教主题占主导地位，如弗里德里希*尼采的Übermensch，奥斯瓦尔德*斯彭格勒对西方衰落的悲观构想，米尔恰*伊利亚德的神圣实践和象征主义理论，勒内*古埃关于西方"精神堕落"的著作，ErnstJunger关于战争和逆境更新力量的思想，Julius
Evola的反动政治和神秘主义，纳粹神秘主义和基督教前异教徒。 Martial
industrial在世界范围内流传，但在德国，匈牙利，法国，意大利，波兰和俄罗斯更为繁荣。



**法西斯主义的指责**

一些乐队（Von
Thronstahl）公开宣称有兴趣学习法西斯意识形态，而其他乐队（Kraschau）则支持君主制，另一些乐队（Militia）则是生态无政府主义者和布尔什维克民族主义者。一些人探索历史和统一美学的色情维度（Ordo
Rosarius Equilibrio）。有时候，martial
industrial艺术家不涉及历史或政治问题。涉及此类问题并使用政治上不正确图像的其他乐队（Turbund Sturmwerk）拒绝透露他们的真实想法。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Martial_industrial
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=274
