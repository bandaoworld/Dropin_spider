#Fidget House
##基本信息
###发源时间：2006
###风格类型：Electro House
##详情
Fidget house（Dirty Electro Fidget
House或Fidget）诞生于2000s年代末，其特点为大量运用和糅合怪异零碎的人声切片、粗糙毛刺而复杂的合成器音色和Bassline。



Fidget house是由 "在4/4节拍上建立的，由凌乱的人声切片，pitch-
bending（音调变换）的具有脏质感的Bassline，rave风格的短促合成器冲击，毛刺故障的音色等元素混合而成。"。它包含了来自Chicago
House, Techno, Baltimore Club，Kuduro，Pimba和嘻哈的影响。该流派的传播者包括The Bloody
Beetroots，AC Slater，Danger，Herve，Sinden，Jack Beats和Switch。



fidget house这个词是由DJ/制作人Jesse
Rose和Switch半开玩笑而创造的，但却成为了脍炙人口的概念。"作为一个玩笑，现在已经有点过头了"



数十年后，Fidget House类型的音乐已经逐渐销声匿迹，而其音乐上的元素也影响了Complextro，Bass
House这些Bassline较为复杂的风格，很多原本Fidget House的制作人也逐渐向这些风格转型。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_house#Fidget_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=55
