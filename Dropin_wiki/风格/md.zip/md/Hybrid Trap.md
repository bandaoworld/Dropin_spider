#Hybrid Trap
##基本信息
###发源时间：
###风格类型：Trap
##详情
Hybird Trap是Trap和Brostep融合的子类型，以Trap的鼓组为基底但更加密集杂乱，使用极其富有金属感的Bass Lead音色以及808
Bassline是这类音乐的重要特点，呈现出极具侵略性和刺激性的听感。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=300
