#Instrumental Hip Hop
##基本信息
###发源时间：
###风格类型：Hip Hop Music
##详情
Instrumental Hip
Hop是嘻哈音乐的纯器乐伴奏部分，它可以作为独立的一类音乐形式存在。他在嘻哈音乐中通常被称为"beat"或"Instrumental"。



一般来说，嘻哈音乐由两个元素组成：一个是器乐轨道（"beat"），一个是人声轨道（"rap"）。制作beat的艺术家是制作人（或beatmaker），制作说唱的是MC（emcee）。在这种形式下，rap几乎总是歌曲的主要焦点，在一个相当重复的节拍上提供了大部分的复杂性和变化。



Instrumental hip
hop是没有Rapper说唱的嘻哈音乐。这种形式让制作人可以灵活地创作出更复杂、更丰富、更多样的instrumentals。这种流派的歌曲可能会在不同的音乐方向上游走，探索各种子流派，因为乐器不必为MC提供稳定的节奏。



虽然自嘻哈诞生以来，制作人已经制作并发布了没有MC的hip hop beats，但这些唱片很少成为知名的唱片。爵士键盘手/作曲家Herbie
Hancock和贝斯手/制作人Bill Laswell的电音合作是明显的例外。1983年的《Future
Shock》专辑和热门单曲《Rockit》由转盘手Grand Mixer D.ST参与制作，这是转盘在爵士乐融合中的首次使用，也让转盘主义和唱片 "刮碟
"得到了广泛的曝光。



1996年，DJ Shadow首张专辑《Endtroducing.....》的发行，见证了instrumental hip
hop运动的开始。主要依靠采样funk, hip hop and film score的结合，DJ
Shadow创新的采样编曲影响了许多制作人和音乐人。在2000年和2010年，RJD2、J Dilla、Pete Rock、Large
Professor、MF Doom、Danny！、Nujabes、Madlib、Wax Tailor、Denver Kajanga、DJ
Krush、Hermitude和Blockhead等艺人的instrumental hip hop专辑都获得了广泛的关注。



由于版权法的现状，大多数instrumental hip
hop的发行都是在小型的独立厂牌上发行的。制作人往往很难为其作品中的许多样本获得许可，而像Stones Throw这样的厂牌则经常面临法律问题。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Hip_hop_production#Instrumental_hip_hop
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=285
