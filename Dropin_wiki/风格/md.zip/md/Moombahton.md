#Moombahton
##基本信息
###发源时间：2008
###风格类型：House
##详情
Moombahton舞曲是一种结合了浩室音乐（House）和雷吉顿舞曲（Reggaeton）的新兴舞曲流派，是由美国DJ Dave
Nada定义的一种风格，特点是厚实的电气声和慢慢扩散的低音线，；Build
up的处理上比较情景化，不像是常规的堆叠式推动情绪，而是放空并切换场景的戏剧式；并且在放慢的Bpm里填充上快而密集的鼓点，并且伴有人声切片样本。Moombahton其实是一种放慢速度的Electro
House，并且加入了Reggaeton和Dutch
House的元素，有种魔性的节奏律动，充满了拉丁风情。这类风格慢慢受到了各大DJ的青睐，并且随着神曲《Lean On》的出现而火爆全球。



![](https://duopin-community.oss-cn-
shenzhen.aliyuncs.com/c1j7iln38pr4s5x7f3kr.jpg)

Dillion Francis是Moombahton场景中的一位知名艺术家

By swimfinfan from Chicago - Dillon Francis @ Aragon, Chicago 12/14/2013, CC
BY-SA 2.0, https://commons.wikimedia.org/w/index.php?curid=37075019



**特征**

Moombahton的特征包括浓重且分散的低音线，引人注目的音色以及使用快速鼓点的2-step跳动。有时，moombahton会使用狂欢音乐合成器和无伴奏说唱。
音乐上，moombahton的节奏起源自Dutch House或House音乐 ，伴随着缓慢的雷鬼节奏和打击乐
，以通常每分钟100至128拍（BPM）演奏。



**历史起源**

Moombahton是由Dave
Nada（戴夫*纳达）在2009年末为他表弟在华盛顿的高中派对做DJ时创建的。他将他计划播放的House和俱乐部音乐与客人们之前听的雷鬼和巴卡塔音乐融合在一起，将Afrojack对Silvio
Ecomo和Chuckie的歌曲 "Moombah!"的混音从128 BPM放慢到108 BPM，从而创造了这个流派的基础。



_"......我试着把我的House歌曲放慢，我把Afrojack对Silvio Ecomo和DJ Chuckie的 "Moombah "的混音放在108
BPM，人们都疯了。我对Sidney Samson的 "Riverside "也做了同样的处理，那是一种谵妄。我明白，我必须尽快录制这些版本。"_

_戴夫-纳达_



2009年底至2010年初，纳达在T&A唱片公司的DJ Ayres和DJ
Tittsworth的支持下，制作了一张五首Moombahton曲目的加长版，于2010年3月发行。



**子流派**

Moombahcore

Moombahcore是moombahton的一个子流派，受到dubstep的影响，也融入了新式硬核、breakcore和techstep的元素。Moombahcore融合了dubstep鼓和moombahton节奏（100-115
BPM），融入了摇摆贝斯、FM合成器、失真基音和复杂的打击乐模式等元素。



Moombahsoul

Moombahsoul是moombahton的一个子流派，受到Deephouse的影响。它结合了灵魂乐、lofi、Deephouse和寒潮的元素，并以moombahton为背景的鼓点和质感。David
Heartbreak在2011年推出了这个流派的第一张合辑，名为 "HEARTBREAK presents
MOOMBAHSOUL]"。这张15首歌曲的合辑包括了Munchi、Heartbreak、DJ Theory & More等的曲目。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Moombahton
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=77
