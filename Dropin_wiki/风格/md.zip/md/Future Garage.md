#Future Garage
##基本信息
###发源时间：Mid-2000s 
###风格类型：UK Garage
##详情
Future Garage（未来车库）是一种电子音乐类型，是UK Garage第一个子风格，在2000年代中后期发展迅速。它融合了来自UK
Garage的各多种影响和来自2-step
garage的柔和元素，从而形成了一种偏激别致的节奏风格。其典型的声音是音调调制的人声切片，偏暖的滤波处理的贝斯，黑暗的气氛（包括合成Pads，现场录音和其他环境声音）和黑胶唱片的噼啪声。节奏通常在130到140
bpm之间，但也可以更慢或更快。



顾名思义，它是将旧的Gagare翻新成具有未来感的呈现理念。在这之前，Dubstep是UK
Garage发展很热门的一个分支，但是也有一些Dubstep音乐人开始摒弃Dubstep的一些特征，转而回到UK Garage /
2-step最开始的清淡，但是仍借鉴了很多2000年以后才出现的新的制作手法来创作Future Garage，算是新与旧的结合。



**音乐细节**

Future garage融合了UK Garage的各种影响和2-step garage的柔和元素。这个流派被描述为受到UK Garage、Dark
Swing、2-step garage和grime的影响，产生了所谓的
"未来主义"，而且经常是非常偏离轨道的现代节奏制作风格。这个名字是Whistla在2009年11月 "Future garage Forum
"出现之前发明的。在2013年3月出版的《音乐科技》杂志第108期中，有人提出Future
garage应该采用重新调整的人声，有柔和attack的主音lead或原声主音，经过调制滤波的Subbass或方波bass，以及four-to-the-
floor或 2-step garage的鼓点节奏加上off-the-grid的hi-hat。future
garage鼓节拍中明显的摇摆是注重在其kick和snare pattern之间的有"延迟"或真实拟人演奏的hi-
hats。著名的艺术家包括Burial、Vacant、Klimeks、Pensees、Manu Shrine、Roam、CloudNone和Zomby。



Future Garage没有Dubstep那样过度浑厚摇晃的贝斯。它虽然回到UK Garage的清淡，但是相比UK
Garage更适合俱乐部跳舞的特点，Future
Garage更适合室内聆听，它借鉴了一些智能舞曲（IDM）的制作手法，通常有着极简主义的思路，制作更光洁，旋律更悦耳。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Future_garage
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=128
