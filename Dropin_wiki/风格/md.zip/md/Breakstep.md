#Breakstep
##基本信息
###发源时间：Late 1990s
###风格类型：UK Garage
##详情
Breakstep，或称breakbeat garage，是一种由UK Garage场景演变而来的音乐类型，并影响了dubstep的出现。



**历史**

Breakstep是由2-step
garage的声音演变而来。摆脱了Garage中更多的灵魂元素，它结合了downtempo鼓和Bass风格的basslines，将2-step的shuffle换成了更直接的breakbeat鼓模式。这种风格的突破来自于1999年DJ
Dee Kline的 "I Don't Smoke"，在Rat
Records上卖出了15,000张，最终在2000年被授权给EastWest，并在英国单曲榜上攀升至第11位。之后，DJ Zinc的 "138
Trek"，是UK Garage节奏（138 bpm）的Drum and Bass制作实验。在Forward>>（伦敦Plastic
People的俱乐部之夜）上，Zed Bias和Oris Jay（又名Darqwan）成为了东道主。他们在DJ
Distance等制作人的break中得到了启发。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Breakstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=127
