#Trival
##基本信息
###发源时间：Early 2000s in Latin America (mainly Mexico),
###风格类型：Electronica
##详情
Tribal guarachero，又称Trival，是一种融合了电子舞曲和特定节奏的墨西哥地区音乐流派的音乐流派。



Tribal guarachero有时也被称为 "3ball"。尽管西班牙语中的字母 "b "和 "v "很相似，但不应将其与tribal
house或tecnocumbia音乐相混淆。



历史

2000年和2001年，这种风格起源于墨西哥城的中下层社区，2007年移至新莱昂州的蒙特雷，2008年移至美国。2010年代初，它在墨西哥裔美国人聚居的大都市和南部各州最受欢迎。tribal
guarachero音乐制作人的前身之一，是最受欢迎的来自蒙特雷的3Ball MTY。



特征

tribal guarachero音乐融合了包括technobanda在内的墨西哥地方音乐和techno, electro house, club
music等EDM流派。以4/4为时标，该流派通常由层叠的三连音和140至280的BPM组成。节奏采用了非洲-古巴节奏和拉丁合成器。



使用方法 作为一种dance和EDM音乐风格，tribal
guarachero音乐可以以独特的舞蹈动作用在独舞中，或在参加舞蹈比赛的舞蹈团中。墨西哥尖头靴通常与tribal
guarachero音乐相关联，并在这些舞蹈比赛中穿着。



###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=365
