#Progressive Breaks
##基本信息
###发源时间：Early 1990s
###风格类型：Breakbeat
##详情
Progressive breaks（也被称为Prog Break, Atmospheric
Break）是Breakbeat的一个子类型，本质上是Breakbeat和Progressive house的融合。与Progressive
house非常相似，这个子类型的特点是其 "trance
"的声音。包括延伸的合成器垫，旋律性的合成器Lead，重混响和电子节拍。然而，与progressive house不同的是，progressive
breaks的曲目很少有人声，大多数曲目完全是乐器演奏，或只使用电子人声样本来达到声音效果。典型的progressive
breaks曲目通常会有一个长久的Build-up，促成音乐的分解和高潮，在不同的时间间隔内，经常添加或减少许多声音元素，以增加其强度。



Progressive breaks的艺术家包括Hybrid, BT, Way Out West, Digital Witchcraft, Momu,
Wrecked Angle, Burufunk, Under This和Fretwell。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Breakbeat#Progressive_breaks
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=103
