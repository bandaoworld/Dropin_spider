#Zenonesque
##基本信息
###发源时间：
###风格类型：Psychedelic Trance
##详情
Zenonesque是psytrance的一种风格，它是任何具有厂牌Zenon
Records发行作品的声音特征的psytrance。它听起来通常是深邃，Dark
Ambient质感的声音，节拍较慢。它可以包含techno元素。相关艺术家包括Electrypnose、Kromagon、Ivort、Grouch、Tetrameth和Shadow
FX。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Psychedelic_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=181
