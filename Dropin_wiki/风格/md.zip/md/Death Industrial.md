#Death Industrial
##基本信息
###发源时间：
###风格类型：Power Electronics
##详情
Death industrial是industrial的子流派，以浓厚的气氛，低端的嗡嗡声，刺耳的循环以及尖叫和/或失真的人声为代表。 它可以与power
electronics区分开来，它具有较慢的，更大气的声音（让人联想到dark ambient）和较少的磨擦声。 death
industrial艺术家包括Brighter Death Now，Anenzephalia，Atrax Morgue，Aelia
Capitolina，Author & Punisher，Genocide Organ，Ramleh，Hieronymus Bosch，Stratvm
Terror和Dead Man's Hill。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.m.wikipedia.org/wiki/Power_electronics_(music)#Death_industrial
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=255
