#Chinese grime
##基本信息
###发源时间：Around 2015
###风格类型：Grime
##详情
Chinese Grime是Grime音乐在中国本土演化和发展的具有地域性特征的子风格。



在中国的上海和北京，存在着一个相对较小的grime场景，由两位英国外籍人士Naaah和Alta发起。2015年前后，Alta和Naaah的厂牌Push &
Pull和发起人Puzzy Stack开始推广grime派对。在上海，这些派对主要在一家名为The
Shelter的俱乐部举办。许多本地制作人会去这家俱乐部展示他们的音乐。该俱乐部在2016年年底因为牌照问题被关闭，后来他们会搬到All Club。



2009年，一种被称为 "sinogrime
"的融合了东亚主题元素的grime风格在中国首次开始受到关注，并影响了本地制作人。上海的制作人Swimful在2016年重新混音了Wiley的sinogrime器乐《上海》。北京的制作人Howie
Lee也制作了一张带有sinogrime元素的专辑《Mu Che Shān Chū》。



与其他地方的grime不同，由于缺乏本土MC，中国grime多为器乐。据北京的grime推广人Puzzy
Stack说，高强度的grime让中国MC很难说唱过来。俱乐部在这一场景中扮演着重要的角色，举办grime之夜，让当地的DJ和制作人可以来展示他们的音乐。制作人有时会加入本地流行文化的样本和参考，比如功夫电影或Mandopop。



2016年，英国grime MC Novelist和AJ Tracey访问上海，并与当地grime制作人一起演出。Killa P、P Money和日本MC
Pakin和Dekishi也曾到访。



2018年，中国饶舌歌手艾福杰尼After Journey前往英国与当地MC
Cadell一同拍摄一部关于Grime的纪录片。在拍摄纪录片的同时，Cadell和After
Journey还制作了一首由英国&中国MC演唱的grime歌曲《2 Much》，这首歌后来被BBC Radio 1xtra的DJ Target收录。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Grime_(music_genre)#Chinese_grime
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=131
