#Jumpstyle
##基本信息
###发源时间：Early 2000s
###风格类型：Hardstyle
##详情
Jumpstyle是一种流行于西欧的电子舞蹈风格和音乐流派，在东欧、澳大利亚和美洲也有流传。



JumpStyling通常被称为"Jumpen"：英语单词"Jump"和荷兰语和德语后缀"-en"（意思是"to Jump"或"jumping"）的组合。



它起源于比利时，但在2000年代在其邻国荷兰获得了更高的人气。



**历史       **

Jumpstyle，最初只是被称为jump，创建于比利时。 它是一个短命的小流派，并没有以其最初的形式获得普及。
然而，在世纪之交，它又回到了公众面前，2003年初在德国经历了重大变化后，整个欧洲的粉丝开始增加。



在获得其目前的名称后，jumpstyle在欧洲被重新引入，并在2005年出现了艺术家和团体制作和发布其音乐。



由于Scooter的 "问题是什么？"和 "跳遍世界
"等音乐视频的成功，其流行的第一个关键阶段出现在2007年和2008年之间，这导致他们的第13张录音室专辑在英国排行榜上排名第一。
然而，仍有一些广播电台，以传统的形式播放jump。 最早的jumpstyle电台成立于2005年，至今仍以JumpStation.FM的名义存在。



这种风格也与其他类型的音乐相融合，例如，Major Lazer和The Partysquad在 "Original Don
"一曲中混合了丛林人声采样的独特曲目，对jumpstyle/hardstyle有影响。 另外，Joel Fletcher对Savage的2005年单曲
"Swing "的混音也使用了jumpstyle的元素。



**锦标赛和联赛     **

世界各地都有各种jumpstyle的联赛，大部分是以在线视频提交和互联网比赛的形式。 然而，在比利时，已经有了诸如European Jump
Masters这样的比赛。



英国是第一个正式建立国际水平的在线联赛的国家，有FIJL（第一届国际跳跃式联赛），但缺乏支持，许多选手退出，留下了许多混乱。



从正面看，这在澳大利亚、俄罗斯、德国和西班牙等国引发了一些国际联赛。



**音乐**

Jumpstyle音乐是techtrance、hardstyle、Gabber和Makina的衍生。 它的节奏通常在140到150BPM之间。
然而，它不能被视为仅仅是gabber的慢速版本，它的特点是在地板上使用909踢腿鼓的节奏， 它还受到hard house 和electro
house的影响。
大约从2002-03年开始，jumpstyle开始从hardstyle音乐中获得影响，比如在旋律中设置的音调基音，更复杂的多频段失真，以及利用方波的合成器。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Jumpstyle
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=187
