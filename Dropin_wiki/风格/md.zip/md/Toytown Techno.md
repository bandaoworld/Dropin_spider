#Toytown Techno
##基本信息
###发源时间：20世纪90年代早期
###风格类型：Techno
##详情
Toytown Techno（也称为kiddy rave或cartoon
rave）是20世纪90年代早期techno的一个子类型，其特点是将techno、oldskool jungle或breakbeat
hardcore与儿童节目或公共信息电影的采样相结合。



Toytown Techno类型中流行的歌曲包括Mark Summers的 "Summers Magic"、Smart E的 "Sesame's
Treet"、The Prodigy的 "Charly "和Urban Hype的 "A Trip to Trumpton"，分别采用了《The Magic
Roundabout》、《Sesame Street》、《Charley Says》和《Trumpton》的采样。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Toytown_techno
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=149
