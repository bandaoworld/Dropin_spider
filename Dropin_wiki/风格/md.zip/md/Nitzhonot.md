#Nitzhonot
##基本信息
###发源时间：Mid-1990s
###风格类型：Goa Trance
##详情
Nitzhonot（希伯来语，意为"胜利"）是Goa Trance的一种形式，融合了Epic Trance，于20世纪90年代中后期在以色列发展成型。



Nitzhonot融入了非常重的贝斯旋律，有时被称为"laserkicks"，在1996年到1997年，它和印度经典旋律Goa
trance有相似的地方。这种音乐节拍通常在145-155 BPM的范围内。



Nitzhonot最受欢迎的时候，在以色列相当成功。这个流派中最著名的艺术家是Eyal Barkan，他在1998年发行了他的专辑Good Morning
Israel。它成为首张在本国获得金牌的trance唱片，（正版）销量超过2万张（盗版唱片超8万张）。其他来自希腊和以色列的艺术家在当年也相当受欢迎。在2000年前后，阿斯特里克斯（Astrix）成为以色列另一位著名的nitzhonot艺术家。



在以色列的大多数艺术家将精力转向Full On之前，希腊的艺术家们正在这个领域努力耕耘。新千年伊始，更名为"uplifting
trance"（不要与epic trance，也叫uplifting
trance相混淆）的nitzhonot开始重新受到大家的欢迎，其中著名的希腊艺术家包括Cyan, Cherouvim, Star Children,
Darma, Space Odyssey和Dementia。



希腊的Uplifting音乐行业此后多年来一直沉寂，在2000s年代后期很少有相关曲目，但2010年之后，尤其是在以色列，nitzhonot再次变得流行。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Nitzhonot
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=171
