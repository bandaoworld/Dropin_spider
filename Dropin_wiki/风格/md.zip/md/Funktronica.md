#Funktronica
##基本信息
###发源时间：
###风格类型：Electronica
##详情
Funktronica是一种融合了electronica和funk的音乐流派。



Funktronica乐队

根据Billboard，Particle是一支 "funktronica "乐队，由GRiZ、Big
Gigantic和Gramatik等艺术家领导。GRiZ是来自密歇根州底特律的electronic
saxophone制作人，是Funktronica运动的流行领袖。25岁的他已经被誉为这一流派的领袖，将传统元素与pop, hip hop, 和
bass相结合。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=348
