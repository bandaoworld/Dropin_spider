#Melodic Techno
##基本信息
###发源时间：2010s
###风格类型：Techno
##详情
Melodic Techno是一种Techno音乐的子类型。Melodic
Techno注重旋律部分的表现，具有更氛围感和迷幻感的声音，尤其强调琶音的小调旋律，将其与Progressive
Trance紧密联系在一起，曲速通常在125 - 130 bpm。



该类型与Melodic House有着密切的联系，二者都源自Progressive House，之间的差异主要体现在 house 和 techno
之间的差异。



以制作该流派而闻名的Melodic Techno艺术家包括 Maceo Plex、Tale of Us、Kolsch 和 Boris Brejcha。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=146
