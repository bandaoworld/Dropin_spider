#Crunkcore
##基本信息
###发源时间：Mid-2000sMid-2000s
###风格类型：Crunk
##详情
Crunkcore(也被称为crunk punk、screamo-
crunk和scrunk)是一种融合了crunk、screamo、pop、electronic和舞曲等多种文化和音乐元素的音乐流派。这一流派的特点通常是尖叫的人声、嘻哈节奏和性挑逗的歌词。



**历史和特点**

作家和音乐人Jessica Hopper声称，crunkcore的影响可以追溯到2005年，当时Panic！at the
Disco将emo与electronics混合在一起。虽然crunkcore的典型特征是使用尖叫的人声，但有些crunkcore艺术家并不尖叫。例如，Warped
Tour的联合创始人兼首席执行官Kevin Lyman称3OH！3乐队是 "scrunk的真正转折点"，他说
"虽然3OH！3并没有融入许多scrunk表演中令人血脉贲张的尖叫声，但他们是第一个脱离传统乐器而采用预编程节拍的受emo影响的表演"，同时仍然保留了许多emo的风格元素。不使用尖叫人声的
The Millionaires 也是crunkcore。The Phoenix将crunkcore描述为 "minimalist的南方嘻哈、Auto-
Tune的唱腔、techno的破音、吼叫的人声和频繁的派对的诗意结合"。Inland Empire杂志将这种风格描述为结合了 "post-hardcore
和重金属 licks与crunk"。



**文化和批评**

The Boston Phoenix曾提到对这种风格的批评，称
"一小群孩子将最低标准的screamo与crunk节拍、被挪用的黑帮话语和emo时尚的极端服装化进行混音，这种想法肯定会激起充满仇恨的抨击"。Noisecreep的Amy
Sciarretto指出，crunkcore "经常被人诟病为这一代的nu metal"。特别是Brokencyde这个团体被挑出来，《卫报》的John
McDonnell对他们的音乐进行了不利的评论。AbsolutePunk的创始人Jason
Tate表示，对Brokencyde的反击程度超过了他在这十年中看到的任何一个表演。根据Tate的说法，"他们就是那么糟糕，他们是音乐（和人类）不应该成为一切的缩影"。Brokencyde成员Mikl已经承认了对他们的批评，但表示："我们不在乎人们说什么......。这些批评家都想把我们打倒，然而我们的音乐却销售了很多，这都是因为我们忠实的粉丝。"
作家Jessica
Hopper也曾批评过这个团体，但承认它对青少年的吸引力，他说："broencyde完全引用了任何可能与当代流行文化相关的东西，或者青少年喜欢的任何东西....。你会一下子得到所有东西。"3OH！3在2015年发行了一首名为
"My Dick "的单曲，引起了类似的争议。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Crunkcore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=282
