#Atmospheric drum and bass
##基本信息
###发源时间：
###风格类型：Drum and Bass
##详情
Atmospheric Drum and Bass是Intelligent Drum and
Bass演化而来的细分类型，它有着更为沉静的氛围以及更合成质感的音色。这类风格的先驱艺人包括Calibre、Zero Tolerance (Zero T)
& Beta 2、London Elektricity、High Contrast、Logistics、Nu:Tone、Danny
Byrd、Cyantific、Netsky、Lenzman、Technimatic (Technicolour & Komatic)、Hobzee &
Zyon Base、Paul T & Edward Oberon、Hybrid Minds等，先驱厂牌包括Hospital Records、Fokuz
Records和Liquid V等。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drum_and_bass#Light_drum_and_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=104
