#Hardwave
##基本信息
###发源时间：2017
###风格类型：Wave Music
##详情
Hardwave 是 Wave Music 的一种子风格，结合了来自 Trance、Hardstyle 等风格的元素



2017年，来自澳大利亚珀斯的制作人 Skeler 和 Ytho 开始尝试向 Wave 音乐中加入来自 Trance 和 Hardstyle
的元素，以迎合更多的俱乐部、节日活动等现场观众的需求，也因此让 Wave 风格得到了更加广泛的推广。经过不断地发展演化，这种融合风格也逐渐成为 Wave
场景中的新风格分支，被称作 Hardwave。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Wave_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=379
