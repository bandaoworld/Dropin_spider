#Acid Techno
##基本信息
###发源时间：Early 1990s
###风格类型：Techno
##详情
Acid techno，有时被称为"Acid"，是Techno的一种子风格，起源于Acid
House。于20世纪90年代初在欧洲发展起来，由当时年轻的艺术家将芝加哥Acid House的合成器调制声音应用于更为硬朗的Techno中而形成。



**特征**

Acid元素主要是通过Roland乐器获得的，最突出的是TB-303低音合成器。所谓Acid（酸、迷幻）声，是特指Roland 303的刺耳的 "酸性
"压制声。酸声是通过操纵合成器的共振和截止频率参数来实现的；在录制音轨的过程中进行实时操作是一种被称为调整的技术。除了从美国进口的acid唱片外，这种风格还受到hardcore,
德国Trance, 和比利时 rave 音乐的影响。



![](https://duopin-community.oss-cn-
shenzhen.aliyuncs.com/naxjv2mpfm9aj6gp7jkw.jpg)

标志性的"Acid"音色来自于Roland TB-303合成器

By ミシャー, CC BY-SA 3.0, https://commons.wikimedia.org/w/index.php?curid=1255077



**历史**

早期的代表人物包括Richie Hawtin（又名Plastikman）、Aphex Twin、Dave
Clarke、Hardfloor、solarquest、Damon Wilde。其他主力包括伦敦的解放者、Henry Cullen（又名D.A.V.E.
The Drummer）、Guy McAffer（又名The Geezer）和DDR。



在伦敦，Acid Techno是通过非法的派对网络发展起来的；1997年的合辑《It's Not Intelligent...And It's Not
From Detroit...But It's F**king 'Avin It》的副标题是 "The Sound of London's Acid
Techno Underground"，帮助巩固了这种流派在underground的地位。



Roland TB-303低音合成器提供了在acid音乐中经常听到的电子压制声。2015年之后，随着市场上出现所谓的Roland
TB-303克隆机，Acid Techno
music重新受到关注。TB-303的软硬件克隆机都可用。原厂Roland重新推出了TB-303，并创建了一个软件版本。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Acid_techno
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=136
