#Electronicore
##基本信息
###发源时间：2000s (decade)
###风格类型：Electronic Rock
##详情
Electronicore(也被称为synthcore或trancecore)是一种融合了各种电子音乐类型元素的metalcore音乐流派，通常包括trance,
electronica和dubstep.



Sumerian Records在2000年代末指出，"最近 electronica/hardcore music已经过剩"。Attack
Attack！通常被认为是这种风格的主要美国贡献者，是受到英国乐队Enter Shikari的启发。"Enter Shikari
"是一支电子乐乐队，1999年开始，增加了最后一名成员，2003年初在英国圣奥尔本斯由 "Hybryd "转型为 "Enter
Shikari"。该乐队曾获得国际广播电台的播放量和大量的音乐奖项，包括Kerrang！、NME、摇滚之声杂志和BT Digital
Awards。他们表达了与trance等电子音乐流派的关系，被称为 "kings of trancecore"。他们的第二张专辑名为《Common
Dreads》，于2009年6月发行，在英国专辑榜上首发排名16。I See Stars首张专辑《3-D》在 "synthcore现场中 "很受欢迎。We
Butter The Bread With
Butter是另一支电子摇滚乐队，来自德国吕本（Spreewald），自2008年以来已经发行了四张专辑和一张EP。合辑《Punk Goes Pop
4》是Punk Goes...系列众多专辑之一，"收录了当今乐坛最热门的流行歌曲，由不同的metalcore, post-hardcore
和electronicore艺术家演绎。" 独立音乐杂志Altsounds指出，"结合电子和金属音乐风格的乐队数量突然增加"。文章指出，许多为《Punk
Goes Pop 4》创作翻唱歌曲的乐队都融入了electronicore的特点，特别是参考了《I See Stars》和《Woe, Is Me》。



**特征**

Electronicore的特点是典型的金属核心乐器、分解、大量使用音序器、传统乐器录音采样器、电子音调生成合成器、自动调音唱法和尖叫人声。这种风格经常会有从柔和的电子民谣到激烈的metalcore
段落的动态转换。然而，metalcore
特征的融入程度可能会有所不同。除了电子乐，融合可能涉及各种其他电子音乐流派，包括techno、trance、dubstep、electro和dance。



**相关音乐风格**

Nintendocore是一种摇滚音乐类型，包括电子游戏音乐和chiptune的元素。它是post-
hardcore的一种衍生形式。Crunkcore是一种结合了post-hardcore和Screamo、Crunk hip
hop和电子音乐特点的音乐流派。Digital hardcore是一种融合了hardcore punk元素和各种形式的electronic music
和techno的音乐流派。它发展于20世纪90年代初的德国，通常以社会学或左翼的抒情主题为特色。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=311
