#Shamstep
##基本信息
###发源时间：
###风格类型：Electronica
##详情
Shamstep是中东地区的一种电子舞曲流派，将传统的Dabke音乐形式与电子乐器相结合。"Sham"是大叙利亚、叙利亚-
巴勒斯坦或黎凡特地区的阿拉伯语名称。"Shamstep "一词是由约旦-巴勒斯坦乐队47Soul创造的，用来描述他们的音乐。



Shamstep被描述为
"不仅仅是时髦的东西方融合的代名词。在47Soul的家乡地区，它正在成为阿拉伯青年的背景音乐的一部分。"乐队曾表示，他们认为Sham地区
"太过分裂，有边界......。在1947年，它可以在我们的小城市之间旅行......我们仍然把它看作是一个整体。"47
Soul的音乐也被定义为与非洲裔美国音乐风格的融合，如Hip Hop和Reggae，由于阿拉伯和非洲音乐之间的一些相似之处
。其他使用电子乐器演奏类似形式的Dabke的音乐家包括Omar Souleyman，以及像Islam Chipsy这样的埃及团体，他们的音乐被视为埃及new
wave 的一部分，称为Shaabi或Electro Shaabi。Rhythmpassport.com网站将所有这些形式归入 "electro Dabke
"的标题下。AlAraby将47 Soul的音乐描述为 "对传统阿拉伯乐器、调式音阶和chubi和mijwiz婚礼音乐中的节奏的重新诠释--
在埃及的electro-shaabi 场景中也是如此"。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=364
