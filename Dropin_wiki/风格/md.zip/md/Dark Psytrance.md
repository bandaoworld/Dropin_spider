#Dark Psytrance
##基本信息
###发源时间：
###风格类型：Psychedelic Trance
##详情
Dark Psychedelic Trance（也叫dark psytrance, darkpsy或dark-trance）是psychedelic
trance中较重,较暗黑的一部分，其节拍在148bpm或以上。相关的风格包括 include psycore (fast and crazy)，hi-
tech (bouncy and glitchy)和forest (organic and
earthy)。它以隐晦、深刻和末世感为特点，辅以忧郁的声音和沉重的低音，使人进入关于死亡、夜晚和超神的冥想世界。这种亚流派的通常用于恐怖片采样，而科幻片则更多地用听起来更"正常"的psytrance。德国艺术家Xenormph，马克*佩特里克，被认为是dark
psytrance的先驱，他的专辑《卡桑德拉的噩梦》（Cassandra's Dream）于1998年发行，对这一亚流派产生了重大影响；X-Dream's
Radio是另一张1998年的专辑，在更早期产生影响。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Psychedelic_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=175
