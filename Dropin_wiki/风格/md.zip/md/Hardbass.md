#Hardbass
##基本信息
###发源时间：Late 1990s
###风格类型：Pumping House
##详情
Hardbass或Hard Bass是1990年代晚期起源于俄罗斯电子音乐的曲风。 Hardbass的灵感来源于UK hard
house、Techno、Scouse
House、Powerstomp和Hardstyle，拥有快节奏（通常为150-175bpm），独特的低音（通常被称作是"Hard
Bounce[强硬的跳跃]"），失真的声音和少许的饶舌。



Hardbass已经成为Gopnik（Гопник）亚文化的核心标志性印象。在欧洲几个国家，有很多Hardbass场面，这是另一种亚文化，许多人会配合Hardbass音乐在公开场合跳舞，有时候会见到一群人聚在一个区域跳舞著。



从2015年开始，Hardbass也以互联网梗的形式出现，以GSC游戏世界的S.T.A.L.K.E.R.系列游戏为蓝本的视频 "Cheeki Breeki
Hardbass Anthem "首发，描绘了斯拉夫和俄罗斯的亚文化。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Hardbass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=91
