#UK Funky
##基本信息
###发源时间：Mid-2000s
###风格类型：UK Garage
##详情
UK funky（有时也被称为UKF或funky）是一种来自英国的舞蹈音乐流派，深受Soulful house、soca、tribal house、UK
garage、break beat和grime的影响。通常情况下，UK funky融合了节拍、贝斯循环和合成器与非洲和拉丁打击乐的dem
bow节奏和当代R&B风格的人声。



**特点**

UK funky使用130bpm左右的节奏。鼓的模式在不同的音轨之间变化，使用 "4 to the floor
"或切分节奏。鼓的模式通常还包括非洲打击乐演奏。乐器种类繁多，但鼓机和合成器是常见的。在节奏、音乐和人声风格上与garage有相似之处。UK
funky受tribal、soulful和bassline house子流派的影响很大。类似的风格包括Afrobeats, broken beat,
electro and garage。

  
**历史**

美国的House制作人如Masters At Work、Karizma、Quentin Harris和Dennis Ferrer都对UK
funky产生影响。这一类型的歌曲包括Crazy Cousinz的歌曲 "Do You Mind?"、"Bongo Jam "和 "The Funky
Anthem"，以及Fuzzy Logik以埃及的 "In The Morning "为特色。



流行歌曲还产生了舞蹈热潮，如 "Heads Shoulders Knees and Toes", "The Tribal Man Skank" and
"The Migraine Skank"。其他著名的艺术家包括Apple、Marcus Nasty、Tribal
Magz、Donae'o、KIG、Roska、Champion、Ill Blu、Lil' Silva和Funkystepz。



在UK funky中扮演重要角色的DJ和MC包括DJ Pioneer、Supa D、MA1、Cameo、NG、MC Kaos Spidey
G、Coldstepz和Dogtaniaun & Versatile。



Funky Dee在2009年录制的 "Are You Gonna Bang Doe? "取得了主流的成功，并被环球音乐集团签约。这首歌被Ed
Sheeran在2010年与 "Nando's Skank "Example一起的freestyle中插播，后来被Sun Bingo插播到2018年的
"Are You Gonna Bingo？"广告活动中。这首歌曲被蒂姆-韦斯特伍德描述为 "夏天的配乐"，"取代了俱乐部中的 "Too Many
Man""，被TRENCH杂志描述为 "Ayia Napa anthem"。而评论家包括Vice的Sam
Diss，他认为这仅仅只是几首常规的曲目之一，"实际上证实了,一首将很快成为这个国家里的新奇配乐，最终导致它的消亡"，而Marcus
Nasty则声称它为这种风格成为 "儿童音乐 "做出了贡献。



2011年，人气歌手Katy B与Ms. Dynamite 在一首名为 "Lights
On"的歌曲中进行了二重唱。这首歌在英国单曲榜上排名第四，也是英国第一首在英国上榜的UK funky歌曲。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/UK_funky
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=134
