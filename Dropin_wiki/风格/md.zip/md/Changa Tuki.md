#Changa Tuki
##基本信息
###发源时间：Early 1990s - 2000s
###风格类型：House
##详情
Changa tuki（又称Raptor
House）是起源于委内瑞拉的House音乐子风格和文化。它是一种源于电子音乐的生活方式、舞蹈和音乐流派，90年代初起源于委内瑞拉加拉加斯，直到2000年代末，它一直是一股强劲的潮流，并存在于派对中。Changa文化与其他流派如雷鬼、萨尔萨、emo等一起，是委内瑞拉人民之间的一大主流。它的舞者和支持者被称为tuki（s）。它的舞蹈是一种贫民窟舞蹈的风格。



他们的服装风格特殊，大多穿着紧身的红色裤子，无袖衬衫，几乎遮住眼睛的帽子，Air
Jordan风格的耐克鞋，并用过氧化氢喷涂胡须和发梢。城市文化，绝大多数与贫穷阶层有关，特别是与诡计和暴徒有关。



这种风格的创造者和最知名的DJ是DJ Baba和DJ Irvin，其他具有代表性的DJ有Pacheko，Pocz。在最受追捧的舞者中，我们可以提及Elber
El Maestro等。



葡萄牙DJ Buraka Som Sistema喜欢Changa tuki，并演奏了许多这种风格的歌曲，还进行了创作。美国DJ Scoop
DeVille也表达了他对这种运动的喜爱，他说 "他对此产生了真正的热情"。



加拉加斯最著名的聚会场所是Adrena，人们在这里伴随tuki音乐跳舞，并且有优秀的DJ和歌手。



另外，当时很多人把tuki这个词与冒犯联系在一起，认为大多数tukis其实是委内瑞拉式的暴徒。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Changa_tuki
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=44
