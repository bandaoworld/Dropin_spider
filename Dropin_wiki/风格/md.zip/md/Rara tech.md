#Rara tech
##基本信息
###发源时间：Early 2010s
###风格类型：Electronica
##详情
Rara tech是一种融合了Afro-Haitian流派rara和house音乐的电子音乐子流派。在Haitian，Haitian-style
electronic dance music（EDM）通常被称为 "HEDM"（海地电子舞蹈音乐）。这一流派和术语的起源是由海地艺术家、音乐制作人和 DJ
Gardy Girault开创的。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=363
