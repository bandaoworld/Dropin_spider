#Trap EDM
##基本信息
###发源时间：2010s
###风格类型：Pop EDM
##详情
EDM Trap是一种流行电子舞曲（EDM），起源于21世纪末和2010年初。
它与影响它的发源流派Trap音乐共享一个名称，最初源自南部嘻哈，后来许多的艺术家把Trap音乐融入流行音乐和EDM。



**发展历史**

2012年，出现了一种电子舞曲（EDM）融合了Trap音乐的元素，并开始越来越受欢迎。这些新的舞曲结合了嘻哈音乐的低音贝斯、脚踏钹以及Dubstep的节奏，创造出「肮脏且侵略性的节拍，黑暗的旋律」。电子音乐制作人，如TNGHT、Baauer、RL
Grime和Flosstradamus扩大了此类音乐的人气，并引起了对Trap音乐衍生形式的广泛关注。这种音乐类型使用了铁克诺、Dub和浩室音乐的声音素材与Roland
TR-808的鼓声和典型Trap音乐的声音样本相结合。



在2012年下半年，各式各样的Trap音乐变得越来越受欢迎，并对美国电子音乐界产生了明显的影响。音乐最初被制作人和粉丝简称为"Trap"，导致"Trap"一词同时被说唱歌手和电子音乐制作人使用，两者的粉丝非常容易混淆。后来为了分别两者的差异，电子舞曲制作人开始用"EDM
Trap"来标记这种新的曲风。 "Trap-house"和"Trapstep"这两个术语通常由制作人标记，以描述单个音轨的音乐结构。随着EDM
Trap的发展和与Dubstep的融合，这种新曲风被认为将在2010年代接替Dubstep的地位。通常音乐的速度大约在140 BPM，低音强劲。



2013年，制作人Baauer的歌曲"Harlem Shake"（常译为：哈林摇），被Joji制成粉丝影片，成为了因特网迷因，该曲目成为Billboard
Hot 100上第一首登上第一名宝座的EDM Trap。这个迷因挑战包括一个人按照歌曲的节奏跳舞直到Drop，然后影片中的其他人将跟随着这个人跳舞。



五个EDM Trap制作人在2013年美国的超音乐节上演出，包括DJ Craze、Baauer和Flosstradamus。
2013年的明日世界音乐节特别客串了一个「Trap舞台」。



2013年2月10日，All Trap Music发行了他们的首张专辑，其中包括来自RL Grime、Flosstradamus、Baauer、Bro
Safari和12th
Planet等制作人的19首曲目，将其描述为同类型中的第一张专辑。它在iTunes舞曲排行榜上排名第二，Vibe杂志声称它是「有史以来全球最畅销的EDM
Trap专辑」。2013年，DJ Snake和Lil Jon发布了单曲"Turn Down For
What"，这首歌在好几个国家都登上热门排行榜并且成为热门话题，滚石杂志投票将其选为2014年第二名的歌曲。



EDM Trap在国际上享有盛名，特别是在韩国。2014年11月，来自韩国男子音乐组合BIGBANG的G-
Dragon和Taeyang发行了他们的单曲"Good
Boy"，其中融入了大量的Trap和电子音乐元素。单曲在不到24小时内获得了200万次观看，并得到了音乐评论家的积极评价。2015年6月，当BIGBANG发布他们的热门单曲"Bang,
Bang, Bang"时，EDM Trap再次在K-
pop领域获得关注，该单曲在韩国取得了商业上的成功，在2015年8月之前销售了超过100万张的数位单曲。2019年4月，韩国女子音乐组合Blackpink发行了专辑"Kill
This Love"，其中的同名主打单曲在不到24小时内获得了5670万次观看，随后登上了Billboard Hot 100排行榜。



Trap 在 2010 年末开始与Synthpop 和 emo 流行音乐融合，当时费城制作人团体 Working on Dying
开始制作弗朗西斯维尔说唱歌手 Lil Uzi Vert 的第三张录音室专辑 Eternal Atake。Working on Dying的 Brandon
Finessin 被署名为 Lil Uzi Vert 的 emo 说唱专辑的八首作品的制作人，他在传统的Trap鼓序列中添加了 hyperpop 和 EDM
元素。 这使得 Lil Uzi Vert 和 Brandon Finessin 合作领跑公告牌Producers and Songwriters Top
100排行榜。这也让 YouTube 小制作人根据 Working on Dying 的电子Trap音乐制作方法出现了 hyperpop trap beat
的分支场景。



2010 年代后期也出现了一种新的Trap音乐子流派，称为Trapwave（或Hardwave），它将Trap音乐与Synthwave融合在一起。

###本词条内容主要来自 https://zh.wikipedia.org/zh-tw/EDM_Trap
部分汉字内容由 @多频百科团队 翻译+编辑
原文译自 hhttps://en.wikipedia.org/wiki/Trap_music_(EDM)
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=35
