#Hip House
##基本信息
###发源时间：Mid–late 1980s
###风格类型：House
##详情
Hip House，又称说唱浩室或浩室说唱，是一种混合了House音乐和Hip Hop元素的音乐类型，20世纪80年代中后期起源于英国伦敦和美国芝加哥。



**历史**

1988年，Tyree在美国发行了一张名为 "Turn Up the Bass "的唱片，由Kool Rock Steady演唱，并宣称这是
"第一张黑胶唱片中的hip house唱片"，随后引起了不小的争议。Beatmasters对此提出质疑，指出 "Rok da House
"最初是在1986年写成并压成黑胶唱片的。随后，他们又推出了由英国主持人Merlin演唱的 "Who's in the House?"，其中包含了
"Beatmasters stand to attention, hip house is your invention "和 "Watch out
Tyree, we come faster "的歌词。随后，Fast Eddie "Yo Yo Get Funky!"、Rob Base和DJ E-Z
Rock "It Takes Two "以及Tony Scott "That's How I'm Living "等人也为Hip-
House冠冕立下汗马功劳。



在Beatmasters、Deskee、Tyree、KC Flightt、Doug Lazy和Mr.Lee成功发行之后，Hip-
House在酸性浩室仓库场景和夜总会中开始流行。Hip House也获得了大量的榜单成功。这种风格与当时的采样唱片相辅相成，由S-Express、Bomb
the Bass和M/A/R/R/S等艺术家制作。



Hip House的进一步成功是以两张突破性唱片的形式出现的。丛林兄弟的 "I'll House You "和Rob Base和DJ E-Z Rock的
"It Takes Two"。"I'll House You "一般被看作是纽约市house-music制作人Todd Terry和Jungle
Brothers（一个来自纽约的非裔嘻哈团体）的合作。"It Takes Two "被《Hip Hop
Connection》杂志描述为"......硬核嘻哈迷的第一种可接受的hip-house形式"。



嘻哈说唱歌手逐渐开始接受Hip House的混音处理，包括Vitamin C，Sweet Tee，Raze和D.O.C.



Hip House歌曲也开始出现在流行的舞蹈汇编中，包括Telstar的Deep Heat汇编系列，并受到DJ如To Kool Chris和Chad
Jackson的支持。



到了80年代末，随着House音乐在世界范围内的兴起，美国的C+C Music Factory等乐队会在 "Gonna Make You Sweat
"等歌曲中使用Hip House配方，同时也会在Eurodance风格中使用Hip House元素--
尤其是比利时Technotronic、德国Snap！和意大利Lee Marrow的歌曲。



**对英国rave场景的影响**

英国艺术家发行的Hip house，如Double Trouble和Rebel MC，Blapps Posse和the Adventures of
Stevie V，是对1990年代英国rave场景和breakbeat hardcore流派（以及由它发展而来的流派，如jungle）的早期影响。



**现代Hip House**

Hip House的现代形式在2000年中后期开始流行，许多艺术家在世界范围内获得了主流的成功。Electro和Hip
House的融合（也被称为Electro
Hop）被证明是非常流行的，并在2000年代末和2010年代初主导了排行榜。这些艺术家包括LMFAO，黑眼豆豆，Pitbull，Flo Rida，Far
East Movement，Hyper Crush，the Streets，Example和Azealia
Banks。其中包括Tiesto和Diplo与Busta Rhymes合作的 "C'mon (Catch 'em by
Surprise)"，以及Wolfgang Gartner和will.i.am的 "Forever"。法国艺术家David Guetta有几首hip
house歌曲，如与Kid Cudi合作的 "Memories"，与Flo Rida和Nicki Minaj合作的 "Where Them Girls
At"，与LMFAO合作的 "Gettin' Over You"，与Taio Cruz和Ludacris合作的 "Little Bad Girl"。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Hip_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=71
