#Outsider House
##基本信息
###发源时间：2010
###风格类型：House
##详情
Outsider house（也被称为lo-fi house，raw house或outsider舞蹈）是电子音乐的一个微流派，结合了Deep
House、Techno和Noise的元素。这种音乐通常是粗糙的，其特点是模糊的鼓声、模糊的合成器和一种淡淡的饱和音质，类似于第四代卡式磁带的质感。



**历史**

" Outsider Dance"一词由DJ Ben UFO和音乐记者Scott
Wilson于2012年首次提出，指的是不同的制作人和唱片公司，例如Laurel Halo，Anthony Naples，以及LIES，Opal等唱片公司。
磁带，未来时报，1080p和龙虾Theremin。 从2016年开始，该流派发展为另一种形式，称为" lo-fi house"。 DJ
Seinfield，DJ Boring，Ross From Friends和Mall
Grab等制作人通过将早期outsider的粗糙声音与蒸汽波产生的忧郁、讽刺和后现代主义美学相结合而广受欢迎，创作了"类似于90年代忧郁的deephouse，录制到卡带上，并被包装成互联网时代讽刺的外衣
"的歌曲，因此便流行起来了。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Outsider_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=81
