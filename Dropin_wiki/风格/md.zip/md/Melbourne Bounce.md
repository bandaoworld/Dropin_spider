#Melbourne Bounce
##基本信息
###发源时间：2010s
###风格类型：Electro House
##详情
Melbourne Bounce是Electro
House的一个子类别，起源于澳大利亚墨尔本，其特征是128-150bpm的节奏，跳跃十足的质感，Dutch House风的号角，tech
trance合成器，电气质感的音色冲击以及混浊的House风Bassline。



Melbourne Bounce已经被用来/制作人包括Deorro，Joel Fletcher，Will Sparks，SCNDL，Reece
Low，VINAI，和TJR等人的音乐。这种风格的特点一般是标准的128bpm，由具有弹性的反拍Bass、嘈杂人声质感的切片或锯齿波音色为lead、喧闹的号角、Drop前的8小节snare
fills等元素组成。Melbournce Bounce经常使用重复的节拍结构，整首曲子中伴随一定数量的build-up和Drop。



Melbourne Bounce最初是Makina、Acid House、Acid
Techno、Psytrance和地下墨尔本House/Minimal风格等元素之间的交叉。Melbourne
Bounce大约在2012年中后期获得了主流的流行，并从2013年开始稳步上升。2014年，Joel Fletcher、Will
Sparks、Uberjak'd等先驱者的作品大受欢迎，他们的歌曲不仅在澳洲商业电台播放，还传播到全球，并与Steve
Aoki、TJR等一起影响着国际EDM风格。



2019年，以韩国制作人和DJ为代表的艺人基于Melbourne Bounce和Minimal Bounce风格延伸出了Korea
Bounce（又称Korean Bounce，Gangnam Bounce）的术语，致力于推广该文化的包括韩国知名Electro/Minimal
Bounce厂牌Moon
Records等。该术语通过互联网得到了较大范围的传播并在夜店场景中有广泛应用，但很多评论认为其在音乐性上不具备构成独立风格的条件。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_house#Melbourne_bounce
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=57
