#Collage
##基本信息
###发源时间：1960s
###风格类型：Musique Concrète
##详情
Collage是Musique Concrete的一种形式，概念已经超越了视觉艺术的界限。



在音乐方面，随着记录技术的发展，从20世纪中叶开始，前卫艺术家开始尝试剪切和粘贴。1960年代，George Martin在制作The
Beatles乐队唱片的同时创建了collages。1967年，pop艺术家Peter
Blake为甲壳虫乐队开创性专辑《Sgt》的封面制作了拼贴画。Pepper的Lonely Hearts Club
Band乐队。在1970年代和1980年代，Christian Marclay和Negativland乐队等人以新的方式重新使用了旧的音频。



到了1990年代和2000年代，随着采样器的普及，"musical collages"已经成为流行音乐的规范，尤其是在rap, hip-
hop和electronic music。 1996年，DJ
Shadow发行了开创性专辑Endtroducing.....，该专辑完全由预先存在的录制材料混合在一起制成，并通过audible
collage制成。同年，New York City艺术家、作家和音乐家Paul D. Miller（又名DJ
Spooky）在博物馆和画廊进行采样，这是一种艺术实践，将DJ文化与作为音源的资料结合起来，体现在他2004年的专辑Songs of a Dead
Dreamer和Rhythm Science和2008年书籍作品麻省理工学院出版社的Rhythm
Science。在他的书中，作者，艺术家和音乐家（例如Antonin Artaud，James Joyce，William S.
Burroughs和Raymond Scott）基于"混音"和collage的混合被称为"声音文学"的一部分。 "2000年，The
Avalanches乐队发行了Since I Left You，属于collage，包含约3500个音乐来源（样本）。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Collage#In_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=261
