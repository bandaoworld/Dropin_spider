#Full-on
##基本信息
###发源时间：
###风格类型：Psychedelic Trance
##详情
Full-On trance是一种psychedelic
trance的子风格，在乐曲氛围高峰时刻有很高的能量，通常旋律性强，精力充沛，拥有清脆的低音和快速的节奏（通常140-148
bpm）。有一些相关的风格是从这个风格衍生出来的，并区分为不同种类的Full-On：twilight和night full-on（或称dark full-
on），它们与标准Full-On的区别在Bassline中有更大胆和低沉的音符，让人有处于晨间的感觉（感觉光明和快乐），并感到振奋。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Psychedelic_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=176
