#Mallsoft
##基本信息
###发源时间：
###风格类型：Vaporwave
##详情
Mallsoft放大了vaporwave的lounge影响。它可以被看作是"大型的商场，没有灵魂的消费主义空间的概念......探索资本主义和全球化的社会后果"。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=345
