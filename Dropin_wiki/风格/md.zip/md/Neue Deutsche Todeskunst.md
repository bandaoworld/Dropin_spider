#Neue Deutsche Todeskunst
##基本信息
###发源时间：Late 1980s
###风格类型：Dark Wave
##详情
Neue Deutsche Todeskunst（NDT，译为 "New German Death
Art"）是20世纪80年代末在德国发展起来的一种音乐流派。它被认为在dark wave运动中建立了德语，虽然当时已经有Xmal
Deutschland、Geisterfahrer和Malaria！等德国乐队。



历史

20世纪80年代末，一些德国音乐家将neo-classical, gothic rock, 和darkwave
风格的音乐与德国哲学文本和高度戏剧化的舞台表演结合起来，他们的音乐以Joy Division、The Cure、Siouxsie and
Banshees等乐队的post-punk, cold wave, 和 gothic rock为基础，以合成器为主的new
wave为基础。这些歌词常常向德国哲学家安德烈亚斯-格里菲斯（Andreas Gryphius）、约翰-沃尔夫冈-冯-歌德（Johann Wolfgang
von Goethe）、弗里德里希-尼采（Friedrich Nietzsche）、戈特弗里德-本恩（Gottfried Benn），以及乔治-
特拉克（Georg Trakl）、埃德加-爱伦-坡（Edgar Allan Poe）、查尔斯-波德莱尔（Charles Baudelaire）、让-保罗-
萨特（Jean-Paul
Sartre）等国际诗人深表敬意。这些团体的音乐会非常强调服装、灯光和烟火技术。这些表演旨在刺激所有的感官，并传达一种整体的黑暗、阴郁的气氛。抒情主题包括短暂、邪恶、虚无主义、超现实主义、表现主义、存在主义哲学、对宗教的批判、暴力、疯狂、孤独、抑郁，尤其是死亡。最伟大的新德国Todeskunst热门歌曲包括Das
Ich（1990）的 "Gottes Tod"，Relatives Menschsein（1991）的
"Verflucht"，Lacrimosa（1991）的 "Der Ketzer"，Goethes Erben（1992）的 "Das Ende
"和Endraum（1992）的 "Regentanz"。许多NDT艺术家都被Danse Macabre唱片公司吸引。

  
起源

"Neue Deutsche Todeskunst "这个词在1991年被Danse
Macabre的唱片公司杂志MagazinOphon首次使用。Zillo杂志的记者Sven Freuen用这个词来形容Relatives
Menschsein、Das Ich和Goethes Erben等乐队。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=318
