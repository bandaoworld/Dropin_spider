#Pumping House
##基本信息
###发源时间：1997
###风格类型：UK Hard House
##详情
Pumping house（或bumping）是早期Scouse
House场景的一个地方变种，在20世纪90年代末到2000年代初流行于俄罗斯和西班牙。在1997年，荷兰二人组Klubbheads创造性的在曲目 "A
Walking Nightmare（Klubbheads GP
Mix）"中使用了所谓的竹管风贝斯音色，成为这种流派开始的标志。几年后，这个流派衍生了英国的Donk现场和西班牙的Poky现场。在俄罗斯，西班牙和波兰，Pumping
House也可以被认为是Scouse House的互换词。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/UK_hard_house#Pumping_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=90
