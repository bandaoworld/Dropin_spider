#Trip Rock
##基本信息
###发源时间：
###风格类型：Electronic Rock
##详情
Trip rock是alternative rock的一种形式，它融合了Psychedelic rock、90年代末的electronica
和密集的dark sound。Trip rock的例子可以在Massive Attack的Mezzanine专辑（Angel - track）和the
Gathering的If_then_else专辑（Analog Park - track）中找到。音乐中的Psychedelic元素大多来自Piper at
the Gates of Dawn / A Sauceful of Secrets时代的Pink Floyd。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=313
