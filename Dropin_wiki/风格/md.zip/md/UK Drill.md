#UK Drill
##基本信息
###发源时间：2012
###风格类型：Drill
##详情
UK Drill是drill music和road rap的一个子流派，从2012年开始起源于伦敦南部的布里斯顿区。受Chicago drill
music风格的影响，UK
drill音乐人说唱的主题包括暴力和享乐主义的犯罪生活。通常情况下，创造这种音乐风格的人隶属于帮派或来自社会经济贫困的社区，在那里犯罪是许多人的生活方式。UK
drill 与Road rap有很大的关系，这是一种英国风格的帮派说唱，在drill存在之前的几年里就已经开始流行。在音乐上，UK
drill常常表现出暴力的语言、多样的抒情以及随之而来的激烈竞争。著名的先驱包括postal-code crews 150, 67
（均位于Brixton或附近）和86.自2016年以来，出现了更多现代团体，如814、Silwood Nation、Block 6、Y.ACG、Zone
2、BSide、Moscow17、CGM（原1011）、12World、SMG、OFB、NPK和Harlem Spartans。UK
drill团体依靠互联网平台来传播他们的音乐，尤其是在YouTube上，Link-Up TV、GRM Daily、SB.TV、Mixtape
Madness、PacMan TV和PressPlay Media等平台帮助各个团体积累了数千，有时甚至数百万的浏览量。UK
drill形成了与Chicago drill不同的制作风格，受到早期英国风格如grime和UK garage的影响，以至于被称为
"新Grime"，drill制作人卡恩斯-希尔评论说，它需要一个新的名字。不过，UK Drill制作人马扎却不同意 "new grime
"的标签，他认为，虽然drill和grime有着相同的能量、生猛，起源方式也很相似，但两种风格有各自的特点。与芝加哥的同类音乐相比，UK
Drill的节奏一般比较快。乐器往往也有滑动的贝斯、重击的踢腿和暗黑的旋律。AXL
Beats解释说，808的和快节奏的snares是grime音乐的衍生品.这两种类型通常利用大约140 bpm的节奏。UK
Drill团体经常互相争执，有时是暴力的，经常发布多个diss曲目。著名的纠纷包括Zone 2对莫斯科17，150对67
OFB/NPK对WG/N9和SMG对814（814的一名成员Showkey在2016年的一次无关事件中被刺死）。2017年，当喜剧演员Michael
Dapaah发布了新奇歌曲Man's Not Hot时，UK Drill受到了全世界的关注。这首歌曲采样了UK
Drill制作人GottiOnEm和Mazza制作的节拍；这首歌曲最早被drill团队86用在其歌曲《Lurk》中，后来67用吉格斯的《Let's
Lurk》。

###本词条内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drill_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=301
