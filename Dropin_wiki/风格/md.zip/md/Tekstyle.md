#Tekstyle
##基本信息
###发源时间：
###风格类型：Hardstyle
##详情
Tekstyle是由Jumpstyle融合Hardtek元素而形成的一类Hardstyle音乐子风格，这类风格发展的历史不长，但有可观的受众群体和成长空间。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=193
