#Merenrap
##基本信息
###发源时间：
###风格类型：Hip Hop Music
##详情
Meren(gue)house/Merenrap是一种融合了merengue music、House、Hip Hop和Caribbean
music而形成的嘻哈音乐风格。



**历史**

上世纪80年代在纽约市形成了被称为 merenrap, merenhouse或Latin house的混合音乐。企业家Jorge
Oquendo鼓励艺术家们将这些流派混合在一起。 Lisa M 在1990年首发的第二张专辑中混合了merengue 和rap。 Latin
house结合了house music, rap, Latin 节奏和Caribbean音乐。Dominican
Merengue音乐可以被认为是多米尼加跨国主义的一种表现形式，因为在20世纪，多米尼加人向纽约市的移民发生了重大转变。Merenhouse
作为一种音乐的混合体，受到在纽约市成长起来的具有多米尼加血统的一代双文化青年的欢迎也就不足为奇了，这种音乐结合了他们文化的两个方面。对多米尼加裔美国人来说，Merenhouse是民族身份的象征，很容易被一种兴奋的声音所识别。



20世纪90年代初，主要由于多米尼加共和国在80年代和90年代初的经济状况大大恶化，从多米尼加共和国到美国的移民大量增加。纽约市见证了这一初期多米尼加人口增长的大部分，一旦这些首批多米尼加移民安顿下来，纽约市就成了美国多米尼加文化的中心。"到1990年，估计有90万多米尼加人仅居住在纽约市，占全国人口的12%"。多米尼加人也
"往往更集中地专门居住在像华盛顿高地-
英伍德这样的贫民区，在移民局登记的多米尼加人中，59%的人居住在这里"。这种强大的多米尼加人集中在一个地方，使他们在融入纽约市文化大熔炉的同时，也带来了自己的文化。Merengue是在这一移民时期带来的众多多米尼加文化中的一个例子，这也是Merenhouse创立的关键因素。有影响力的艺术家Lisa
M是第一位主要的拉丁女说唱歌手。她的第二张专辑《No Lo Derrumbes》中的歌曲 "Tu Pum-Pum
"是第一首merenrap歌曲。该专辑于1990年发行。Los
Ficos是一支混合了Merengue、R&B和HipHop的Merengue说唱乐队。Fulanito是一个来自多米尼加共和国的Merenhouse乐队。他们是最早将Merengue舞曲和House音乐结合起来的团体之一，获得了广泛的赞誉，在全世界销售了约200万张专辑。Proyecto
Uno是一个多米尼加-美国的Merengue乐队，它帮助普及了一种融合了Merengue 和rap, techno, dancehall reggae, 和
hip hop的音乐风格。该团体赢得了Billboard拉丁音乐奖，Premios Los Nuestro和艾美奖。Ilegales（也叫Los
Ilegales）是一个格莱美提名的多米尼加Merenhouse三人组。他们登上了Billboard Tropical排行榜，并被提名为拉丁格莱美奖的
"最佳流行专辑"。Dark Latin Groove（简称DLG）是一支混合了salsa, reggae, reggaeton, 和hip
hop的萨尔萨乐队。该乐队曾获格莱美奖 "最佳热带专辑 "和Premio Los Nuestro奖 "最佳热带团体 "提名。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Merenrap
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=287
