#Post-Dubstep
##基本信息
###发源时间：early 2011
###风格类型：Dubstep
##详情
Post-Dubstep（有时被称为"UK bass"或简称"bass
music"）最初于2011年前后被用来描述受dubstep某些方面影响的俱乐部音乐。这类音乐经常参考早期的dubstep作品以及UK
garage、2-step和其他形式的地下电子舞曲。制作post-dubstep音乐的艺术家也融入了ambient music
和早期R&B的元素。典型的post-dubstep音乐的节奏大约是每分钟130拍。2010年后兴起的Future Garage、Witch
House等风格也常被视为Post-Dubstep运动的分支。



与"post-dubstep"一词相关联的风格之广，使其无法成为一种特定的音乐体裁。Pitchfork的作者Martin
Clark曾表示，"善意地试图松散地定义我们在这里所涵盖的领域是有点徒劳的，几乎可以肯定是有缺陷的。这不是一个流派。然而，考虑到其中的联系、互动和自由流动的想法......你不能把所有这些行为都视为无关紧要的。"制作组合Mount
Kimbie经常与术语post dubstep的起源联系在一起。英国音乐制作人Jamie xx推出的混音被认为是post-dubstep，包括Gil
Scott-Heron的混音专辑《We're New Here》（2011）。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Post-dubstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=162
