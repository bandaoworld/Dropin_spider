#Livetronica
##基本信息
###发源时间：Early-1990s
###风格类型：Electronica
##详情
Livetronica，也称为Jamtronicam, Electro-jam，是一种融合了即兴乐队元素和电子乐元素的音乐风格。 这个名字是"Live
Music"和"Electronica"这两个词的融合。

###本词条内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/livetronica/wiki
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=351
