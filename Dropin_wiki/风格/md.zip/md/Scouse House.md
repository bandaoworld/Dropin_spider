#Scouse House
##基本信息
###发源时间：Late 1990s to early 2000
###风格类型：UK Hard House
##详情
Scouse house（原名为bouncy hard house或bouncy house），也被称为UK bounce，donk，或最近的hard
bounce，是1999年前后出现的一种UK Hard House风格。与其他Hard
House风格不同的是，它的特点是节奏感强、精力充沛，并且高度关注使用特色的"Pipe" 采样作为Offbeat Bassline，这通常代表"
donk"的声音。



近年来，hard bounce的术语被用于形容远不如原来的Scouse house那么含有uplifting
trance的取向的风格，这类风格也利用了同样的采样，但采取了稍微更商业化的方式。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/UK_hard_house#Scouse_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=92
