#Hipster Hop
##基本信息
###发源时间：Early to mid-2000s (decade)
###风格类型：Alternative Hip hop
##详情
"Hipster hop"是Hipster和hip hop两个词的合成词，是alternative hip
hop的微流派，更确切地说，是"融合独立摇滚风格的hip-hop"。它也被称为hipster rap。



**词源**



评论家Matt Preira在《Miami New Times》上撰文称，hipster-
hop构成了"说唱音乐中一个明显的过渡"，它融合了hipster文化的元素。Preira称这是"一种酝酿中的微体裁，随时准备席卷主流"。芝加哥的读者评论家Miles
Raymer说，潮人说唱"玩弄着老派的象征"，但这种潮人说唱"体现了与老派嘻哈一样的乌托邦式、大帐篷式理想"。根据雷默的说法，它是"说唱音乐和舞蹈音乐相互作用的前沿"，同时被定义为嬉皮士的时尚和态度。



**特征**

总之，"潮人"说唱的特点是模糊了"纯"说唱、嘻哈、节奏布鲁斯、流行和摇滚之间的界限"。评论家们经常把它与西雅图和华盛顿的乐队联系起来，如Mad
Rad，尽管该乐队否认他们的音乐属于这种类型。



###本词条汉字内容由 @多频百科团队 翻译+编辑
https://en.wikipedia.org/wiki/Hipster_hop
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=279
