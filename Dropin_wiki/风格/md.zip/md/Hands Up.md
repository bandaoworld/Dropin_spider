#Hands Up
##基本信息
###发源时间：20世纪90年代中后期
###风格类型：Eurodance
##详情
Hands Up(有时也称为 Handz Up!或HandzUp
!(在东欧也被称为Dancecore)是Eurodance的一个分支流派。这种音乐类型来源于它的名字，意思是要求听众"举起手来"的音乐，同时也要求适宜性和舞蹈性。



Hands Up在20世纪90年代中后期和21世纪初期起源于德国，在那里它从Eurodance和各种其他dance流派(如happy
hardcore和techno)发展而来。这也是这一流派得名的时期。Starsplash和Mark
'Oh是Eurodance的代表，有时也被认为是Hands
up的先驱。在两千零几年之前，Scooter的热门单曲Nessaja在单曲榜上排名第一，获得了这种音乐最大的商业成功。
合成器的旋律往往朗朗上口，简单易懂，通常人声由合成器伴奏。与Techno相比，它使用的是短高音调的合成器。Hands
Up唱法并不依赖于结构累积，而是基于典型的诗歌-合唱-流行音乐方案。主要元素是低音、鼓声和朗朗上口的引音（lead
sound）一种典型的风格是女声或由此产生的女声，男声也很常见。此外，扭曲、自调谐、短切和重复的口语短语也是共同的特征。





###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Eurodance#Hands_Up
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=224
