#Folktronica
##基本信息
###发源时间：1990s–2000s
###风格类型：Electronica
##详情
Folktronica是一种音乐流派，由各种民乐和电子音乐元素组成，通常以使用声学乐器----特别是弦乐器----
为特色，并结合了嘻哈、电子或舞蹈节奏，尽管它因声音的影响和选择而有所不同。"Ashgate Research Companion to Popular
Musicology "将Folktronica描述为 "一个包罗一切的，指所有将机械舞蹈节奏与原声摇滚或民谣元素结合在一起的艺术家"。



1991年群青乐队(Ultramarine)的专辑《Every Man and Woman is a
Star》被认为是这一流派的鼻祖；它以田园的声音为特色，并将小提琴和口琴等传统乐器与techno和house元素相结合。
根据《星期日泰晤士报》文化版的《现代音乐百科全书》，该流派的重要专辑有《Four Tet's Pause》（2001年）、《Tunng's Mother's
Daughter and Other Songs 》（2005年）和Caribou的《The Milk of Human Kindness
》（2005年）.美国歌手麦当娜的第九张录音室专辑《American Life》深受该流派的影响，并在Billboard 200排行榜上名列第一。



2010年代，alt-J和Bon Iver等Folktronica艺术家成为主流。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=347
