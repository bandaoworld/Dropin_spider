#Slap House
##基本信息
###发源时间：2010s末期
###风格类型：Deep House
##详情
Slap House 是 2010 年代后期开始发展的隶属于 Deep House 的子类型。Slap House 曲目的速度通常在 120 bpm
左右，采用 4/4 拍节奏。Slap house 与 Brazilian Bass
密切相关，在听感上也高度相似。二者在乐器和音色配置上都追求简化，以为极具张力的标志性 Bass Pluck
和调制音色预留表现的空间。其名称中的"Slap"一词也来源于 Bass 音色接近乐器贝斯演奏中使用Slap（大拇指拍打）技巧而发出的音效。与面向俱乐部舞池的
Brazilian Bass 相比，Slap House
的声音设计没有那么夸张，Bassline有很强的存在感但并没有过强的侵略性，旋律（通常还有较多的人声部分）也更加优美和得到重视，并且包含更面向电台播放的元素。



该类型在 2020 年前后开始出现爆发式的流行，在全球范围内都受到广泛的关注。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=48
