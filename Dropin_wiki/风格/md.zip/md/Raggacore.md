#Raggacore
##基本信息
###发源时间：
###风格类型：Breakcore
##详情
Raggacore是一种源于Ragga
Jungle的音乐风格，在某种程度上它比Breakcore还要早一些，其特点是Ragga和Dancehall的节奏和人声。其根源可以说可以追溯到Jungle制作人Remarc，他是第一批将Ragga和Dancehall的人声与混乱的、复杂的重新排列的Break节拍相混合的制作人之一。
虽然只有少数制作人主要从事这种风格的工作，但它在breakcore迷中仍有相当大的追随者。



这种风格的突出艺人代表包括Aaron Spectre, Bong-Ra, Cardopusher, Enduser, FFF, LFO Demon,
Renard Queenston, Lemon Drizlay Crew, Ruby my Dear, Istari Lasterfahrer,
Shitmat, Venetian Snares, 以及来自the Life4Land crew的Stivs.

###本词条汉字内容由 @多频百科团队 翻译+编辑
内容源自 https://en.wikipedia.org/wiki/Breakcore#Raggacore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=198
