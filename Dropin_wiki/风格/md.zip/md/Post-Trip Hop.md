#Post-Trip Hop
##基本信息
###发源时间：mid-1990s
###风格类型：Trip Hop
##详情
Post-Trip Hop（后神游舞曲）是Trip Hop音乐进入21世纪后经发展和演化所表现出来的新形式。在1990年代中期Trip
hop取得初步成功后，"Post-Trip hop"艺术家包括Baby Fox、Bowery
Electric、Esthero、Morcheeba、Sneaker Pimps、Anomie
Belle、Alpha、Jaianto、Mudville以及Cibo Matto和Lamb等将Trip
hop融入到其他流派中，包括Ambient、Soul、IDM、Industrial、dubstep、breakbeat、Drum and Bass、Acid
Jazz和New Age。首次在印刷品中使用 "Post-Trip Hop "一词是在2002年10月《独立报》的一篇文章中，被用来描述乐队Second
Person。







###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Trip_hop#"Post-trip_hop"
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=122
