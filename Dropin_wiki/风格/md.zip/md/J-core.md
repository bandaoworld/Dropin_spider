#J-core
##基本信息
###发源时间：
###风格类型：Hardcore
##详情
J-core是20世纪90年代末以来与日本团体和DJ有关的硬核电子乐风格。
它的特点是使用来自电子游戏和动漫的采样，色彩鲜艳的卡哇伊图像和专辑图形，以及从Denpa和otaku文化中借用的一般元素。这种风格在视频游戏中很有特色，如Beatmania
IIDX，并形成了doujin音乐场景的一个重要部分。



DJ
Sharpnel被认为在1998年开创了这种风格，在21世纪初，这种风格通过日本的点对点网络传播。随着动漫在美国和欧洲的流行，J-core也在那里的动漫迷中得到赞赏，使得西方的、受J-
core启发的混音文化得以发展，以及J-core对2010年代初的nightcore现象的贡献。



**著名制作人**  

DJ Chucky

DJ Sharpnel

IOSYS

m1dy

REDALiCE

t+pazolite

Techn0rch

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.m.wikipedia.org/wiki/J-core
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=210
