#Jungle Terror
##基本信息
###发源时间：2010s
###风格类型：Electro House
##详情
Jungle Terror是在2010年代发展起来的一种电子音乐类型，它通常被描述为 "混乱 "的House，Grime和Drum 'n'
Bass节奏的融合。同时也有动物声音，人声切割和打击乐等元素。听感上给人以在热带丛林中紧张神秘，部落氛围笼罩的体验。



荷兰DJ和音乐制作人Wiwek被认为是该流派的创始人，他在2013年至2016年间的作品使这种风格在EDM领域中广受欢迎。同时，Skrillex、Diplo和KURA等知名制作人的作品也与该流派有关联。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_house#Jungle terror
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=56
