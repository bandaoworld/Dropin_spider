#Diva House
##基本信息
###发源时间：1990s
###风格类型：House
##详情
Diva House（又称Handbag
House）的一种形式，在1990年代下半叶在同性恋俱乐部中最受欢迎。它是电子舞蹈音乐中最主流，最容易接受的子流派之一。
《当代英国文化百科全书》将其定义为"具有突出的女性嗓音，分解和大量的钢琴'刺'"。 现代Diva浩室的作品多使用合成器和4/4节奏。



**背景**

"diva house "一词早在1992年7月就开始使用，当时Billboard杂志将Dee Dee Simone的 "What Are We
Doin'"描述为 "铁肺天后屋"。它以轰轰烈烈的中性人声著称，有时从其他唱片中取样。这种采样来自于灵魂乐、迪斯科、福音唱片，甚至是由贝蒂-米德勒、朱迪-
加兰、莉莎-明奈利等歌手和其他同性恋偶像演唱的表演曲。这种轰轰烈烈的风格可以包括舞蹈专家表演的歌曲（见艺术家），也可以包括Patti
LaBelle、Aretha Franklin、Mariah Carey和Whitney Houston等歌手对流行歌曲的俱乐部混音。



在英国的舞中，"handbag house "这个词似乎特别流行，它指的是一群女性舞者围着一堆手袋跳舞的概念。舞蹈文化对 "handbag house
"这个词的使用，一开始是作为一个贬义词。



在20世纪90年代，随着同性恋俱乐部和同性恋文化成为主流，House音乐也成为主流。diva
house的普及导致了同性恋俱乐部音乐的主流化。特别是在英国，diva house成为俱乐部文化的象征。根据音乐历史学家Bill
Brewster和Frank Broughton的说法，到了90年代中期，diva house帮助俱乐部成为
"主流休闲活动"。随着90年代同性恋文化的主流化，"diva "这个词将house音乐与同性恋舞池捆绑在一起，而此前只有意大利迪斯科舞曲才能定义这个舞池。



音乐评论家西蒙-雷诺兹（Simon Reynolds）断言，diva House
"最初是一个贬义词，是由居高临下的认知者相对于据称对女性有吸引力的、穿透榜单的House曲调，尤其是对莎伦和特蕾西的民间神话构造所创造的。"
根据电子音乐制作人Ewan Pearson和学者Jeremy Gilbert的说法，"diva house "经常被舞曲迷嘲笑为 "塑料迪斯科"，他们更喜欢
"更深奥的音乐声音，这些音乐摒弃了旋律和口头语言的'主流'音乐重点"。diva
house的主流吸引力导致地下舞曲纯粹主义者涌向硬包、前卫浩室、深度浩室和车库浩室等衍生流派。"社会学家Dunja Brill认为，对diva
house的批评带有 "在俱乐部文化表述中对'diva house'这一被诋毁的主流的厌恶性倾斜，而Ravers正是针对这一主流定义他们的亚文化。
"布里尔认为，对diva house的偏见 "最明显地表现为对流行文化中被诋毁的'主流'的女性化，而亚文化正是针对这种主流来定义自己的"。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Diva_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=49
