#Dubstyle
##基本信息
###发源时间：2010
###风格类型：Hardstyle
##详情
Dubstyle是2010年初Hardstyle引入的新的变体，是hardstyle和dubstep的融合风格的名称。Dubstyle倾向于使用反拍Wobble
Bassline，并采用hardstyle标志性的Kick，同时将它们与节奏、律动和dubstep节拍结合，并融合其它hardstyle的元素与dubstep节奏，通常是2-step或breakstep节奏。Dubstyle自最初出现后，至2010年代中期并未出现太多演化和发展。



###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Hardstyle#Dubstyle
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=186
