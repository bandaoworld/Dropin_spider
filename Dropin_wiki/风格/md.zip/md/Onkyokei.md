#Onkyokei
##基本信息
###发源时间：Late 1990s
###风格类型：Reductionism
##详情
Onkyo音乐运动又名Onkyokei（意为声音的混响）是一种自由即兴创作音乐形式，1990年代末在日本出现。Onkyō可以翻译为"声音，噪音，回声"。通常与Onkyō有关的艺术家包括中村俊丸、秋山哲图、Sachiko
M和杉本拓等。



The Off
Site位于东京，是Onkyo音乐运动的发源地，其特点是即兴创作、极简主义和"安静的噪音"。Onkyo即兴创作"探索了声学和电子声音的细密纹理细节"。



它影响了Electroacoustic即兴演奏的发展以及EAI，一个和Onkyo有很强联系的流派。Onkyo的跨国传播也影响了它作为一种"日本新音乐"的表现形式，尽管它的作者声称Onkyo与日本文化认同没有什么关系。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Onkyokei
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=248
