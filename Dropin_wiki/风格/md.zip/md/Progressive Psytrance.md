#Progressive Psytrance
##基本信息
###发源时间：
###风格类型：Psychedelic Trance
##详情
"Progressive psytrance"或"Prog-
psytrance"是派对中常见的类别主题，通常在下午或在不同的舞台上播放。自20世纪10年代中期以来，它越来越受欢迎，经常被贴上"psytrance"的标签。从事这一流派的艺术家包括Astrix和Protonica。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Psychedelic_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=177
