#Funkstep
##基本信息
###发源时间：2012
###风格类型：UK Funky
##详情
Funkstep（又称Dubbage）是电子舞曲的一种风格，是由UK Funky结合Dubstep和Drum and Bass的元素而成的一个子流派。



**历史**

自2001年的dubstep运动以来，Funkstep获得了更多的听众，因此也有更多的唱片制作人来制作这种音乐风格。自2012年起，Funkstep融合了dubstep、drumstep、drum
and bass、funky house和electro house等音乐流派而形成。



**特点**

Funkstep的速度变化是很明显的，因为鼓点会在150到170 BPM之间，因为它的2-step beat，French 和electro
house通过120和130
BPM之间的对比。这个问题通常是通过播放歌曲在其drumstep甚至dubstep部分的一半速度来解决的，与发生的house在类似的部分相比。



大多数funkstep歌曲都是从平静的前奏开始的，由于它的dubstep和drum and
bass一样的鼓声，有时会和drumstep混在一起。但从典型的funkstepriff开始，将bassdrum改为一致的4x4-cadence之后，很容易识别出更复杂的house音乐的桥段，这就是典型的funkstep歌曲。一首歌曲中可以反复包含这些桥段和变化，这些桥段和变化大多表示落点和亮点。Funkstep也经常与glitch结合在一起，因为它们的BPM和失真声音的arsenal相似。



由于funkstep包含的部分听起来类似于house、drum 和bass and
drumstep的不同变化，所以它对多种音乐风格的听众都很有吸引力，而且相当多样化。



从2009年开始，著名的现场报道就试图向听众简单地解释Funkstep的概念，贴出 "Dubstep+Funky House=Funkstep
"这样的标题。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Funkstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=110
