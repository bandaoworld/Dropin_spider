#Cloud Rap
##基本信息
###发源时间：Late 2000s
###风格类型：Hip Hop Music
##详情
Cloud rap是南方rap and trap音乐的一个子流派，它以其朦胧、梦幻和轻松的声音，具有lo-fi的声音特征。许多音乐专家认为说唱歌手Lil
B和制作人Clams Casino是这种风格的早期先驱。"Cloud rap "一词的诞生与其互联网的诞生和空灵的风格有关。A$AP Rocky和Yung
Lean是两位受欢迎的艺术家，他们都曾在自己的音乐中融入Cloud rap风格。



**起源**

"Cloud Rap "这个词，通常用来指代lo-fi、朦胧的说唱。



Cloud rap最初是在2000年代末从亚特兰大、休斯顿和孟菲斯传出的。早在2006年Viper的第二张专辑《Ready...and
Willing》中就可以听到Cloud rap的元素，比如朦胧和轻松的声音。有人将这个词归功于说唱歌手Lil
B，音乐作家Noz在2009年的一篇文章中写道，说唱歌手Lil B给他看了一个云中城堡的CGI图像，并说 "这就是我想做的音乐"，将这个词的创造归功于Lil
B。" 制作人Clams Casino也被认为早在2010年就通过与Lil B的合作，开创了Cloud rap的先河。



Space Age Hustle的歌曲合集" _3 Years Ahead: The Cloud Rap Tape_ "也使用了"Cloud
Rap"这个词。该合辑由后来被认为属于Cloud Rap流派的歌曲组成。2011年，随着说唱歌手A$AP Rocky的首张mixtape《Live.
Love. A$AP》，该风格开始获得主流市场的认可关注。



**特点**

Cloud Rap在节奏上类似于lo-fi和chill-wave的节奏，但区别于lo-fi和chill-
wave的失真、迷幻的采样和加入说唱。这种风格的灵感来自于云计算所带来的 "多样化的影响和易得性"。这些影响包括hip hop, drum and
bass, grime, and trip hop, R&B, dance, indie, rock, 和 pop music流派。



"cloud "这个标签代表了该流派的明显特征，比如它的 "朦胧"、空灵的美学（在听觉和视觉表达上），以及作为一种没有明确边界的流派的模糊性。Cloud
Rap的歌词有时围绕着爱情和背叛的主题，以及流行音乐中更典型的主题，如性、毒品和异化。主唱们经常使用无厘头的口号和Twitter诱饵，比如 "swag
"这样的插话，以及提到 "based"，这突出了一种自我意识的荒诞感，作为一种模仿的尝试，同时也拥抱了它的网络文化起源。



Cloud rap从多元化的说唱声音和地域中汲取灵感：来自东西海岸和南方。特别是，Cloud
rap经常利用女歌手的循环采样，而且往往是那些声音具有空灵性的歌手。通常情况下，Cloud rap是独立于唱片公司发行的，Cloud
rap艺术家依靠互联网服务（如SoundCloud、YouTube和Twitter）来传播和推广他们的音乐。



**艺术家和制作人**

制作人Clams Casino在Lil B于2009年发布的Mixtape《6 Kiss》中制作了三首歌。2011年，他协助A$AP
Rocky制作《Live. Love. A$AP》，有1,164,114名听众收听了这张作品，是Cloud
Rap中收听量最多的mixtape之一。这张作品包含了常见的Cloud Rap元素和主题例如毒品、性爱和自我审视等。



与Clams Casino 一样，另类电子音乐天后Imogen Heap于2009年涉猎这一流派，她的音乐被 Clams Casino 采样，用于 Lil
B 的歌曲"I'm God"。 此后，Lil B也多次对Heap的作品进行采样。 随后，Heap也参与了A$AP Rocky 2011年的专辑《Live.
Love. A$AP》，进一步巩固了她在Cloud Rap领域的位置。



2013年，瑞典说唱歌手、制作人 Yung Lean 成为著名的Cloud Rap艺术家，当时他的单曲"Ginseng Strip
2002"的视频在网上疯传。Yung Lean 通过大量采用忧郁、梦幻般的说唱风格而崛起，与传统的Cloud Rap声音有所偏离，将Cloud
Rap升级至更现代的版本，让更多人可以自由地融入这种风格。



其他著名音乐人还包括 Post Malone、已故的 XXXTentacion 和 Lil Peep、$uicideboy$ 和
Bones等。虽然这些艺术家的音乐也属于多种其他流派，例如Trap、Lo-fi和Hip
hop，但他们都发行过慢节奏、飘逸的音乐、毒品和性的歌词等具有Cloud Rap特色的歌曲。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Cloud_rap
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=280
