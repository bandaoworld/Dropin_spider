#Euphoric Hardstyle
##基本信息
###发源时间：2010
###风格类型：Hardstyle
##详情
Euphoric Hardstyle是从大约 2010
年开始从较传统的Hardstyle风格转向更为旋律化的方向发展而形成的子流派，其特点是高度富有感情的旋律和Kick高度的音高变化。著名的Euphoric
Hardstyle风格音乐制作人包括 Headhunterz、Coone、Atmozfears、D-Block & S-Te-Fan 和 Da
Tweekaz[1]。



Euphoric Hardstyle 是一种不那么"Raw"的 Hardstyle，它对底鼓声音的使用并不像 Hardstyle
众所周知的常用的Reverse Bassline+底鼓，并且更旋律化，更容易入耳，并强调整体的电影感和令人振奋的感觉[2]。



**参考资料**

1\. https://en.wikipedia.org/wiki/Hardstyle#Euphoric_hardstyle

2\. https://www.last.fm/tag/euphoric+hardstyle/wiki

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=189
