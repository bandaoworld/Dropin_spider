#Dubtronica
##基本信息
###发源时间：1980s
###风格类型：Dub
##详情
Dubtronica指的是在20世纪80年代在英国地区受dub music影响而发展的电子音乐。早期例子是80年代来自厂牌On-U Sound
Records和艺术家Mad Professor的实验性作品。



1980年，Tackhead前成员、制作人Adrian Sherwood创办了厂牌On-U
Sound。在当时的英国，绝大多数雷鬼乐迷是白人群体，而艺术家和创作者则多是非裔。On-U
Sound成为了这两个群体之间的桥梁，极大的促进了Dub音乐在英国本土的发展，Dubtronica的概念也在英国得以发展。



Dubtronica的作品主要由电子节拍组成，以Downbeat的方式呈现。它的速度比Techno慢得多，通常比舞曲型电子乐听感更加温暖。有些曲目使用雷鬼文化中的toasters（Deejay，致辞）或雷鬼歌手来创作出更容易理解的音乐形式。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Dubtronica
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=337
