#Bass Music
##基本信息
###发源时间：1980s
###风格类型：Electronic Dance Music
##详情
Bass Music（低音音乐）是电子舞曲领域中常用的一个术语，用于描述 1980
年代以来出现的多种电子舞曲和嘻哈音乐风格，这些风格共同的特点是侧重于Bass
Drum（低音底鼓）和/或Bassline（低音声线）的声音表现。随着2010年代以来Dubstep及其相关子风格的快速发展，Bass
Music迎来了全球范围内更广泛的流行，部分Bass Music的音乐特点也逐渐向响度更高，听感更具刺激性、侵略性的方向发展。



2018年，音乐评论人Steven Mason在Relentlessbeats.com中做出了这样描述Bass
Music："现在世界上有许多不同类型的Bass Music，而这其中的每一种类型都通过各自的方式，诠释了现代音乐中最具响度的元素"。



通常，Bass Music中的低音部分是使用合成器和鼓机创建的，例如通过极具影响力的 Roland TR-808
鼓机等硬件设备，或Serum等现代数字合成器软件创作。



属于Bass Music范畴中的电子舞曲/嘻哈音乐风格包括：

  * Bass house
  * Bassline
  * Drum and bass
  * Dubstep
  * Footwork
  * Future bass
  * Glitch hop
  * Midtempo bass
  * Moombahton
  * Trap (EDM)
  * UK bass
  * UK garage
  * Wave
  * Wonky
  * Miami Bass

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Bass_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=377
