#Tropical House
##基本信息
###发源时间：2000s
###风格类型：House
##详情
Tropical House（热带浩室），又名Trop house，是Deep House的一个子流派 ，也结合了Dancehall和Balearic
beat等的元素。这一流派的音乐人常常会参与到Tomorrowland等在夏季举办的音乐节中。Thomas Jack、Kygo、Matoma、Lost
Frequencies、SeeB、Gryffin等音乐人为Tropical House的推广做出了贡献。



"Tropical House"一词源于澳大利亚音乐制作人托马斯*杰克（Thomas
Jack）的一句玩笑，但随后这一说法逐渐在听众中流行起来。"Trouse"不应与此词混淆，那是一种使用电子合成器、结合Trance的感觉和渐进浩室的节拍的音乐流派。



**特征**

Tropical House是Deep House的子流派，而Deep
House又是House的子流派。因此，它拥有浩室音乐的特征，包括合成器乐器和4/4拍的底鼓节奏。区别于深度浩室阴暗的听感，热带浩室往往听上去令人振奋而放松。热带浩室的节奏比深度浩室慢一点（100-115bpm）。与电子浩室等不同，热带浩室通常不使用Pumping这种压缩效果。它常常采用热带乐器，如钢鼓（英语：steel
drum）、马林巴、吉他、萨克斯甚至长笛，有时也会用舞厅（英语：Dancehall）和雷鬼音乐中常用的Dembow（英语：Dembow）节奏。



**历史**

在2000年代中期和后期，Bob Sinclar和Yves Larock创作了具有热带房屋许多特征的国际流行歌曲，它们从1980年代的Hi-
NRG音乐中汲取了灵感，并与当时的其他电子类型（EDM）音乐形成鲜明对比。 2012年，独角兽小子（Unicorn
Kid）创造了热带狂欢，这是一种更快的形式，后来被称为热带房屋。然而，直到2013年，随着Klangkarussell的" Sun Do n't
Shine"和" Kygo"和" Robin Schulz"等制作人的出现，热带音乐屋成为一种舞蹈音乐潮流。在2014年至2015年期间，Lost
Frequencies，Felix Jaehn，Alex Adair，Sam Feldt，Bakermat，Klingande和Faul＆Wad
Ad等制作人将与热带大热门一起加入他们的行列。



在2010年代中期，某些热带制作人与贾斯汀*比伯（Justin Bieber）和Little
Mix等艺术家合作。这使得该流派取得了巨大的商业成功，并产生了被称为"Tropical Pop（热带流行）"的相关歌单。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Tropical_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=86
