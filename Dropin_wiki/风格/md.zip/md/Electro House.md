#Electro House
##基本信息
###发源时间：Late 1990s – early 2000s
###风格类型：House
##详情
Electro House（电气浩室）是电子音乐的子风格，特点是130bpm左右的节奏以及强劲有力的重低音部分。这种风格受到Tech
House和Electro的影响。许多知名制作人的创作都与Electro House相关，如Benny Benassi，Daft
Punk，Skrillex，Steve Aoki等。



**特征**

Electro
House的特点是其低音部分的处理。通常是以嗡嗡作响的Bassline形式出现，例如用锯齿波和失真创造的Bassline。它也经常以宽大的低音鼓声的形式出现在重拍上。Electro
House的BPM通常在每分钟125到135次之间。Electro House有时类似于Tech
House，但它可以包含旋律元素和受Electro影响的采样和合成器。



**历史**

西蒙*雷诺兹（Simon Reynolds）在其有关狂欢音乐和舞蹈文化的书中描述了Electro House，将像Zedd、Erol
Alkan和Bloody Beetroots这样的艺术家创作的风格称为Electro House，尽管它
"与house或electro都没有什么关系"。Reynolds将这种声音描述为受到Daft
Punk的Discovery以及Justice和Digitalism音乐的影响，这种声音在美国被deadmau5流行起来，并指出这种风格的独特风格是有一个
"脏质感的低音 "和 "研磨和呼啸质感的锯齿Bassline"。



2011年，"Electro"这个词被看作是一个形容词，表示 "硬电子舞曲"。



早期被追溯贴上Electro House标签的歌曲包括1996年Arrivers的 "Dark Invader "和1997年Basement Jaxx的
"Raw S*it"。Mr. Oizo 1999年的主打歌 "Flat Beat "也被认为是该类型的早期范例。



意大利DJ Benny Benassi在2002年推出的歌曲
"Satisfaction"，被认为是将电气浩室带入主流的先驱。到了2000年中期，电气浩室的受欢迎程度有所提高。2006年11月，由Fedde Le
Grand创作的电音House歌曲《Put Your Hands Up For
Detroit》和由Bodyrox和Luciana创作的D.Ramirez混音的《Yeah
Yeah》分别占据了英国前40名单曲榜的第一名和第二名。此后，出现了Feed Me、Knife Party、The M Machine、Porter
Robinson、Yasutaka Nakata和Dada Life等电音House制作人。



**子风格和相关风格**

  * Big Room
  * Complextro
  * Dutch House
  * Fidget House
  * Melbourne Bounce
  * Jungle Terror
  * Moombahton

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=51
