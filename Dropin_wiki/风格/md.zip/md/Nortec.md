#Nortec
##基本信息
###发源时间：Early-2000s
###风格类型：Electronica
##详情
Nortec（来自 "norteño "和 "techno
"的组合）是一种在蒂华纳（墨西哥下加利福尼亚州的一个边境城市）发展起来的电子舞曲流派，于2001年首次流行起来。"Nortec "音乐的特点是hard
dance beats和墨西哥传统音乐形式的样本，如Banda sinaloense和Norteño--经常使用明确无误的墨西哥号角。



不同的个人项目创造了nortec音乐。还有一个 "Colectivo
Visual"：一个由设计师和VJs组成的团队，负责nortec现场表演的视觉方面。Nortec这个词是norteño（"来自北方"）和techno的组合，但主要是描述电子音乐的音乐、风格和文化与norteño和tambora这两种墨西哥北部本土音乐流派之间的碰撞。这些风格的特点是使用手风琴和低音提琴(norteño)；大号、单簧管、号角和抽气低音鼓(tambora)，以及奇特的打击乐和多韵律的小鼓卷(两者)。所有这些元素都被用来创造一种很像
Tijuana的声音。



Nortec起源于1999年，当时Pepe Mogt开始尝试用老的banda
sinaloense和norteño专辑的样本，并在电脑上改变它们或用模拟合成器过滤它们。他是在一次家庭社交活动中听了tambora和norteña音乐的敲击声和棱角分明的节奏后，产生了这个想法。通过与位于
Tijuana臭名昭著的Zona
Norte红灯区的录音室的一些联系，Pepe从tambora和norteña试听录音的多轨录音中编纂了一些孤立的乐器音轨，这些音轨被录制这些音轨的乐队遗弃在录音室里。他开始将这些音轨刻录到CD-
R上，随后他将这些CD-R分发给朋友，条件是他们使用这些材料制作新的音轨。这些最初的原始音轨被编入 "Nor-tec
Sampler"，这是Mil唱片公司的第一张唱片，之后又发行了 "The Tijuana Sessions Vol.1 "和 "The Tijuana
Sessions Vol.3"。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=361
