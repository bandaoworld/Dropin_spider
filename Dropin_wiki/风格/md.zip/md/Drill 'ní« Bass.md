#Drill 'n‘ Bass
##基本信息
###发源时间：Mid-1990s
###风格类型：Intelligent Dance Music
##详情
Drill 'n' Bass（也称为 fungle 或 spunk jazz）是 1990 年代中期随着 IDM 艺术家开始尝试Drum and
Bass、Breakbeat和Jungle音乐元素而发展起来的电子音乐子流派。 Drill 'n'
Bass艺术家们利用强大的音频软件程序并部署疯狂的、不规则的节拍，且这些节拍往往不适宜跳舞。 这种风格通常被解释为与激发它的舞蹈音乐风格有轻微的模仿关系。



**历史**

早期在drill 'n' bass方面做出尝试的人有Luke Vibert, Aphex
Twin和Squarepusher，这种风格是由Vibert在他1995年的EPs下的以Plug这个名称首创的。其他开创性的发行曲包括1995年Aphex
Twin的Hangable Auto Bulb EP和同年Squarepusher的Conumber E:P
EP，到20世纪90年代末，它却基本消失在视野中。后来Kid606等艺术家借鉴了这种风格，对IDM衍生出的breakcore的发展有帮助，
比jungle音乐更认真、更疯狂。





###词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drill_'n'_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=232
