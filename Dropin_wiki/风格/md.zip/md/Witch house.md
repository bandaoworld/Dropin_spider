#Witch house
##基本信息
###发源时间：2007-2008
###风格类型：Industrial
##详情
Witch House是2000年代末出现的一种以神秘、黑暗为主题的电子音乐类型和视觉美学。Witch House这个说法起源于本名Travis
Egedy（艺名Pictureplane）的音乐人于2009年和朋友开的一个玩笑，用于描述以神秘学为核心精神的House音乐。这个原本流行于网络的词汇很快就被权威音乐媒体Pitchfork
Media、博客站点以及其他主流音乐媒体为了推广音乐而大量运用，现今Witch
House这个音乐标签已被Pitchfork半正式的用于描述Industrial音乐的一种分支。



**影响和风格**

Witch house采用了来自像DJ
Screw这样的艺术家的技术，这种技术根植于切碎的嘻哈音乐中，通过跳跃和停止时间的节拍大大放慢节奏，并结合了其他流派的元素，如ethereal wave,
noise, drone和shoegaze。Witch house还受到了20世纪80年代的ethereal wave bands如Cocteau
Twins的影响，以及一些工业和实验乐队如psychittv和Coil的严重影响。对嘻哈鼓机，噪音氛围，令人毛骨悚然的样本，受合成流行音乐影响的黑暗主旋律，密集的混响，以及严重改变、扭曲和压低的人声的使用是该流派声音的主要特征。在2010年代早期，随着对个人制作的电子音乐和网络亚文化的兴趣的重新兴起，这一流派开始崭露头角
----同时也伴随着诸如seapunk和vaporwave等流派的兴起。



**反应**

Witch-
Hous的音乐被认为具有煽动性和具有越界性质，"就像从德古拉城堡飘出来的流行音乐"。该流派的特点是软的，黑暗的，越轨的，混合了粗糙和和谐的界限。这一类型的许多艺术家都发布过流行歌曲和嘻哈歌曲的慢速混音，或者是不同歌曲的长混音，这些歌曲的节奏被明显放慢了。



**起源与词源**

Witch house这个词是2009年由Travis
Egedy创造的，他以Pictureplane的名义表演。这个名字最初是一个玩笑，Egedy解释说:"我和我的朋友Shams……关于我们制作的house音乐，witch
house是开玩笑的因为它是基于神秘学的house音乐. ...我在《Pitchfork》上做了一件关于witch
house年度最佳的事...我说我们是witch house乐队，2010年将是witch house之年....它从那里起飞.
...可是，当时，我说witch house的时候，它根本不存在……"
在被Pitchfork提到后不久，博客和其他主流音乐媒体开始使用这个词。Flavorwire表示，尽管Egedy坚持，"无论好坏，这种类型的游戏现在确实存在。"但是，一些音乐记者以及一些被认定为音乐流派当前运动的音乐家认为witch
house是由某些音乐出版物(包括《卫报》、Pitchfork和各种音乐博客)构建的一个微流派的虚假标签。
该音乐类型也与"强奸凝视"一词有短暂联系，被其创造者公开谴责，他们从没期望过将其用作实际类型，但只是将其视为一个玩笑而已：嘲笑音乐出版社倾向于创造微型流派。



**特征**

Witch
House的音乐一般融合了美国得克萨斯州休斯敦市的音乐厂牌Swishahouse所做的嘻哈音乐的一些技术特点：慵懒的速率加上跳拍、停顿的节拍，加上一些来自noise,
drone, shoegaze这些音乐类型的元素。Witch House还受到了1980年代哥特乐队的影响，包括Cocteau Twins, The
Cure, Christian Death和Dead Can Dance等乐队。Witch
House同时还有强烈的早期工业音乐的影子。这种音乐风格的音乐人发布了不少流行和说唱歌曲的慢速度版本混音，或是把不同的歌很明显的放慢以后做成时间较长的混音歌曲。这种音乐类型的艺人和歌曲名常常使用三角形、十字架形或是其他几何图形命名（例如▲,▼,∆,
†），原因包括他们独特的审美风格以及一些艺人希望将这种音乐保持地下，不想轻易在网上被找到。 时至2011年8月2日，Pitchfork
Media始终在使用这个音乐类型术语，但主要用于推广美国另类金属乐队Deftones主唱兼吉他手Chino
Moreno的个人音乐作品†††，他的单曲EP唱片Crosses集合了极简主义、温和的、以电子音乐为基调氛围摇滚曲目，这使得这种模糊、难定义的音乐类型更加富有争议性。

###本词条汉字内容由 @多频百科团队 翻译+编辑
参考链接：https://en.wikipedia.org/wiki/Witch_house_(genre)
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=276
