#Drill
##基本信息
###发源时间：Early 2010s
###风格类型：Trap
##详情
Drill是2010年初起源于芝加哥南区的一种trap音乐风格。它的特点是黑暗、暴力、虚无的抒情内容和不祥的trap音乐节拍。



在Young Chop、Chief Keef、Lil Durk、Fredo Santana和Lil
Reese等说唱歌手和制作人的成功之后，Drill在2012年中期逐渐进入美国主流，他们在当地拥有许多粉丝和重要的网络影响力。媒体的关注和Drill音乐人与各大厂牌的签约也随之而来。该流派内的艺术家因其抒情风格和与芝加哥犯罪的关联而受到关注。



从2012年开始，伦敦出现了一个地区性的子流派--UK drill，尤其是在布里斯顿区。UK
drill在2010年代中期崛起，并影响了其他地区场景的创造，如 Australian, French, Irish, Dutch and New York
drill。



特点

drill歌词往往是暴力的，非常粗犷的。《卫报》的Lucy
Stehlik说："虚无主义的drill反映了真实的生活，而它的那些非常干净的嘻哈同行们却失败了。"
drill歌词与早期芝加哥说唱歌手和当代主流嘻哈的题材形成了强烈的对比，在drill出现的时候，这些歌词往往是在美化和庆祝财富的崛起。Drill歌词通常反映的是街头生活，往往是粗犷、暴力、现实和虚无主义的。Drill说唱歌手使用的是一种严峻的、死板的表达方式，通常通过自动调音过滤，受到
"Soulja Boy（最早的非本地Keef合作者之一）和他之前的Lil Wayne的嗑药、漫无目的的莺歌燕语 "的影响。来自亚特兰大的说唱歌手Gucci
Mane和Waka Flocka Flame对drill现场产生了重要影响。虽然它与Trap音乐有很多相似之处，但drill
beat的速度一般较慢，节奏适中，每分钟大约有60到70拍。有些制作人以双倍的节奏工作，如每分钟130至140拍。Drillers往往是年轻人，许多著名的音乐人在十几岁的时候就开始受到关注。该流派最著名的音乐人之一Chief
Keef在16岁时就与Interscope签订了一份价值数百万美元的唱片合同，而在一个极端的例子中，Lil Wayne联合签约了13岁的drill歌手Lil
Mouse。批评者注意到drill rappers对隐喻或文字游戏缺乏关注。Chief
Keef表示，他的简单化流程是一种有意识的风格选择："我知道我在做什么。我掌握了它，而且我甚至没有真正使用metaphors或punchlines。'因为我没有必要。但我可以。...
我认为这是做得太多了。我宁愿只说现在发生了什么。... 我真的不喜欢metaphors 或punchlines这样的说法。" Moser写道，Keef的歌曲
"在抒情、节奏和情感上都被削弱了，这就是为什么它们听起来如此无气无力和幽闭恐惧......。这甚至不是宿命论，因为那将意味着一种自我意识，一种道德考虑，这在歌词中是不存在的。它就是这样，一而再再而三地存在着。"《纽约时报》的一篇关于现场的报道考察了这一流派的侵略性。除了罕见的例外，这种音乐是不加修饰的，原始的，没有亮点的，专注于愤怒和暴力。人们本能地将这种强硬、无情、具体的硬音乐称为无乐感的音乐，但事实上，它在黑暗中充满了活力。它的大多数创造者都很年轻，在芝加哥令人发指的暴力背景下，尤其是在年轻人中
--今年有几十名青少年在芝加哥被杀--
而且往往与帮派有关，他们开始了自己的创作。芝加哥的帮派和芝加哥的说唱之间有很长的重叠历史）。他们的音乐是脾气不好的交响乐，这不应该是一个惊喜。女艺人在这个场景中自始至终都有话语权。Pitchfork的Miles
Raymer说："与其说rapping是'hitta'--当地人对枪手的称呼，不如说是rapping爱上了hitta。除此之外，他们和其他drill
rappers一样，使用来自相同制作人的那种冰冷的反社会的节拍，表现得同样强硬。" 女drillers在歌曲中混合了暴力和爱情的主题，Katie Got
Bandz说："这是不一样的，因为男性不会想到女性会说唱drill。他们已经习惯了女性推销自己。" Stehlik称drill制作风格是
"溜须拍马的脚步声、南方的fried hip-hop和808 trigger-finger of trap的声音流派"。Young
Chop经常被评论家认定为该流派最具特色的制作人。trap制作人Lex Luger的音乐声音对drill产生了主要的影响，Young
Chop认为Shawty Redd、Drumma Boy和Zaytoven是drill的重要前辈。



**历史**

Complex的David Drake 说，drill并没有被任何特定的制作风格所定义，而是 "关乎整个文化：行话、舞蹈、心态和音乐，其中大部分源于'Dro
City'，即伍德隆街区的一个帮派定义的城市街区领地"。在街头俚语中，"drill"的意思是战斗或报复，"可以用于任何事情，从女性被打扮得漂漂亮亮，到街头的全面战争"。Dro
City说唱歌手Pacman被认为是该流派的风格鼻祖，被认为是第一个将该词应用于本地嘻哈音乐的人。Drake将drill场景描述为2010年代初芝加哥嘻哈兴起的主要载体，并将其描述为
"一场草根运动，它曾在一个封闭的、相互交错的系统中孵化：在街头和社交媒体，在俱乐部和派对的网络中，以及在高中之间。"
drill在芝加哥南区发展，当时正值暴力升级和凶杀危机。Mark Guarino 在《沙龙》杂志上写道，音乐是在
"从历史上控制着数千名成员的单体犯罪组织之间的争斗转变为控制范围仅有几个街区的小型混合团体之间的内部争吵和报复性冲突的过程中成长起来的......"。生活在这些街区的强硬现实是形成Drill
music的原因。" 在drill现场，说唱冲突和帮派冲突相互交织，许多年轻的说唱歌手都来自有暴力经历的背景。《独立报》的Sam
Gould写道，"Chief Keef
"既代表了当下嘻哈文化的一个可怕的应变，也代表了美国社会中一个严重疏离的群体"。到了2012年底，其他场景的说唱歌手和嘻哈明星如Kanye
West、Drake和Rick Ross等都开始与drill音乐人合作。Kanye West为2012年GOOD音乐合辑Cruel Summer混音了 "I
Don't Like"，成为 "Don't Like"，West、Chief Keef、Pusha T、Big
Sean和Jadakiss等人都有参与。West将drill作为2013年专辑Yeezus受到的影响，Chief Keef和King
Louie在专辑中也有演唱。Drill的题材与Kid Sister、Lupe Fiasco、Psalm One、Rhymefest和The Cool
Kids等早期芝加哥说唱歌手的题材形成了强烈的对比，老一辈芝加哥说唱歌手对drill的流行和暴力的反应不一。在一次电台采访中，说唱歌手Lupe
Fiasco说："Chief Keef让我害怕。不是他具体的，只是他所代表的文化......。芝加哥的谋杀率正在急剧上升，你看看是谁在做，在实施--
他们听起来都像Chief Keef。" 在Chief
Keef在推特上威胁Fiasco之后，Fiasco说他正在考虑退出乐坛。Rhymefest在推特上说，drill音乐是
"谋杀的主题音乐"。当芝加哥的drill音乐逐渐淡出主流流行的时候，一个新的音乐场景正在英国兴起，到2010年代末获得了主流流行，并蔓延到欧洲各地，影响了欧洲大陆drill场景的建立。与芝加哥drill相比，UK
drill发展出自己独特的制作风格。2010年代中期，Brooklyn drill的出现几乎完全受到芝加哥的影响，出现了Bobby
Shmurda和Rowdy Rebel等艺人，而2010年代后期，纽约布鲁克林出现了著名的drill艺人，如Pop Smoke、Sheff G、Fivio
Foreign、Sleepy Hallow、Smoove'L、22Gz、Nick Blixky、Blizz Vito、Bizzy Banks和Rah
Swish等。后来Brooklyn drill制作深受UK drill的影响，Fivio Foreign、Sheff G、Smoove'L、Bizzy
Banks和Pop Smoke等艺人与808Melo、Yamaica Productions、Yoz Beats和AXL Beats等UK
drill制作人合作。Pop Smoke的歌曲 "Welcome to the
Party"，由808Melo制作，是2019年的一个突出的版本，并且看到了Nicki Minaj，Meek Mill和英国MC
Skepta的混音.Sheff G的 "No Suburban"（2017年发布）和22Gz的
"Suburban"（2016年发布）让人们关注后来的Brooklyn drill。



**UK drill：British hip hop**

UK drill 是2012年起发源于伦敦南部Brixton区的一种drill music 和 road rap的子流派。受Chicago drill
music风格的影响，UK
drill艺人经常说唱暴力和享乐主义的犯罪生活方式。通常情况下，创造这种音乐风格的人都隶属于帮派，或者来自社会经济贫困的社区，在那里犯罪是许多人的生活方式。UK
drill与Road rap有很大的关系，Road rap是一种英国风格的帮派说唱音乐，在drill存在之前的几年里就开始流行。在音乐上，UK
drill常常表现出暴力的语言、多样的抒情表达方式，以及随之而来的激烈竞争。著名的先驱者包括postal-code crews
150、67（都在布里斯顿或附近）和86。自2016年以来，出现了更多的现代团体，如814、Silwood Nation、Block
6、Y.ACG、Zone 2、BSide、Moscow17、CGM（原1011）、12World、SMG、OFB、NPK和Harlem
Spartans。UK drill groups依靠互联网平台传播音乐，特别是在YouTube上，Link-Up TV、GRM
Daily、SB.TV、Mixtape Madness、PacMan TV和PressPlay
Media等平台帮助各团体积累了数千，有时甚至数百万的浏览量。UK drill 形成了与Chicago
drill不同的制作风格，受到早期英国风格如grime和UK garage的影响，以至于被称为 "New Grime"，drill 制作人Carns
Hill评论说，它需要一个新的名字。不过，UK drill 制作人Mazza却不同意 "new grime"的标签，他认为，虽然drill 和
grime有着相同的能量、生硬，起源方式也很相似，但两种风格有各自的特点。与芝加哥的同类音乐相比，UK
drill的节奏一般比较快。乐器往往也有滑动的贝斯、重击的踢腿和黑暗的旋律。AXL
Beats解释说，808的和快节奏的snares是grime音乐的衍生品。这两种流派通常利用约140 bpm的节奏。UK drill
groups之间经常发生纠纷，有时是暴力的，经常发布多个diss曲目。著名的纠纷包括Zone 2对莫斯科17，150对67
OFB/NPK对WG/N9和SMG对814（814的成员Showkey在2016年的一次无关事件中被刺死）。2017年，当喜剧演员Michael
Dapaah发布了新奇歌曲"Man's Not Hot"时，UK drill受到了全世界的关注。这首歌曲采样了UK
drill制作人GottiOnEm和Mazza制作的节拍；drill group
86首先在其歌曲《Lurk》中使用了这首歌曲，后来67以Giggs的《Let's Lurk》使用了这首歌曲。



**法律行动**

一些伦敦公职人员批评UK drill及其周边文化，认为它鼓励了暴力犯罪。侦探督察Mike
West表示，"有暴力的手势，暗示他们正在发射武器，还有图形描述他们会对对方做什么。" 2017年，当时年仅17岁的说唱歌手Junior
Simpson（人称M-Trap）曾写过关于持刀袭击的歌词，他是刺死一名15岁男孩的团伙成员之一，并因此被判无期徒刑。法官安东尼-伦纳德（Anthony
Leonard QC）对辛普森说："你的提出都只是为了作秀，但我不相信，我怀疑你是在等待合适的机会进行攻击。" 2018年，大都会警察局长Cressida
Dick将UK drill作为伦敦持刀袭击率上升的原因之一，并敦促大型互联网公司删除 "美化暴力
"的内容。当年5月，YouTube报道称，已经删除了她要求平台删除的一半以上的音乐视频；她认为这些视频是伦敦暴力犯罪的原因。一共有30多个视频被删除。同年晚些时候，出生在南伦敦的drill
MC、有志于担任伦敦市长的Drillminister发布了一首名为 "Political Drillin
"的歌曲，这首歌在第四频道新闻中播出，随后被病毒式传播，他利用英国议员的评论，试图突出自己暴力语言的虚伪性。2019年7月，YouTube决定不再在YouTube上下架UK
drill视频。2018年6月，UK drill group 1011的成员被称为法律上前所未有的举动，法院命令禁止他们在音乐中提及伤害或死亡，并禁止在
"帮派语境
"中提及某些postcodes。该命令还要求他们在发布新视频后24小时内通知警方，提前48小时通知他们任何表演或录音的日期和地点，并允许警察参加。该命令受到了许多人的批评，包括运动组织
"审查制度指数"（Index on Censorship）的首席执行官乔迪-金斯伯格（Jodie
Ginsberg）说："禁止一种音乐并不是处理令人厌恶或不安的思想或观点的方式"，"这并不能解决导致这种音乐创作的问题"。2018年6月，Victor
Maibvisira是2017年10月在肯特郡Gillingham刺死Kyle
Yule的5名团伙成员之一，他们被判谋杀罪并被判处终身监禁。在他被还押期间，一个以他说唱刀具犯罪和帮派为主题的drill视频被放到了网上。



**国际传播**

UK drill的制作风格已经传播到了英国之外，其他国家的艺术家和团体的说唱风格和使用的制作深受UK drill的影响，同时也合作使用了UK
drill音乐中常见的英国俚语。英国制作人通过为其他国家的艺人制作，成功地输出了这种声音。特别是爱尔兰、荷兰和澳大利亚，发展出了深受UK
drill影响的drill场景，如澳大利亚的OneFour、爱尔兰都柏林的Chuks & J.B2和荷兰的73 De
Pijp。这种风格也传到了纽约，在纽约，Sheff G、22Gz和Pop Smoke等艺人都与UK
drill制作人合作过。西班牙制作drill音乐的艺术家也受到了英国同类音乐的影响，各种参考和类似UK drill的制作。加拿大音乐人Drake
在2018年为Link Up TV做了一段 "Behind Barz "的freestyle，他使用UK drill beat说唱。Drake还认为UK
drill艺术家Loski对他2018年的专辑《Scorpion》产生了影响。2019年，Drake发行了《War》。这首歌采用了UK
drill的制作风格，由英国制作人AXL Beats制作。Drake在这两次音乐中都让人联想到UK
drill艺人，而这种制作风格也迅速在多伦多地区和大温哥华地区的其他艺人中流行起来，促使人们猜测加拿大可能会出现一种结合美国和英国元素的新的混合型drill音乐亚流派。



**影响力**

drill音乐的歌词往往传达出攻击性的主题，这在该流派的一些音乐视频中很明显，这可能会导致这种风格被认为是一种负面影响。一些重要的公众人物曾试图将drill音乐与伦敦青少年的暴力行为联系起来。大都会警察局长Cressida
Dick在2018年成功向YouTube提出申请，要求删除30个drill视频。2015年7月25日，警方关闭了一场由Chief
Keef主演的音乐会，Chief
Keef是一名说唱歌手，他帮助在美国普及了drill音乐。虽然这场音乐会是为7月11日遇害的一名幼儿和一名22岁男子Dillan Harris和Marvin
Carr的家属举办的慈善活动，但它被认为是对公共安全的威胁。据称，drill音乐与犯罪率上升之间的联系是有争议的。UK drill rapper
Drillminister对一名持刀袭击受害者的说法提出了质疑，他指责这种流派的音乐煽动了暴力行为。Drillminister解释说，很多人在不了解情况的情况下，就迅速将矛头指向drill
music。许多drill rappers将自己的生活环境作为歌词的主题。加拿大麦吉尔大学心理学教授Daniel
Levitin曾表示，其他因素，如人们的个性，可能导致他们沉迷于暴力，而不是受drill音乐的影响，drill音乐可能被非暴力的听众所喜欢。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drill_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=298
