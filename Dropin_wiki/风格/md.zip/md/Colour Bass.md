#Colour Bass
##基本信息
###发源时间：2015
###风格类型：Riddim Dubstep
##详情
Colour Bass（又称Color
Bass）是2015年开始逐渐兴起的Dubstep/Bass音乐风格分支，以注重中高频Bass音色并呈现出旋律性强，以及明亮闪耀、花哨华丽的听感而得名。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=376
