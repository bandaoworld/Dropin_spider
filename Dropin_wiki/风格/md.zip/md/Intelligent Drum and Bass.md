#Intelligent Drum and Bass
##基本信息
###发源时间：
###风格类型：Drum and Bass
##详情
Intelligent Drum and Bass（智能鼓打贝斯）或Intelligent
Jungle（智能丛林）是一种比较平稳的风格，受到环境音乐、弛放、爵士乐和灵魂音乐的影响。它由艺术家Omni Trio、Peshay、Foul
Play、Seba、Blu Mar Ten、Nookie、Hyper-On-Experience、DJ Pulse、Higher Sense、Deep
Blue（Sean O'Keefe、Cause4Concern Records）、Photek、Jack Smooth（Basement
Records）、Blame、LTJ Bukem和他的厂牌Good Looking Records，以及厂牌Moving Shadow等开创。



**衍生风格**

Atmospheric Drum and Bass

Atmospheric Drum and Bass创造了一种更平静但更合成的声音。它由Calibre、Zero Tolerance (Zero T) &
Beta 2、London Elektricity、High Contrast、Logistics、Nu:Tone、Danny
Byrd、Cyantific、Netsky、Lenzman、Technimatic (Technicolour & Komatic)、Hobzee &
Zyon Base、Paul T & Edward Oberon、Hybrid Minds以及Hospital Records、Fokuz
Records和Liquid V等厂牌所开创。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drum_and_bass#Light_drum_and_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=112
