#Skweee
##基本信息
###发源时间：Late 2000s (decade)
###风格类型：Chiptune
##详情
Skweee是一种音乐风格，起源于瑞典和芬兰。Skweee将简单的合成器/chiptune主音和basslines与funk、R&B或soul-
like节奏相结合，整体呈现出一种脱俗的funky声音。曲目以器乐为主，但也有例外。"skweee "这个名字是由Daniel
Savio创造的，他是这个新兴声音的发起人之一。这个名字指的是在制作过程中使用模拟合成器，目的是尽可能 "挤出 "最有趣的声音。



制作人可以不同，从著名的艺人到斯堪的纳维亚电子乐环境中的新秀。



专注于skweee的博客Skweeelicious，以及Myspace和Nation of
Skweee等社区网站对skweee音乐的传播和公众对这一音乐类型的接触起到了重要作用。



Skweee音乐的主要销售渠道是瑞典的Flogsta
Danshall唱片公司和芬兰的Harmonia唱片公司，后来挪威的Dødpop、加拿大的Ancient
Robot、美国的Losonofono、美国的Titched、美国的Poisonous Gases、西班牙的Lo Fi
Funk、芬兰的Massy和法国的Mazout也加入了这个大家庭。Skweee爱好者首选的媒体格式是7
"黑胶唱片。早期的唱片都是以这种格式发行的。然而最近，一系列12寸黑胶唱片、数字版本和CD合集也通过这些渠道发行。



随着Skweee流派的知名度越来越高，导致了诸如Planet Mu的Eero Johannes专辑和Ramp Recordings的Skweee
Tooth合辑的发行。



Skweee和dubstep
Skweee在2008年底和2009年初开始影响dubstep的声音。在dubstepforum上发起的一个帖子让现场的人知道了Skweee。制作人如Rusko,Gemmy,Joker,Zomby,Rustie,等等，都对这个声音做出了自己的贡献，从而在skweee和dubstep之间发布了几张唱片。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=370
