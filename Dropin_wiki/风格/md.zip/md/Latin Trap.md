#Latin Trap
##基本信息
###发源时间：2000s–2010s
###风格类型：Trap
##详情
Latin trap是一种音乐流派，受southern
trap和波多黎各reggaeton的影响，在2007年之后获得流行，并自那以后传播到整个美洲。Latin
trap与主流trap相似，歌词描写的是街头生活。



**特点**

声乐包括说唱和歌唱的弯曲，通常用西班牙语，同时仍然保持着trap的声音回路。Latin Trap的歌词往往是关于街头生活、暴力、性和毒品。

  
**历史**

2000年,Latin Trap起源于波多黎各，并在整个拉丁美洲流行。确切的起源日期不详，一直被广泛争论。Puerto Rican reggaeton
和Latin trap歌手Ozuna表示，它起源于2007年的歌曲 "El Pistolon"，由Arcangel & De La Ghetto、Yaga
& Mackie、Jowell & Randy（前两人当时是双人组合）演唱。De La Ghetto则表示，他大约从2005年或2006年开始演唱Latin
trap，人们认为 "他疯了"。此时的Reggaeton 乐队艺术家希望将美国嘻哈和R&B的元素介绍给西班牙观众。2010年代的Latin
Trap在2014年左右开始崭露头角，当时Alvaro Diaz、Myke Towers和Fuete
Billete等艺术家开始通过社交媒体平台发布他们的歌曲，他们是第一批使用早期Latin
Trap节奏说唱的波多黎各艺术家。这种新的声音最终在波多黎各流行起来，并出现了许多Latin Trap歌曲，如Bryant Myers的 "Esclava
Remix"、Lary Over和Brytiago的 "Tu Me Enamoraste Remix"、Farruko的 "Ella y Yo "和De
La Ghetto的 "La Ocasion"，Ozuna认为后者将Latin Trap扩展到了国际上。2017年7月，《The
Fader》写道："从波多黎各到哥伦比亚的说唱歌手和雷鬼歌手们将trap的元素--颠簸的低音线、抖动的808s和眼睛半闭的氛围--
注入到一个又一个的banger中。" 在2017年8月Billboard的一篇系列文章 "A Brief History Of
"中，他们邀请了一些Latin Trap的著名艺术家，包括Ozuna、De La Ghetto、Bad Bunny、Farruko和Messiah--
讲述了关于这一流派的简史。Rolling Stone的Elias Leight指出："Fonseca以Puerto Ricana为特色。"Fonseca
在汇编《Trap Capos》中收录了Anuel AA、Bryant
Myers和Noriel等波多黎各艺术家的作品。第一季》，成为第一张登上Billboard拉丁节奏专辑排行榜第一的 "Latin Trap "LP。"
许多其他的reggaeton和Latin Trap艺术家为Latin Trap的流行做出了贡献，比如Bad Bunny带领了Latin
Trap流派流行起来。Bad Bunny制作的多首歌曲进入了Billboard的拉丁歌曲热门榜单，并与Nicki Minaj、Travis
Scott和Cardi B等美国人气艺人有多次合作，他很快就成为了Latin Trap突然流行起来的代言人。通过与其他艺术家的合作，比如他出现在Becky
G的 "Mayores "中，Bad Bunny是第一批在电台上说唱的Latin Trap艺术家之一。他在电台上的出现使Latin
Trap在美国得到了更多的认可。他的首张专辑《X 100pre》于2018年12月发行，并获得了拉丁格莱美最佳城市音乐专辑奖。2018年4月，Nio
Garcia、Casper Magico、Darell、Ozuna、Bad Bunny和Nicky Jam发行了一首混合了Latin
Trap和reggaeton的歌曲 "Te Bote"。它成为第一首带有Latin
Trap元素的歌曲，在美国公告牌热门拉丁歌曲排行榜上排名第一。目前，它在YouTube上的点击率超过18亿次。2018年，Cardi B与Bad
Bunny和J Balvin合作的热门单曲 "I Like It "成为第一首登上美国Billboard Hot 100榜单的Latin Trap歌曲。

  
**批评**

Latin Trap无法在电台播放，源于歌词的亵渎和淫荡。Maluma的歌曲 "Cuatro Babys
"因其歌词而受到很多争议，因为它们可以说似乎暗示着对女性的暴力。Change.org上发布了一份请愿书，要求从数字平台上删除这首歌。尽管有这样的争议，但
"Cuatro Babys "的人气却只升不降，这首歌已经获得了四倍白金唱片。正因为如此，Latin
Trap有了一大批粉丝，但主要是地下粉丝。2018年9月15日，Anuel
AA发布了一首针对同门说唱歌手Cosculluela的diss歌曲。这首歌曲因其粗口和对同性恋和HIV患者的攻击性言论而受到广泛的批评。由于公众的反感，Gazmey原定于当年10月12日在波多黎各Coliseo
de Puerto Rico场馆举行的演唱会被他的制作人员和主要制作人Paco Lopez取消。Gazmey后来就这首歌发表了道歉声明。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=302
