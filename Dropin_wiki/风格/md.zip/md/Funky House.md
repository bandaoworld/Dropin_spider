#Funky House
##基本信息
###发源时间：Late-1980s
###风格类型：House
##详情
Funk
House（放克浩室）是house音乐的一个子流派，它使用迪斯科和放克样本，以放克风格为灵感的低音线或强烈的灵魂影响力，结合鼓声，从20世纪70年代和80年代的放克唱片中获得灵感。迪斯科弦乐的使用在该流派中也很常见，尽管并非总是如此。Funky
house使用特定的技术和特定的声音，特点是bassline、swooshes、swirls和其他合成声音，使音乐具有128 BPM左右的跳动节奏。



这种风格在商业上很受欢迎，Defected Records、Ministry of Sound、Hed Kandi、Fierce
Angel等唱片公司都推出了专门针对这种风格的合辑。



**历史**

Funky House在2000年代初和中期（十年左右的时间）特别成功。



2010年代至今，随着2010年代初人们对Funk和Disco的重新关注，Funky
House这个音乐类型经常被误用。当代音乐人在制作House音乐时，以Funk和Disco的样本为基础，但歌曲的结构和特点仍然是来自于普通House。这类音乐通常被称为funk-
house，是母体类型的发展，与funky house没有关系。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Funky_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=63
