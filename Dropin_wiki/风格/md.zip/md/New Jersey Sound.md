#New Jersey Sound
##基本信息
###发源时间：Early 1980s
###风格类型：House
##详情
New Jersey Sound（或Jersey
Sound）是20世纪80年代初起源于新泽西州纽瓦克市的一种House音乐流派。它是一种Deep/Garage
House音乐，强调受纽瓦克Gospel音乐传承影响的灵魂乐之声。



**历史**

New Jersey Sound（新泽西之声）起源于20世纪80年代。1982年，在新泽西州纽瓦克的桑给巴尔俱乐部（DJ Tony
Humphries在这里开始驻扎）等地方，帮助 "催生了有时生硬但充满灵魂和福音的子流派 "的deephouse音乐，被称为泽西之声。 除了 "New
Jersey house"这个名词之外，这个流派还有其他的名字："在英国，由于相当不可思议的原因，它被称为车库音乐（以纽约的Paradise
Garage命名），而在新泽西本身，他们干脆把它称为俱乐部（或者也许更贴切地说是泽西声）。" 纽瓦克女歌手以house音乐DJ Larry
Levan的混音而著名，包括Gwen Guthrie（"Ain't Nothin' Goin On But The Rent"）和Taana
Gardner（"Heartbeat"）。



1992年，来自Union County的Aly-Us发行了deephouse主打歌 "Follow Me"。



阿比盖尔-亚当斯的house音乐唱片公司和商店，位于纽瓦克（Newark）邻国东奥兰治（East Orange）的莫文唱片（Movin
Records），也是泽西之声的另一位贡献者。



Jersey Club的场景也催生了纽瓦克酒店和夜总会的舞会文化。"House女王 "Crystal
Waters和其他House名人在纽瓦克现场表演。另一位桑给巴尔DJ Kerri Chandler是 "泽西之声
"各种House音乐的另一位先驱。诸如Jomanda这样的泽西州艺术家在90年代初的House音乐界获得了成功。有人说，"当纽约流行说唱时，泽西岛偏爱俱乐部，因为有Zanzibar夜店"。



**音乐节**

每年的夏季活动，如瓦里南科公园的Roselle House音乐节、Trenton House音乐节、Weequahic Park
House音乐节和Lincoln Park音乐节，都会吸引家庭和house音乐爱好者，也就是所谓的
"househeads"，致力于80年代泽西州的经典音乐。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/New_Jersey_sound
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=80
