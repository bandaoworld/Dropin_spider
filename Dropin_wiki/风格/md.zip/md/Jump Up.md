#Jump Up
##基本信息
###发源时间：90年代中起
###风格类型：Drum and Bass
##详情
Jump Up是Drum and Bass的一个子流派，最早流行于90年代中期。这类音乐通常都是轻快的，以嘻哈采样和突出的旋律Bassline为特色。



**历史**

Jump Up这个词来源于早期使用的 "Jump-
up"，最早指的是那些通常是Ambient氛围前奏的歌曲，这些曲目在Drop时会改变风格，通常是通过转换至"amen
breakbeats"采样节奏，这将使听众"Jump-up（跳起来） "并开始跳舞。



大约在1994年，它开始被更多地应用于带有嘻哈采样和振荡Bassline的唱片，比如Suburban Bass艺术家Dream Team和DJ
Hype，而到了1995年，更具体地应用于与DJ Zinc和Ganja唱片相关的风格。"Yeah Man Remix"--Dream
Team（1995年）和DJ Rush Puppy "Bad Man Lighter--Jump Up
Remix"（1995年）是两个很好的例子，虽然曲子不一定会使用amen breaks，但这种风格会更具体地被称为jump-
up。到了1996年，它特别指的是由DJ Zinc、Aphrodite和Dillinja等艺术家录制的风格（还有很多其他的艺术家），这可能包括amen
breakbeats，但更多的时候是有一个step-break，或者只用amen或其他breaks作为歌曲后面部分的额外舞池燃点。



艺术家们制作的风格有很多交集，一个艺术家的jump-up风格可能与另一个艺术家的完全不同。比如Aphrodite的jump-
up唱片，风格就比较有起伏波动。"Drum and Bass"（见DJ Rush Puppy "Silencer - Drum and Bass Mix
"1995）会被用于鼓点较多的唱片，或者是听起来比较电子化的唱片（比如后来被称为techstep的风格）。



这里甚至有更多的交叉，因为在 "Drum and Bass "这个名词还没有出现之前，就有这种风格的唱片，而 "jump-up jungle
"以前并不是一个流派，而是指那些中途改变风格的Jungle唱片。现在这些唱片可以改称为 "Drum and
Bass"，以区别于那些听起来更像Jungle的匪帮、Rolling和Jump-up风格。但由于现在 "Drum and Bass
"作为整个音乐风格的名称比 "Jungle "更受欢迎，所以很多曲目都可以归类为 "Drum and
Bass"。而到了2000年代后期，越来越多带有轻快感的新曲子也开始更多的被称为 "Jump Up"。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/jump+up
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=114
