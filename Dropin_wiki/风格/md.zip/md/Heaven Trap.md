#Heaven Trap
##基本信息
###发源时间：
###风格类型：Trap
##详情
Heaven
Trap是Trap音乐的分支，在Trap音乐节奏型、鼓组和强劲808低音部分的基础上，加入较强混响的合成器旋律，使之增添了空灵、唯美、大气的听感。Heaven
Trap融合了Trap，Future Bass，Trance等风格的音乐特色，目前更多被认为是一种风格标签，代表艺人包括RL Grimes,
SLANDER等。

###本词条汉字内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=159
