#Harsh Noise Wall
##基本信息
###发源时间：Early 2000s
###风格类型：Harsh Noise
##详情
Harsh noise wall，也称为wall noise或static noise，是noise
music的一种极端子流派，被描述为"一堵完全一致的、毫不畏缩的、由单一噪声构成的包围墙"。该运动由法国音乐家Vomir率先提出，他的审美是"没有思想，没有变化，没有发展，没有娱乐，没有悔恨"。



Harsh noise wall具有将噪音分层在一起以形成静态声音的功能。Harsh noise wall音乐家Sam MacKinley，也被称为The
Rita，将该类型视为"将Japanese harsh noise净化为更加精致的紧缩形式，从而用缓慢移动的形式使得简约纹理中的失真音质得以结晶。"



尽管大部分情况都停留在地下，但Harsh noise wall却在狂热的追随者中引起了强烈的反响。 Vomir在Les
InstantsChavires，Montreuil，Seine-Saint-Denis由Vomir组织了一系列针对该类型的活动，命名为"Harsh
Noise Wall Festival"，来宾包括著名的音乐家，如Werewolf Jerusalem，TheNightProduct，Black
Leather Jesus和Tissa Mawartyassari。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Harsh_noise_wall
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=253
