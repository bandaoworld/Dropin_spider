#uptempo hardore
##基本信息
