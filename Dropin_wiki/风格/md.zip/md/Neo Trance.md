#Neo Trance
##基本信息
###发源时间：2000s早期
###风格类型：Trance
##详情
Neo
Trance是Trance音乐的一个子流派了，最早出现于2000年代初期，用于描述向更为简约方向发展的Trance分支。它是通过使用不符合或不坚持先前的Trance的各种音乐方面来定义的。Neo
Trance音乐使用更深沉、有时更有含义的歌词。参与 Neo-trance 创作的艺术家经常与以前只在 trance 领域之外进行录音的歌手合作。



Neo Trance本身源于极简音乐和电子音乐，同时通常会添加旋律元素和Breakdown，将曲目带入Neo Trance的氛围钟。最早时 Minimal
techno 制作人开始制作一些旋律（尽管不是典型的 trance 弦乐），这个 mini-techno 的新分支开始流行起来，充满旋律的 Trance
便与这个音乐分支有关。通常，Neo-Trance给人一种更黑暗的感觉。



"Neo-trance"一词最早出现在英国的 DJ 杂志上，由音乐评论家兼记者 Tim Stark 用来描述德国制作人和 DJ Kyau & Albert
的作品。它随后被采用并且该团体开始在整个 trance 场景中扩散，但是 Kyau & Albert 不是新 trance 领域的新人，因为他们主要制作
Progressive Trance。一些人还认为，克罗地亚制作人达米尔*普什卡 (Damir Pushkar) 是第一个通过描述他的曲调使用"Neo
Trance"的人。



与该流派相关的艺术家包括德国艺术家 Stephan Bodzin、Dominik Eulberg、Ellen Allien、Gabriel
Ananda、Paul Kalkbrenner、Extrawelt、Pantha Du Prince 和 Gregor Tresher，以及国际艺术家，如
James Holden、Deadmau5、Nathan Fake、Oxia、 Gui Boratto 和 Trentemøller。Neo
Trance也与新的Electro和Electroclash运动有关。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/neo+trance/wiki
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=172
