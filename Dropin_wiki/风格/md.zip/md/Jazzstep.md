#Jazzstep
##基本信息
###发源时间：
###风格类型：Drum and Bass
##详情
Jazzstep，又称Jazzy Jungle。这类风格受爵士乐的影响很大，它使用典型的爵士乐音阶、节奏和乐器。著名的艺术家包括Roni
Size、Reprazent、Goldie、Utah Jazz、Morgan Sullyvan、Makoto、Alex Reece、和DJ
Dextrous。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drum_and_bass#Light_drum_and_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=113
