#Eurotrance
##基本信息
###发源时间：1990s末期
###风格类型：Trance
##详情
Eurotrance是一种融合Hard Trance和Eurodance音乐风格特点的Trance子类型，在1998年末至2000年这段时间最为流行。

###本词条汉字内容由 @多频百科团队 编辑+翻译
https://en.wikipedia.org/wiki/List_of_trance_genres
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=168
