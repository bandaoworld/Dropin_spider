#Hardbag
##基本信息
###发源时间：mid-1990s
###风格类型：Diva House
##详情
Hardbag是90年代中期流行的一种电子舞曲类型。从1993-1994年的Diva House（Handbag
House）演变而来，这种类型享有巨大的知名度，尽管是短暂而流行化的，很多Hardbag作品都排行在UK榜单的上层位置。在当时，它有时会与Nu-
NRG混淆，然而这两种风格却有明显的不同。



由Felix演唱的 "Don't You Want Me "在很大程度上被认为是引发hardbag爆炸的歌曲。由Faithless、Red
Jerry和Felix的Rollo Armstrong制作的 "Don't You Want Me "于1992年发行，在英国单曲榜上获得了前十名的成绩。



1995年，随着Commandor Tom、Candy Girls、Rollo & Sister Bliss和Mrs
Wood的发行，hardbag风格的流行达到了顶峰，都跨入了主流。事实上，这种声音开始与makina融合，这在Interactive的 "Forever
Young "和Seb的 "Rainbow Islands "等曲目中表现得很明显。



最有影响力的两位制作人是荷兰制作人帕特里克-普林斯（Patrick Prins）（他用各种化名录制了几首英国俱乐部和排行榜上的热门歌曲，如 "Bits &
Pieces"--Artemesia）和已故的托尼-德维特（Tony De Vit），他的hardbag作品 "Hooked
"至今仍被认为是这一流派的权威性例子之一。另一位在hardbag界的伟大存在是Red Jerry，Hooj
Choons的前负责人。其他有影响力的制作人还包括Rollo Armstrong（后来的Faithless组合）和Paul
Masterson，后者将hardbag混音多样化，加入Hi-NRG元素。



到1997年初，Hardbag的热潮逐渐消退，自此Hardbag对英国硬浩室和Electro house产生了影响。诸如Tripoli
Trax这样的厂牌通过发行Lemon 8的 "Bells Of Revolution "和Knuckleheadz的 "Raise Your Hands
"来阐述这种声音。



几位hardbag制作人在90年代后期成为了trance场景中的大人物。这些人包括Matt Darey（担任Bi-Boy Action
Squad，Orgasmatron和Space Baby），Sister Bliss（与Rollo和Joyd
Wimmin的Jon共同创作和共同制作），以及John Graham，他的Quivver别名"Saxy
Lady"（1994年）的hardbag形象大受欢迎。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Hardbag
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=50
