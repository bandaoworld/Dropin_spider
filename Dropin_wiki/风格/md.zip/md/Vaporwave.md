#Vaporwave
##基本信息
###发源时间：Early 2010s
###风格类型：Hauntology
##详情
Vaporwave（蒸汽波）是一种电子音乐的微流派，同时也是一种视觉艺术风格，是2010年代初出现的一种网络流行文化。它的部分定义是由它对20世纪80年代和90年代的smooth
jazz, elevator, R&B, 和lounge
music的放慢、切碎和扭曲的样本。周围的亚文化有时与消费资本主义和流行文化的一种模棱两可的或讽刺的看法联系在一起，并倾向于以怀旧或超现实主义的方式参与前几十年的流行娱乐、技术和广告为特征。在视觉上，它将早期的互联网图像、20世纪90年代末的网页设计、glitch
art、动漫、3D渲染对象和赛博朋克的主题融入到封面作品和音乐视频中。



Vaporwave起源于chillwave的一个讽刺性变体，从hypnagogic pop以及类似的retro-revivalist和post-
Internet
motifs主题演变而来，这些主题在那个时代的地下数字音乐和艺术场景中已经变得很流行，比如Tumblr的seapunk。这种风格是由James
Ferraro、Daniel Lopatin和Ramona Xavier等制作人开创的，他们各自使用了不同的假名。在Xavier的专辑《Floral
Shoppe》（2011年）为这一风格确立了蓝图之后，这一运动在Last.fm、Reddit和4chan等网站上建立起了观众群，而大量同样以网络假名运作的新乐队则转向Bandcamp进行发行。



2012年，随着Vaporwave的广泛曝光，出现了大量的子流派和分支，如future funk, mallsoft,
和hardvapour，不过大部分的流行度已经下降。该流派还与街头服饰等时尚潮流和各种政治运动交织在一起。自2010年代中期以来，Vaporwave经常被描述为一个
"死亡
"的流派。公众开始将Vaporwave视为一种网络追忆，这种观念让一些希望被认可为严肃艺术家的制作人感到沮丧。许多与Vaporwave有关的最有影响力的艺术家和唱片公司此后都转向了其他音乐风格。



**特点**

Vaporwave是一个特殊的亚流派（或
"微流派"），它既是一种电子音乐的形式，也是一种艺术风格，尽管它有时被认为主要是一种视觉媒介。这个流派在很大程度上是由它周围的亚文化所定义的，它的音乐与它的视觉描述密不可分。学者Laura
Glitsos写道："这样一来，Vaporwave就违背了传统的音乐惯例，通常将音乐优先于视觉形式。"
vaporwave主要借鉴了20世纪80年代和90年代早期的音乐和文化资源，建立在chillwave and hypnagogic
pop音乐的实验性和讽刺性倾向的基础上，同时也与对消费资本主义和技术文化的暧昧或讽刺联系在一起。"vaporwave "这个名字来源于
"vaporware"，这是一个术语，指的是宣布但从未发布的商业软件。创作一首vaporwave音乐只需要掌握基本的制作技术。它几乎完全由慢速采样组成，并通过使用斩波和拧波技术、重复和重混响来颠覆20世纪80年代和90年代的舞蹈音乐。评论家Adam
Trainer写道，这种风格偏爱 "与其说是为享受而制作的音乐，不如说是为调节情绪而制作的音乐"，比如用于信息广告和产品演示的企业股票音乐。学者Adam
Harper将典型的vaporwave乐曲描述为
"完全合成或经过大量处理的一大块企业情绪音乐，明亮而认真，或缓慢而闷骚，通常很美，要么是循环失调，超越了功能点"。加上其与音乐和视觉艺术形式的双重参与vaporwave拥抱互联网作为一种文化、社会和审美媒介。视觉美学(通常风格为
"AESTHETICS"，字符为全宽)融合了早期的互联网图像、20世纪90年代末的网页设计、突波艺术和赛博朋克题材，以及动漫、希腊罗马雕像和3D渲染的物体。VHS退化是另一种常见的vaporwave艺术效果。



一般来说，艺术家们将素材的年代限定在20世纪80年代日本经济蓬勃发展到2001年的9.11事件或网络泡沫破裂之间（包括Floral
Shoppe在内的一些专辑的封面上描绘了完整的双子塔）。



**历史**

起源和前驱者

Vaporwave起源于2010年代初的互联网上，是chillwave的一种讽刺性变体，也是Ariel Pink和James
Ferraro等hypnagogic pop 音乐人作品的衍生，他们的特点是引用复古流行文化。它是这个时代出现的众多互联网微流派之一，与witch
house, seapunk, shitgaze, cloud
rap,等齐名。chillwave与一个更广泛的趋势不谋而合，这个趋势涉及到年轻艺术家，他们的作品取材于他们在80年代的童年。"Chillwave "和
"hypnagogic pop
"几乎是在同一时间，也就是在2009年中期被创造出来的，并被认为是可以互换的术语。像vaporwave一样，它们参与了怀旧和文化记忆的概念.其中最早预见vaporwave的催眠行为是Matrix
Metals和他的专辑《Flamingo Breeze》（2009年），该专辑建立在合成器循环上.大约在同一时间，Daniel
Lopatin（Oneohtrix Point
Never）以别名sunsetcorp的名义偷偷上传了一个掠夺phonics循环的集合到YouTube上。这些片段取自他的视听专辑《Memory
Vague》（2009年6月）。Washed Out的 "Feel It All Around"（2009年6月），将1983年Gary Low的意大利舞曲
"I Want You "放慢了速度，体现了vaporwave艺术家试图重构的 "模拟怀旧 "的chillwave。



Vaporwave被归入了更大的 "Tumblr美学
"之下，而这种美学在2010年代的地下数字音乐和艺术场景中已经成为一种时尚。2010年，Lopatin将Memory
vague中的几首曲目以及一些新的曲目收录在他的专辑《Chuck Person's Eccojams Vol.1》中，于8月以 "Chuck Person
"的别名发行。这张专辑的包装与1993年的电子游戏《Ecco the
Dolphin》相似，激发了许多郊区青少年和年轻人形成了后来的vaporwave。2011年中，Seapunk作为一种以水族为主题的Tumblr亚文化和网络追忆，在其对
"spacey
"电子音乐和Geocities网络图形的关注中，预示着vaporwave的诞生。和vaporwave一样，它也被定义为与互联网的接触（有时被描述为后互联网）。vaporwave的音乐模板来自Eccojams和Ferraro的Far
Side Virtual（2011年10月）。Eccojams的特色是对20世纪80年代的流行歌曲进行删减和扭曲的变体，而Far Side
Virtual则主要借鉴了Skype和任天堂Wii等过去媒体的 "颗粒状和爆炸性的哔哔声"。根据Stereogum的Miles
Bowe的说法，vaporwave是Lopatin的 "斩钉截铁的plunderphonics "和 "James Ferraro的Muzak-
hellscapes的虚无主义易听
"之间的融合。2013年某音乐博客上的一篇文章将这些专辑与Skeleton的Holograms（2010年11月）一起称为 "proto
vaporwave"。早期的场景Vaporwave艺术家原本是 "潜伏在互联网上的神秘且常常是无名的实体"，Adam
Harper指出，"他们往往隐藏在一个伪公司名称或网络外衣的背后，他们的音乐通常可以通过Mediafire、Last
FM、Soundcloud或Bandcamp免费下载。"



根据Metallic Ghosts（Chaz
Allen）的说法，最初的vaporwave场景来自于Turntable.fm网站上形成的一个在线圈子。这个圈子里的人包括互联网俱乐部（Robin
Burnett）、Veracom、Luxury Elite、Infinity Frequencies、Transmuteo（Jonathan
Dean）、Coolmemoryz和Prismcorp。这个网络环境的众多制作人从Ramona Xavier的New Dreams Ltd.获得灵感。(记入
"Laserdisc Visions"，2011年7月)。第一次报道使用
"vaporwave"一词是在2011年10月的一篇博客文章上，由一位匿名用户评论Girlhood的专辑《Surf's Pure
Hearts》，然而，Burnett被认为创造了这个词，以此将这个圈子联系起来。Xavier's Floral Shoppe（归功于 "Macintosh
Plus"，2011年12月）是第一张被认为是该风格的正确专辑，包含了该风格的所有核心元素。Vaporwave在2012年中发现了更广泛的吸引力，在Last.fm、Reddit和4chan等网站上建立了受众。9月，Blank
Banshee发行了他的首张专辑《Blank Banshee
0》，这反映了vaporwave音乐制作人的趋势，他们更多的受到trap音乐的影响，而不太在意传达政治内涵。Bandwagon称这是一张
"进步的唱片"，它和Floral Shoppe一起，"标志着第一波重采样音乐的结束，......重构了制作vaporwave音乐的意义"。



在大量新的vaporwave乐队转向Bandcamp进行发行之后，各种在线音乐出版物，如Tiny Mix
Tapes、Dummy和Sputnikmusic开始报道这场运动。然而，作家、粉丝和艺术家们努力区分vaporwave, chillwave, 和
hypnagogic pop音乐，而The Essential的Ash Becks指出，像Pitchfork和Drowned in Sound这样的大型网站
"似乎拒绝在该流派两年的'高峰期'中接触vaporwave"。常见的批评是，这个流派 "太笨 "或 "太知识分子"。



主流曝光与 "死亡"

2012年11月，seapunk美学被流行歌手蕾哈娜（Rihanna）和阿泽利亚-班克斯（Azealia
Banks）在音乐视频中挪用。这次曝光将亚文化推向了主流，随之而来的是vaporwave。同月，优酷网友Anthony Fantano发表的《Floral
Shoppe》的视频评论，帮助巩固了这张专辑作为vaporwave的代表作品的地位。这样的宣告来自于乐迷自己。在最初的浪潮之后，4chan和Reddit上的用户们发明了一些新的术语，他们试图将vaporwave分成多个子流派，有些是开玩笑的，比如
"vaportrap"、"vapornoise "和 "vaporgoth"。更多的子流派包括 "eccojams"、"utopian
virtual"、"mallsoft"、"future funk", "post-Internet", "late-nite lo-fi", "broken
transmission" (或 "signalwave"), and "hardvapour"。Complex的Joe
Price报道说，"大多数流派都消失了，许多风格从一开始就没有意义。...
视觉方面的形成速度比声音快，导致发布的作品看起来一样，但却无法形成一个声音上有凝聚力的整体。"
2013年，YouTube开始允许其用户举办直播，结果出现了一大批24小时的 "电台"，专门为vaporwave和lo-fi hip hop等微流派服务。



瑞典说唱歌手Yung Lean和他的Sad
Boys团队鼓舞了一波匿名DJ创作vaporwave混音，上传到YouTube和SoundCloud上，这些混音挪用了任天堂64电子游戏的音乐和图像。标题包括
"Mariowave"、"Nostalgia 64 "和 "Z E L D A W A V E"。Dazed Digital的Evelyn
Wang将Lean归功于 "允许Vaporwave在IRL上泄露，鼓励其与街头服饰的不和谐耦合"。她列举了他们相关的时尚主打是
"皱眉脸、作为配饰的日文和阿拉伯文、运动装品牌、亚利桑那冰茶，以及同时在传播中成为meme的不可思议的能力"。2013年底，Thump发表了一篇文章，标题为
"Is Vaporwave the Next Seapunk?"虽然作者预言Vaporwave不会像seapunk那样 "作为一个笑话
"而结束，但这种风格在很大程度上被视为一种面目狰狞的互联网meme，主要基于复古的视觉风格或
"氛围"，这种观念让一些希望被认可为严肃艺术家的制作人感到沮丧。许多与该流派相关的最有影响力的艺术家和唱片公司后来都转移到了其他音乐风格中。2015年，《滚石》杂志发表了一份名单，将vaporwave
act 2814列为 "你需要知道的10位艺术家 "之一，并将他们的专辑《新一天的诞生》（Birth of a New Day）称为
"在互联网的一个小而充满激情的口袋里取得了无与伦比的成功"。在Fact榜单 "2015年50张最佳专辑 "中，Death's Dynamic
Shroud.wmv的专辑《I'll Try Living Like This》位列第十五位，同一天，MTV国际台推出了深受vaporwave 和
seapunk启发的品牌重塑，Tumblr推出了一款名为Tumblr TV的GIF查看器，并明确了MTV风格的视觉效果。嘻哈歌手德雷克在7月31日发布的单曲
"Hotline Bling "也受到了vaporwave制作人的欢迎，激发了人们对这首曲子进行幽默和严肃的混音。截至2016年，包括《Floral
Shoppe》在内的vaporwave专辑继续位列Bandcamp上最畅销的实验专辑。该场景还在Reddit.Price等社区上拥有着一个专门的追随者，报道称，对于这些舞台之外的人来说，该流派通常被认为是
"一个大笑话"。他补充说："各种vaporwave
Reddits的用户在大多数情况下总是会非常认真地对待它，但即使在那里，人们也在讨论vaporwave是否还在继续强大。"
尽管他们反对这个标签，但运动中严肃的艺术家仍然被贴上了vaporwave的标签。



2019年，在YouTube有关互联网的视频中，注明 "AESTHETIC "的用户评论依然无处不在。该流派的著名人物乔治-克兰顿（George
Clanton）评论说，"vaporwave"的横幅仍然可以很好地为那些并不属于这一流派的音乐贴上营销标签。9月，他在纽约市组织了有史以来第一次的
"100%vaporwave音乐节"（100% ElectroniCON），Saint Pepsi、Vaperror、Nmesh、18 Carat
Affair等多位与该流派相关的艺术家以及Clanton本人都在现场进行了表演，其中大部分是他们职业生涯中的第一次。



**政治相关**

2012年12月，Dummy发表了一篇被认为是关于vaporwave的 "权威 "文章，作者是Adam
Harper，他在文章中把这种流派等同于加速主义政治理论。这篇文章激发了 "一波内容暧昧的庆祝荒诞的资本主义"。2016年初，讽刺刊物《Rave
News》报道称，著名的vaporwave制作人在蒙特利尔安排了一次紧急峰会，讨论现场
"蠕动的法西斯主义"。虽然这篇文章很有面子，但它的评论区吸引了许多为这种政治信仰辩护的vaporwave乐迷。"Daily Stormer
"的创始人安德鲁-安格林（Andrew Anglin）在8月建议alt-
right成员接受synthwave，而不是传统上与极右运动相关的摇滚类型，因为他觉得synthwave代表了 "有史以来最白的音乐"。他的言论普及了被称为
"fashwave "的音乐和视觉美学，这是一种受vaporwave启发的法西斯主义典故的更新，受到了许多超右翼成员的欢迎。



2017年，Vice的Penn Bullock和Eli Penn报道了自认为是法西斯主义者和alt-
right成员挪用vaporwave音乐和美学的现象，将fashwave运动描述为 "第一种足够容易入耳的法西斯主义音乐，具有主流吸引力"，反映了
"一种面向千禧一代的全球网络亚文化，由像Pepe the Frog这样的meme传播，以4chan这样的网站为中心"。《卫报》的迈克尔-汉恩（Michael
Hann）指出，这场运动并非史无前例，上世纪80年代的朋克摇滚和90年代的黑金属都有类似的分支。汉恩认为，和那些流派一样，pink
vaporwave"冲击主流 "的可能性很小。到了2019年，宣传2020年总统候选人Andrew Yang的pink
vaporwave风格的帽子在其支持者中流行起来。国家评论员西奥多-科普夫雷报道说，这是一种趋势的一部分，表明杨已经 "取代唐纳德-
特朗普成为meme候选人"。



**批评性解读 模仿、颠覆和流派**

vaporwave是2010年代初催生的几个微流派之一，是媒体关注的短暂焦点。正如Vice所引用的那样，各种音乐论坛上的用户对这一流派的描述各不相同，有的说是
"马克思主义者的chillwave"，有的说是 "post-elevator music"，有的说是 "corporate smooth jazz
Windows 95 pop"。与过去典型的音乐流派相比，它的流传更类似于一种互联网meme，正如作者乔治娜-博恩（Georgina
Born）和克里斯托弗-霍沃斯（Christopher
Haworth）在2017年所写的那样，Vaporwave的文化实践明知故犯地复制和嘲讽了社交网络的成瘾性，几乎是强制性的参与，用户社区的自愿劳动推动了系统的发展并产生了价值。



任何有互联网连接的人都可以产生vaporwave......。在情感渲染的推动下，这些meme的统一性在该流派活跃的网络亚文化中被迅速模仿。Pitchfork的撰稿人Jonny
Coleman将vaporwave定义为居于 "不可思议的流派"，它位于
"听起来很假的真实流派和可能是真实的假流派之间"。同样来自Pitchfork的Patrick St.Michel称vaporwave是
"互联网音乐的一个小众角落，由西方人用日本音乐、采样和语言来胡闹".Vice作家Rob Arcand评论说，"亚流派的快速扩散本身已经成为
"vaporwave "冲锋陷阵的一部分，指责这个流派本身的荒谬性，即使它看到艺术家们把它作为创新的跳板。" 文化评论家西蒙-雷诺兹（Simon
Reynolds）在谈到2018年 "Vaporwave "中 "所谓的颠覆性或模仿性元素 "时表示，该流派在某些方面已经成为modern trap
music and mainstream hip hop的多余部分。他认为 "还有什么比德雷克唱片或坎耶歌曲中的主观性更疯狂或更病态的呢? 黑人Rap n
B主流在声音和态度上比白人互联网-波西米亚的任何东西都更进一步。他们的角色是多余的。Rap和R&B......已经是Simulacrum，已经是颓废了。"
在2018年的一篇报道Monkees的Mike Nesmith对该流派的热情的文章中，作者Andy Greene将Vaporwave描述为
"边缘的电子乐子流派，很少有外界充满讽刺的追忆爱好者听说过，更不用说形成意见了。"Nesmith称赞了这种流派，并将其声音归结为让人高度联想到psychedelic的旅程。乐评人Scott
Beauchamp写道，Vaporwave的立场更侧重于失落、慵懒的概念和被动的默认，"Vaporwave是第一个从出生到死亡完全在线上生活的音乐流派".他认为，超调的表达方式激发了Vaporwave的发展和衰落。



**资本主义和技术**

Vaporwave被认为支持与消费资本主义的暧昧或加速关系。许多学术书籍已经出版了关于这个主题的书籍，这一趋势是由亚当-哈珀（Adam
Harper）在2012年发表的《假人》（Dummy）文章所引发的，并试图将这一流派与punk rock和反资本主义的姿态联系起来。
他在文章中写道，vaporwave制作者
"可以被理解为讽刺性的反资本主义者，揭示现代技术文化及其表象的谎言和滑坡，也可以被理解为它心甘情愿的促进者，在每一波新妙不可言的声音中高兴得发抖。"他指出，这个名字本身既是对vaporwave作品的点赞，也是资本主义下利欲能量被无情升华的想法。音乐教育家格拉夫顿-
坦纳写道："vaporwave是一种艺术风格，它试图重新安排我们与电子媒体的关系，迫使我们认识到无处不在的技术的陌生性......vaporwave是'非时间'和'非地点'的音乐，因为它对消费文化对时间和空间的影响持怀疑态度"。Vice旗下科技网站Motherboard的乔丹-
皮尔森（Jordan Pearson）在评论MTV国际采用vaporwave 和
seapunk风格的品牌重塑时指出，"催生vaporwave及其相关的基于Tumblr的美学的愤世嫉俗的冲动如何在两方面被共同利用和抹杀--
它的源头和它的生存地"。 Beauchamp提出，punk的 "没有未来 "立场及其源自Dada dystopia历史血统的积极的
"不满的原始能量"，与vaporwave对 "政治失败和社会反常 "的关注是平行的。



Vice的Michelle Lhooq认为，"模仿商业并不完全是目标。Vaporwave不仅仅是重现corporate lounge music--
它将其丰满成更性感、更合成的东西。" 在他2019年出版的Hearing the Cloud: Can Music Help Reimagine The
Future?一书中，学者埃米尔-弗兰克尔（Emile Frankel）写道，vaporwave被那些迷信20世纪80年代和 "retro synth-
pop "的人沦为 "自己的商业外壳"。他把这个场景比作PC音乐，这个标签
"被认为从对商业主义的讽刺性肯定扭曲成了普通的流行音乐。......任何以反讽作为批判方法的东西都有被误认的风险"。



**分支和子流派**

Future funk 在vaporwave的disco/house元素基础上进行了扩展.它采用了比vaporwave更有活力的方式，并融入了French
house的元素，尽管制作方式与vaporwave一样以样本为基础。这些样本大多来自80年代的日本城市流行唱片。Hardvapour
主条。Hardvapour
Hardvapour出现于2015年末，是对vaporwave的重新想象，主题更黑暗，节奏更快，声音更重。它受到了speedcore和gabber的影响，并针对有时归于vaporwave的乌托邦情绪来定义自己。Mallsoft
Mallsoft放大了vaporwave的lounge的影响。它可以被看作是与
"商场作为大的，没有灵魂的消费主义空间的概念......探索资本主义和全球化的社会后果"。



Fashwave

（来自 "fascist"）是一种主要由synthwave 和
vaporwave组成的器乐融合体，大约在2015年起源于YouTube。随着政治曲目的标题和偶尔的声音，该流派结合了纳粹象征主义与synthwave
和vaporwave相关的视觉效果。根据Hann的说法，它在音乐上源于synthwave，而Heavy贡献者Paul Farrell写道，它
"被认为是无害的vaporwave运动的一个分支。"一个类似的分支，Trumpwave，专注于唐纳德-特朗普。

###本词条内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Vaporwave
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=342
