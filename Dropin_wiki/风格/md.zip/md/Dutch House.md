#Dutch House
##基本信息
###发源时间：2009
###风格类型：Electro House
##详情
Dutch House（有时被称为"Dirty Dutch"），是一种发源于荷兰的Electro House子风格，2009年开始崭露头角。主要由Vato
Gonzalez和DJ
Chuckie开创。它的主要特点是以拉丁风格的鼓组、强调低频率的低音和吱吱作响的高音调主音合成Synth等元素为基础的复杂节奏。该风格受到的影响包括底特律Techno、嘻哈和其他Urban音乐风格。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_house#Dutch_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=54
