#Extratone
##基本信息
###发源时间：
###风格类型：Speedcore
##详情
bpm大于等于1000的歌曲被称为extratone歌曲。这种节奏的bpm节拍相当快，以至于无法区分单个拍子，使拍子听起来像一个恒定的音调。Extratone被认为是世界上最快的电子音乐流派，一些BPM超过9000个。"Extratone"这个名字来源于两个德语单词extrahieren（提取）和Ton（声音）的组合。



###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Speedcore#Extratone
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=214
