#Moombahsoul
##基本信息
###发源时间：2011
###风格类型：Moombahton
##详情
Moombahsoul是moombahton的一个子流派，并且收到Deephouse的影响。它结合了灵魂乐、lofi、Deephouse和寒潮的元素，并带有moombahton为背景的鼓点和韵味。David
Heartbreak在2011年推出了这个流派的第一张专辑《HEARTBREAK presents
MOOMBAHSOUL》。这15首歌曲包括Munchi、Heartbreak、DJ Theory等的曲目。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Moombahton#Moombahsoul
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=79
