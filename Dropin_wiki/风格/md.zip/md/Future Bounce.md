#Future Bounce
##基本信息
###发源时间：2014
###风格类型：Future House
##详情
Future Bounce是Future House的一种子风格，最早于2014年在互联网文化中诞生，并在2016/17年前后兴起。这种风格结合了Pop
EDM的元素并在DROP部分添加了Bouncy（跃动感）音色，使之具有灵动跳跃的标志性特色。



Future Bounce最早作为Future House的一个小分支标签出现，很多早期相关作品在当时都仅被制作人和乐迷认为是具有某种特点的Future
House。而随着其极具特色的弹性听感受到越来越多粉丝的喜爱，"Future Bounce"作为Future
House正式的一种子风格的定义从2015年后逐渐受到认可并推广开来。活跃在这一风格领域的艺术家包括Mike
Williams，Brooks，Mesto，Dropgun等人。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=65
