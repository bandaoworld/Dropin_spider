#Electro Swing
##基本信息
###发源时间：Early 1990s
###风格类型：House
##详情
Electro Swing（电子摇摆）是电子音乐的一种子风格，结合了老式和现代摇摆和爵士乐的影响，并结合了House，嘻哈和EDM。
该流派的成功实例创造了一种现代而集中在舞池上的声音，这种声音更容易被现代人听到，但也保留了现场铜管乐器和早期摇摆录音的活力。
电子摇摆乐队通常包括歌手，演奏传统爵士乐器（例如小号，长号，单簧管，萨克斯风）的音乐家和至少一个DJ。



一些著名的Electro Swing歌曲包括 Yolanda Be Cool 和 DCUP 的"We No Speak Americano"、Icona
Pop 的"Emergency"、Doop 的"Doop"、Fergie 的"A Little Party Never Killed No (All We
Got)" 、Q-Tip 和 GoonRock 以及 Momoland 的"Bboom Bboom"。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_swing
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=60
