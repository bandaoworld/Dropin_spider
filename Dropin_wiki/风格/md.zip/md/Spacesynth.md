#Spacesynth
##基本信息
###发源时间：20世纪70年代末
###风格类型：Euro Disco
##详情
Spacesynth（太空合成音乐）风格的源头可以追溯到"space disco"的开始----
20世纪70年代末舞曲的曲名、歌词和封面艺术作品中的科幻主题(外太空、机器人和未来)。这与当时整个社会的文化艺术环境都有或多或少的联系。1977年夏天上映的《星球大战》取得巨大成功，随后流行文化中对科幻主题的兴趣激增，世界范围内大量以科幻为主题、充满"未来主义"(电子合成器和琶音)的Disco音乐开始盛行。



**Spacesynth/Space Disco**

交集在Space Disco这个汇聚点的音乐包括Italo Disco、Electro和Synthpop，都具有"声码化的和声人声"（如 Mr.Flagio
的"Take a Chance"）和"未来感合成旋律"（ Kano的"Cosmic
Voyager"）的特点，这些音乐后来被称为Spacesynth或Space Disco。 在后来的几年里，它也受到巴西音乐、Funk和Jazz
Fusion的影响（详可另见：Afro/cosmic Music）。



在现代历史中，Space Disco的早期代表通常包括法国乐队 Space，和 Lindstrøm 的作品"I Feel Space"。



制作此类音乐的唱片公司包括

  * What We Want Records（美国纽约）

  * Lindstrøm's Feedelity（欧洲）

  * Eskimo、Bear Entertainment/Bear Funk、Prins Thomas' Full Pupp（比利时）

  * Tirk 和 DC Recordings（英国）



**Post-disco和House音乐**

自 1970 年代以来，总部位于纽约的Post-disco唱片公司 Emergency Records
专门从事重新发行/销售来自意大利的唱片（例如Kano的"I'm Ready"）。 Kano 是 Glen White
所在的组合，以在使用基本合成器的同时将美国音乐元素（受Funk较大影响、"breakbeat"节奏、声码器的使用）与电子音乐结合而闻名，这形成了 Italo
Disco最早的形式之一。 这种美国化的 Italo Disco 形式，代表人物还包括 Klein + M.B.O.（代表作"Dirty
Talk"、"Wonderful"、"The M. B. O. Theme"），它们重新进入美国市场并以对House音乐的发展产生影响而闻名。
Doctor's Cat的作品"Feel the Drive"同样是最早的House歌曲之一。



Emergency Records（美国纽约，1980 年代）是这一时期的代表唱片公司。







###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Italo_disco
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=227
