#Aggrotech
##基本信息
###发源时间：mid-late-1990s
###风格类型：Dark Electro
##详情
Aggrotech（也称为hellektro）是dark-electro的一种子流派，受到hardcore-
techno的强烈影响，最早出现在1990年代中后期。Aggrotech通常采用有侵略性的节拍，突出的主合成线以及暗黑的歌词。通常，人声会失真并变音，听起来刺耳，像合成的。另外还添加了静电和刺耳效果。Aggrotech的音乐家包括Agonoize,
Alien Vampires, Amduscia, Bestias De Asalto, Cenobita, Chiasm, Die Sektor,
Combichrist, Dawn of Ashes, Detroit Diesel, Dulce Liquido, DYM, Feindflug, God
Module, Grendel, Hocico, iVardensphere, Nachtmahr, Machine Sonata, Panic Lift,
Psyclon Nine, Reaper, Suicide Commando, Tactical Sekt, Tamtrum, The Retrosic,
Ritual Aesthetic, Unter Null, Virtual Embrace, X-Fusion等等。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.m.wikipedia.org/wiki/Electro-industrial#Aggrotech
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=265
