#Rabòday
##基本信息
###发源时间：Mid-2000s
###风格类型：Electronica
##详情
Raboday使用传统舞曲的节奏，用鼓声演奏，并编入电子音乐。



词源

Raboday这个名字是从数百种传统的Vodou节奏中借用的，这种节奏是Haitian音乐的基础。



起源

Raboday出现在2000年中期，其灵感来自于Rasin音乐，它是Haitian传统节奏和80年代以来 pop-rock
音乐的混合体。与Rasin音乐一样，Raboday谈论的是社会问题。Raboday的节奏是4/4的舞蹈节奏。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=362
