#Mahraganat
##基本信息
###发源时间：
###风格类型：African Electronic Dance Music
##详情
Mahraganat（英语：节日；埃及阿拉伯语：مهرجانات或Electro
Mahragan）是埃及电子舞曲的一种类型。Mahraganat是婚礼上播放的流行shaabi music和electronic dance
music的结合。DJ Figo在2011年埃及革命期间推出了他的团队 "set
dyaba"，使这一流派更加知名。虽然这可能是有史以来第一首进入主流的歌曲，但Mahraganat最初是由DJ El Sadat、Feelo、Zeezo
El Noby、Hamo
Beka在2006年首先构思的。他们通过MP3文件和手机分享他们的音乐，在出租车、tuktuks和大街上都能听到他们的音乐。第一个Mahragan
mix是在2008-09年由The group of friends发行的，名为"Mahragan Elsalam"，讲述了友谊和如何变得成熟。



历史

mahraganat（马赫拉甘的歌曲）的起源在于开罗的流行（sha'bi）街区和贫民窟。2006-7年，婚礼DJ开始将shaabi音乐和EDM结合起来，并受到reggaeton,
grime 和rap的影响。2011年，革命开始，这一流派反映了政治动荡，DJ Figo发布了他的第一首大单曲 "Ana Baba,
Y'llla"，最初，mahragan没有在电台或电视上播放，而是通过YouTube和SoundCloud等网站在网上传播。与mulid（sha'bi音乐的另一个子类型）一样，它是舞蹈音乐，不适合坐着听。Mahragan街头表演激发了狂野的、有时是杂技性的舞蹈，将嘻哈动作与raqs
baladi（埃及民间舞蹈）相结合。2014年，mahragan DJ
Souissy签下了唱片合约，EEK（纯音乐无歌词）等艺术家将这一风格带入了埃及的主流。到2014年夏天，mahraganat已经在整个埃及流行起来。在埃及以外，该流派被另类文化杂志Audio
Kultur和开罗解放阵线普及。舞蹈音乐博客Generation Bass也帮助将mahraganat介绍给欧洲观众。2014年，一群mahragan
DJ在荷兰巡演。2016年，Mahragan DJ Zola在革命五周年庆祝活动中被当街枪杀。政府宣布穆斯林兄弟会的抗议者应对枪击事件负责，而DJ
Sadat则认为警方应对此负责。一些年长且比较保守的埃及人认为这种风格很庸俗。这是因为表演者和粉丝的社会地位，有争议的话题和歌词风格，使用淫秽的语言，以及sarsagiyya(mahragan
fans)的个人风格。 2016年，Nagham FM广播电台禁止mahragan歌曲从其节目中播放，理由是它们 "不符合埃及的习俗和传统"。
然而，电视节目和音乐制作人采取行动来兑现新的趋势，签下了某些艺术家，如Oka &
Ortega，他们自2013年以来进行了更广泛的表演，并拍摄了一些商业广告，以及许多热门歌曲。2020年情人节当天，在开罗体育场举办了一场音乐会，邀请了amer
Hosny, Nancy Ajram, Wael Jassar等人参加。Mahraganat的主唱Hassan Shakoush也应邀与他的合作歌手奥马尔-
卡迈勒一起参加了音乐会，他们在音乐会上演唱了他们的超级大作《Bent El-Geran》（The Neighbor's
Daughter）。有鉴于此，社交媒体上出现了一些势头，批评他们所谓的部分歌词缺乏年龄适宜性，偏离了埃及的价值观。这些批评经常提到其中一句明确的台词，即
"我喝酒，抽Hashish"。然而，歌手们的反应则是发布了一个视频，他们声称所发生的事情是一个广告错误。在视频中，他们道歉并解释说，尽管另一个版本已经录制好了，但播放的是错误的版本，其中明确的台词被修改了。不久之后，埃及音乐家联盟决定在埃及禁止Mahraganat音乐，并拒绝Mahraganat歌手的会员资格，包括Mohamed
Ramadan。在流行文化中 2013年，Hind Meddeb发布了一部关于该流派的纪录片，名为《Electro Chaabi》。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=358
