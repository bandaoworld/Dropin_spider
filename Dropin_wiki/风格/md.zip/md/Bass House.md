#Bass House
##基本信息
###发源时间：2010s
###风格类型：House
##详情
Bass house 是一种出现在 2010 年代早中期的House子风格。该流派以 House 的节奏为基地、结合Deep House、Riddim
Dubstep 和 UK bass 的元素，曲速通常设置在 128 bpm 左右，并且经常包含高度失真的音色调制。早期的 Bass house
在各个频率区间都非常饱满，在DROP段落中通常只有一套 Bass Pattern；随着时间推移，许多 Bass house 制作人开始从 House
的其他子流派中找到灵感，尤其是 tech house，并将 Bass Pattern
与旋律分开。这个流派的代表人物包括Tchami、Joyryde、Jauz、Habstrakt、Jace Mek和LOOPERS等。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=43
