#Neoclassical Dark Wave
##基本信息
###发源时间：Mid-1980s
###风格类型：Dark Wave
##详情
Neoclassical dark wave指的是dark
wave音乐的一个子流派，其特点是空灵的氛围和天使般的女声，以及受到古典音乐的强烈影响。Neoclassical dark wave与被称为
neoclassical music的艺术音乐形式不同， neoclassical
music是一种可以追溯到20世纪初的古典音乐风格。在流行音乐的语境中，"neoclassical
"一词常被用来指代受古典音乐影响的音乐（包括巴洛克、古典、浪漫、印象派音乐的元素）。



**历史背景**

80年代中期，Dead Can Dance和In the Nursery两支乐队推出了颇具影响力的专辑，基本奠定了Neoclassical Dark
Wave风格的基础。1985年，Dead Can Dance发行了《Spleen》和《Ideal》，开启了乐队的 "中世纪欧洲之声"。1987年In the
Nursery发行了《Stormhorse》，表现出大胆的电影风格和交响乐/后工业化的声音，适合'被设想为戏剧性史诗的伴奏音乐'。这种音乐，"显然更多的灵感来自于古典音乐，而不是摇滚传统，有一种忧郁的，有远见的，有时是怀旧的品质"。著名厂牌
Equilibrium Music Hyperium Records Prikosnovenie。

###本词条内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Neoclassical_dark_wave
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=317
