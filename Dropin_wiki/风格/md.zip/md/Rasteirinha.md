#Rasteirinha
##基本信息
###发源时间：2012
###风格类型：Funk Carioca
##详情
Rasteirinha(或Rasterinha)是巴西的一种电子音乐流派，源于Funk
carioca、Reggaeton、Samba和axe。这种节奏源于贫民窟，像Omulu、DJ Comrade、Munchi和Buraka Som
Sistema这样的DJ将其传播到世界各地。

###本词条汉字内容由 @多频百科团队 翻译+编辑
https://en.wikipedia.org/wiki/Rasteirinha
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=293
