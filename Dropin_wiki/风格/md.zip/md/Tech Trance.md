#Tech Trance
##基本信息
###发源时间：Mid-1990s
###风格类型：Trance
##详情
Tech-trance，也称为Techno-trance或Techno/Trance，是电子音乐中的一个子风格，融合了Techno和Trance风格的元素



**历史**

Tech trance是由Oliver Lieb等人在20世纪90年代中期开创的，其他早期的tech-trance制作人还有Humate, Chris
Cowie和Marmion。在21世纪初，tech-trance朝着一个新的方向发展，在旧金山，在这一趋势中开拓的DJ有Keith Edwards,
Skyscraper, Owen Vallis和DJ Amber。到2006年，trance最广泛的变体是仍在增长和发展的Tech
trance类型，由Dave Schiemann、Simon Patterson、Bryan Kearney、Will Atkinson、Matt
Bowdige、John Askew、Ian Booth、Sam Jones、Will Rees、Indendent Noise、Marco V、Tempo
Giusto和Mark Sherry等制作人开创。



**风格**

Tech trance的定义特征是复杂的、大量量子化的电子节奏，由响亮的Kick Drum驱动，带有过滤、肮脏质感或轻微扭曲的hi-
hat声音和拍子；较硬的synth，通常带有大量共振或延迟；极简的pads，通常带有侧链以增加节拍的音量。早期版本的trance通常以钢琴、弦乐或原声吉他为特色，而tech
trance几乎只以合成声音为特色，尽管电吉他声音偶尔也会以合成声音为特色。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Tech_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=182
