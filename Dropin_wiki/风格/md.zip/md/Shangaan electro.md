#Shangaan electro
##基本信息
###发源时间：
###风格类型：African Electronic Dance Music
##详情
Shangaan electro是一种舞蹈运动和音乐风格，诞生于21世纪南非乡镇的当地民间传统，Tsonga Disco和Kwaito
House。这一运动近年来由DJ Khwaya和制作人Nozinja带头，他们把它变成了一种标志性的 Afro-futurist电子舞曲。Shangaan
Electro在南非Limpopo省也被称为"Tsonga Electro"。



历史

在Honest Jon's于2000年末发行之前，Shangaan Electro运动拥有大量的磁带、CD-Rs和DVD，通过Nozinja
Productions在南非当地发行。这张唱片和它在YouTube上引起的对舞者行动的关注，促使他们在Sonar
Festival、Berghain和欧洲、澳大利亚和非洲的其他地方进行了一系列的表演。Shangaan Electro发行名单 Mualusie的
"Ndhuma"（2015，SHANGAANBANG）"Malamulele/Khombo/Tshamiseka"（2015，SHANGAANBANG）Da
Multi Snake的 "Volume 2"（2015，SHANGAANBANG）"N"（2014, SHANGAANBANG）《卷一》Da Multi
Snake（2014，SHANGAANBANG）Xitsonga Dance的Heke Heke / Hoza Xitsonga
Dance（2013，佳隆）Tshetsha Boys的Bafana Bafana / Dyambu（2013，佳隆）"Shangaan
Shake"（2012，Honest Jon's（2008。Nozinja音乐）"Ndzi Teke Riendzo "福斯特-
曼加尼（2008年，Honest Jon's）Shangaan Electro--来自南非的新浪潮舞曲（2010年。Honest Jon's) Pollyn
- "How Small We Are (Nozinja's Shangaan Electro Remix) "选自How Small We Are EP
(2011) Pollyn - "How Small We Are (Nozinja's Shangaan Electro Version)
"选自Pieces in Patterns EP (2012) Nacho Patrol - "How Small We Are (Nozinja's
Shangaan Electro Version) "选自Pieces in Patterns EP (2012)。"Lineas
Angola（Nozinja's Shangaan Electro'Sansana'Remix）"来自Lineas Angola（2013）Nkata
Mawewe - Khulumani Xitsonga Dance - Vomaseve Vol. 6 Lucy Shivambo - Wamina hi
Wihi Tshe-Tsha Boys - Xolo / Ka Buti Tshe-Tsha Boys - Tshe-Tsha Tiyiselani
Vomaseve - Vanghana Ni Vhona Khombo - Mancingelani卷2 Vuyelwa - Mosimana Wa
Dikgom Mapostoli - Mapostoli Mario Chauke - Avanga Hembi卷。3 Tshe-Tsha Boys -
ni famba na wena MC Mabasa Na Shigombe Sisters (No. 17) - Ritaboxeka Thumba



场景的扩展

Shangaan Electro与其他具有前瞻性思维的电子制作人和DJ，包括Caribou、The Knife、Mount Kimbie和Pearson
Sound，找到了特殊的亲缘关系。一系列的12寸唱片让这些与其他电子音乐风格的联系更进一步，Theo Parrish、Rashad &
Spinn、Ricardo Villalobos、Hype Williams等人都对Shangaan的歌曲进行了混音。随后在2013年，Dan
Snaith（Caribou，Daphni）的Jiaolong厂牌又推出了两首全新的Nozinja作品（以各种化名）.2014年，英国的SHANGAANBANG厂牌，专攻Shangaan电音，推出了他们的第一张专辑《Volume
1》，来自Limpopo的艺术家Da Multi Snake。Guardian将其描述为传统Tsonga音乐的 "更难、更快、电子化
"版本，其本身的特点是由Thomas Chauke和曾经与Paul Simon合作过的General MD
Shirinda（曾在1986年的《Graceland》中出现过）等艺人推广的流畅的吉他线条和鼓点。Nozinja的作品主要是为舞蹈而创作的，他将音乐的速度推到了190bpm，与其他舞曲风格相比，Shangaan电音少了对贝斯的关注，有一种
"快速的动感"，在风格上与Footwork相关。舞蹈Shangaan，加沙帝国人民的名字现在是Tsonga人的一部分，这是一个多样化的地区，包括Shangaan人、Thonga人、Tonga人和几个较小的民族，这些民族对Shangaan电音舞产生了影响，如Footwork舞蹈仪式、Xibelani舞蹈或Pantsula舞蹈，更多的城市街头文化出现在20世纪50年代和60年代。表演者通常穿着类似生育仪式的服装和面具，他们利用这种方式与公众更好地互动，在大多数情况下，他们会在舞台上进行集体交流。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=359
