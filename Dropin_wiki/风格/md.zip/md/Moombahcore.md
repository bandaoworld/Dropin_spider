#Moombahcore
##基本信息
###发源时间：
###风格类型：Moombahton
##详情
Moombahcore是受dubstep影响的moombahton的一个子流派，也融入了新式硬核、breakcore和techstep的元素。Moombahcore融合了dubstep鼓和moombahton节奏（100-115
BPM），融入了摇摆贝斯、FM合成器、失真基音和复杂打击乐模式等元素。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Moombahton#Moombahcore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=78
