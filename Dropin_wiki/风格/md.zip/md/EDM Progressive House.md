#EDM Progressive House
##基本信息
###发源时间：2010s
###风格类型：Pop EDM
##详情
EDM Progressive House是以流行EDM为主体，结合传统Progressive
House元素而成的音乐类型，性质上更偏向流行化和商业化，对应的受众群体也更加广大，是当今最受主流市场欢迎的电子音乐子风格之一。



EDM Progressive House和传统Progressive
House的表述在严格意义上还没有明确的划分，但实际上这两种描述所代表的音乐内容已经有了较大的区别。在音乐性上，前者更倾向Pop
EDM，多以二段曲式结构为主，从Verse到Build-
up到Drop再循环重复，单曲时长多在3~4分钟，不超过5分钟；后者则没有固定的曲式套路，单曲时长亦长短不一，主要在House的节奏框架下遵循"渐进"的音乐编排设计和感受而推进。从听感上来讲，EDM
Progressive House更为明亮积极，具有独特的亲和力，可以迅速让人进入音乐的氛围中；传统Progressive
House则更为深邃晦涩，更具实验性。



在EDM Progressive
House类作品中，Vocal部分重要性大大提升，这也是流行EDM类音乐的重要特征。Vocal的旋律设计以及歌手的呈现水平，很大程度上会决定EDM
Progressive House作品在市场上的反响。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=32
