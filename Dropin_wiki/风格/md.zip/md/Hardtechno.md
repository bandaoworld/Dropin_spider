#Hardtechno
##基本信息
###发源时间：2000
###风格类型：Techno
##详情
Hardtechno（Hard Techno）是Techno音乐的一种子风格，在Techno中融合了来自New Beat,
Hardcore等风格的元素。早在1991年左右，PCP和Industrial
Strength等厂牌出现了第一批更硬的Techno作品，这些作品最开始被称为Hardcore
techno[1]，并经发展在90年代早期独立成为早期Hardcore类型。



90年代末，在Schranz运动的推动下，一种新的、极度硬朗的Techno风格开始流行，现在一般被称为Hardtechno。这种风格保留了Techno音乐冰冷的侵略性，且类似上述的早期Hardcore音乐，更加充斥着暗黑元素。Hardtechno音乐通常曲速可达到160BPM或以上，有着重度失真的音效以及突出的Kickdrum，这些激进的元素将其排斥在当时的俱乐部场景之外，却成为了90年代末期Rave场景中的必备[2]。



**参考资料**

1\. https://en.wikipedia.org/wiki/Hardtechno

2\. https://www.di.fm/hardtechno

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=142
