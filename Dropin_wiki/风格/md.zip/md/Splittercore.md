#Splittercore
##基本信息
###发源时间：
###风格类型：Speedcore
##详情
当bpm在600到1000
bpm之间时，Speedcore通常被称为splittercore。splittercore以其机关枪式的节拍而闻名。在20世纪90年代，splittercore有时被称为nosebleed
Techno。





###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Speedcore#Splittercore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=215
