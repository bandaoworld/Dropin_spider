#Illbient
##基本信息
###发源时间：Early 1990s
###风格类型：Ambient
##详情
Illbient是一种电子音乐流派。据称，这个词是DJ
Olive于1994年创造的，用来形容纽约布鲁克林威廉斯堡社区的一群艺术家创作的这种音乐。"Illbient"这个词是由嘻哈俚语"ill"(它是一种积极的表达方式，即"坏"表示"好")和"ambient"两个词组合而成的。尽管illbient有许多独立衍生的曲风，但其音乐的特点是有趣的配音和音乐分层，使用受hip
hop影响的音乐样本，以及囊括世界上所有类型groove和electronic的节奏编排的渐进方法。Illbient经常使用节拍，而不仅仅是纯粹的ambient(或dark
ambient)，并且在录音中经常循环。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Illbient
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=241
