#Phonk
##基本信息
###发源时间：2000s
###风格类型：Trap
##详情
Phonk(/ˈfɒŋk/)是直接受1990年代Memphis rap启发的hip hop和 trap
music的一个子流派。这首歌主要呈现在SoundCloud平台上，音乐的特点是怀旧的Funk样本，通常伴随着老Memphis
rap磁带的人声。这种风格通常从90年代早期的hip hop中提取样本，与爵士乐中的声音相结合，并运用斩击、拧巴等失真技术来创造更黑暗的声音。



**历史**

phonk通常被定义为 "sound of Gen
Z""，它的灵感来自于20世纪90年代中期美国南部的trap音乐。虽然phonk在2000年代末消亡了，但在2010年代初又出现了复兴。SpaceGhostPurrp、DJ
Smokey和Mr.Sisco等主要制作人出现了对20世纪90年代trap音乐的更黑暗、不祥的看法。SpaceGhostPurrp将 "phonk
"这个词推广开来，他推出了Pheel Tha Phonk、Bringin' Tha Phonk和Keep Bringin' Tha
Phonk等曲目。YouTube频道，如TRILLPHONK，也帮助普及了这一流派。这些音乐的特点是怪异的样本，扭曲的陷阱，和低端主导的混合。Phonk制作人继续在地下推动这种声音，然后在2010年代中期，该流派获得了真正的动力。到2017年底，phonk已经发展成为更现代的音乐，摆脱了
"粗犷，黑暗，孟菲斯导向的声音"，并加入了更多的现代人声，带来了更多的jazz 和classic hip
hop。2016年至2018年间，phonk是SoundCloud上被收听次数最多的音乐流派之一，其中#phonk是每年最热门的标签之一。

  
**特点**

phonk的一个特点是它并不固定在一个区域性的 "场景 "中：这与SoundCloud本身作为一个网络平台的性质有关，它突出了由hip hop
和experimental
pop音乐衍生出来的子流派。事实上，艺术家Lowpocus在2017年接受采访时就曾表示。"令人着迷的是，这些艺术家来自世界各地：你可以在加拿大、在美国、在法国，甚至在俄罗斯找到phonk的制作人！"
其他与phonk相关的艺术家包括DJ Smokey、Soudiere、Mythic、DJ Yung Vamp、NxxxxxS和SwuM。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=303
