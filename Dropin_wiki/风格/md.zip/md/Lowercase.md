#Lowercase
##基本信息
###发源时间：
###风格类型：Reductionism
##详情
Lowercase是Ambient
Reductionism（极简主义）的一种极端形式，将非常安静的、通常听不到的声音放大到极致。Minimal艺术家Steve Roden的专辑Forms
of Paper让该流派流行起来。在专辑中，他记录了自己用各种方式处理纸张的过程。这些录音是洛杉矶公共图书馆好莱坞分馆委托制作的。



**定义**

Steve Roden对他在后期作品中开始出现的lowercase倾向这样说:"它带有某种安静和谦卑的感觉。它不需要注意，它必须被发现……这和capital
letters正好相反，大的东西会引人注意。"



**艺人**

为Lowercase运动做出贡献的艺术家还包括Richard Chartier, Starrlight Mighty5（Jeremy Leafey）,
以及Carsten Nicolai（Alva Noto）

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Lowercase_(music)
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=247
