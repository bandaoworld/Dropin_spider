#Drumfunk
##基本信息
###发源时间：1990年代末期
###风格类型：Drum and Bass
##详情
Drumfunk，有时也被称为 "Edits"或 "Choppage"，是Drum and
Bass的一个子流派。这个词在2000年开始广泛使用，当时drumfunk本身也开始扩展。drumfunk风格的特点是复杂的节拍，听起来像是在drumkit上现场演奏，但通常由经过电子处理和重新排列的样本组成。第一首drumfunk曲目可以说是Krust和Roni
Size的《Witchcraft》，可以追溯到1994年。最常见的Breaks是来自The Winstons的 "Amen Brother
"以及Apache、Think、Aligator Boogaloo和其他一系列的采样。



虽然是Drum and Bass的一个子流派，但它通常比主流Drum and
Bass中存在的标准鼓型要复杂得多。歌曲的重点往往是鼓声而不是旋律。它通常是由老式Funk唱片的鼓声样本组成，这些样本相对来说比较晦涩。与主流的Drum
and Bass相比，其旋律提供了一个更为轻松的背景氛围。支持这种风格的最受欢迎的活动是Chris
Inperspective举办的技术性活动，总部设在伦敦，每月第一个周三在Herbal举行，还有总部设在阿姆斯特丹的IChiOne，也是以美食和电影为主题，同时还有来自德国曼海姆的Neurotic
Sound Foundation与Twilight
Zone的演出。"除了它在舞池中的魅力，drumfunk也适合在家里聆听，因为它复杂的鼓声和悠闲的质感让人感到舒缓和满足。"

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/drumfunk
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=109
