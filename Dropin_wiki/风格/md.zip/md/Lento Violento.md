#Lento Violento
##基本信息
###发源时间：Late 1990s
###风格类型：Hardcore
##详情
Lento
Violento，有时简称为Lento，是一种在意大利发展起来的电子舞曲风格。这个词组直译是指"慢"（Lento）和"暴力"（Violento），因为这种风格的节奏通常在85和115
BPM之间。Lento
Violento的作品有质感交映的Kick，类似于hardcore或hardstyle中的Kick，但它以非常慢的速度演奏，并配有人声采样、暗黑和acid声音以及Loop循环。



**起源**

带有 Lento Violento 声音的第一首曲目是 Ottomix 的 Anima Ladina (1991)、Gigi d'Agostino 的
Panic Mouse (stress mix) (1996) 、Ottomix 的 Ibiza (1998) 以及由 Ottomix 联合制作的 Alex
Castelli 的《Enjoy》。虽然在那个时候，他们还没有被称为 Lento Violento
。这些曲目受到了更多以Techno和Trance为导向的曲目的影响，如 Mauro Picotto 的 "Lizard"、Joman (Joy
Kitikonti) 的 Iguana、Pulsar、Tuttincoro 或 Raggattak，这些作品全部来自意大利厂牌 BXR Records。



虽然一些 Lento Violento 单曲在俱乐部很受欢迎，但直到 DJ/制作人 Gigi D'Agostino 于 2003 年开始制作一系列作品，如
Ripassa，这个风格自身才得以确立。事实上， Gigi 为这种风格创造了这个名字，他在自己的子厂牌 Noise Maker 上发行了他的大部分
Lento Violento 歌曲，使用别名 Dottor Dag、Lento Violento Man、Uomo Suono、Orchestra
Maldestra 或 La Tana Del Suono 来区分这些歌曲和他的 Italo Dance 作品。



在这种风格成功后，其他艺术家开始创作类似的曲目。还发行了几张 Lento Violento 音乐的合辑 CD，例如"Movimentolento"系列。



事实上，Lento Violento 是 Gigi D'Agostino 为他的系列作品合辑所注册的限制商标。任何其他艺术家都不能使用此名称。 Gigi
总是说 Lento Violento 不是音乐风格，这就是为什么大多数制作人使用"slowstyle"或"hard slowstyle"这个名字的原因。



**融入Hardstyle**

意大利制作人 Technoboy 在 2009 年发行的单曲"The Undersound"中，将 lento 与现代 Hardstyle 元素融合在一起；
虽然该曲目声称将新类型命名为"undersound"，术语"lento"仍偶尔用于命名 Hardstyle 曲目。Technoboy
本人一直在他的曲目中继续使用这样的主题，例如"Catfight"。Brennan Heart 和 Headhunterz 的曲目"MF Point of
Lento"则明确称 Technoboy 是该流派中最杰出的艺术家。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Lento_Violento
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=212
