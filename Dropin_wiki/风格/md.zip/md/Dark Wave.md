#Dark Wave
##基本信息
###发源时间：Late 1970s – early 1980s
###风格类型：New Wave
##详情
Dark wave 或darkwave，是20世纪70年代末new wave和post-punk运动中出现的一种音乐流派。dark
wave的创作主要以小调调性和内敛的歌词为基调，一直被认为是黑暗、浪漫、凄凉的，带有悲伤的色彩。常见的特点包括使用电吉他、原声吉他、小提琴、钢琴等和弦乐器，以及合成器、采样器、鼓机等电子乐器。这个流派包含了一系列风格，包括cold
wave, ethereal wave, gothic rock, neoclassical dark wave 和neofolk。



20世纪80年代，一种亚文化主要在欧洲与dark wave音乐并存发展，其追随者被称为wavers 或dark
wavers。在德国等一些国家，该运动还包括gothic rock 乐迷（所谓的trad-goths)。



**基础**

自20世纪80年代以来，这个词在欧洲被用来描述new wave 和post-punk music的阴郁和忧郁的变体。当时，"goth"一词与gothic
rock有着不可分割的联系，而 "dark wave"则获得了更广泛的含义，包括与gothic rock 和synthesizer-based new
wave music相关的音乐人，如包豪斯、Joy Division、The Cure、Siouxsie and the Banshees、The
Sisters of Mercy、Anne Clark、Depeche Mode、Gary Numan和The
Chameleons。暗波一词起源于20世纪80年代，作为新浪潮的暗色对应物的指标。Cocteau Twins、Soft Cell和Depeche
Mode等乐队是第一代darkwave的代表。darkwave......与new
wave相比，它在音乐中采用了相对较慢的节奏、较低的音调和更多的小调来表现忧郁的文字。- 伦敦金斯顿大学音乐学教授伊莎贝拉-范-埃尔弗伦（Isabella
van Elferen） 该运动在国际上传播，发展了诸如Cocteau Twins等乐队，以及新古典主义暗波（Dead Can Dance和In the
Nursery）的音乐所引发的。法国cold wave乐队如Clair Obscur和Opera Multi
Steel也与darkwave有关；法国cold wave乐队Exces Nocturne的吉他手Remy Lozowski称他的音乐为new wave
noire（"dark new wave"）。



与此同时，与new wave 和dark wave 运动相关的不同亚流派也开始相互融合和影响，例如synth-wave（一种使用合成器的new
wave，也被称为 "electro-wave"）与gothic rock，或者开始借用后工业音乐的元素。Attrition、Die
Form(法国)、Pink Industry(英国)、Psyche(加拿大)、Kirlian Camera(意大利)和Clan of
Xymox(荷兰)等乐队在80年代都曾演奏过这种音乐。其他乐队如Malaria！和The Vyllies加入了chanson和cabaret
music的元素。这类dark wave音乐后来被称为cabaret noir（或dark cabaret，美国dark wave唱片公司Projekt
Records推广的术语）。德国dark wave乐队部分与the Neue Deutsche Welle（即德国新浪潮）有关，包括Xmal
Deutschland、Mask For、Asmodi Bizarr、II. Invasion、Unlimited Systems、Moloko
†、Maerchenbraut、Cyan Revue、Leningrad Sandwich、Stimmen der
Stille、Belfegore和Pink Turns Blue。



**1990s: 第二代**

在新浪潮和后朋克运动在80年代中期衰落后，dark wave作为一种地下运动被德国乐队如Girls Under Glass、Deine
Lakaien、Love Like Blood、Love Is Colder Than Death、Diary of Dreams、The Eternal
Afflict和Wolfsheim，以及Project Pitchfork和其分支Aurora Sutra等重新激活。 来自意大利的Ataraxia和The
Frozen Autumn，以及法国的Corpus
Delicti也是从这个运动中发展起来的，成为西罗马式场景的领军人物。所有这些乐队都走了一条基于80年代新浪潮和后朋克音乐的道路。20世纪90年代，第二代dark
wave乐队开始流行，包括Diary of Dreams、Deine Lakaien和The Frozen Autumn......。德国乐队Deine
Lakaien......明显受到Depeche Mode的dark合成器声音的影响。- 音乐学教授Isabella van Elferen
与此同时，包括Das Ich、Goethes Erben、Relatives
Menschsein和Endraum在内的一些德国艺术家发展出了一种更加戏剧化的风格，其中穿插着德国诗意、隐喻的歌词，被称为Neue Deutsche
Todeskunst（字面意思是新德国死亡艺术）。其他乐队如Silke Bischoff、In My
Rosary、Engelsstaub、Impressions of Winter等，则将合成器与neofolk 和neoclassical dark
wave元素结合起来。



**美国**

1993年以后，在美国，dark wave（作为单字变体 "darkwave"）这个词开始与Projekt
Records厂牌联系在一起，因为这个词是厂牌创始人Sam
Rosenthal在翻阅Zillo等德国音乐杂志后采用的，并一直被用来在美国推广和推销德国厂牌Hyperium
Records的艺人，比如Chandeen和Love Is Colder Than Death。我第一次知道 "dark wave
"这个词是在1992年。它出现在德国的杂志上--比如Zillo--描述了欧洲音乐的一种风格，它追随其他的 "浪潮"，比如New
Wave......。我觉得这两个词（"dark "和
"wave"）很有意思。这是一种地下的、淹没的、晦涩的东西......它席卷着你、沉浸着你、包围着你。这是一个充满诗意的短语，可以描述许多不同的声音。



_当时，我正在思考一个新名字，我想要一个能包含我的目录中的各种音乐的名字。_

_\- Sam Rosenthal_



Projekt Records，2000年，Projekt的特色是Lycia、Black Tape for a Blue Girl和Love Spirals
Downwards等乐队，其中一些乐队的特点是大气的吉他、合成器声音和女声。这种风格从1980年代的Cocteau
Twins等乐队身上汲取了灵感，通常被称为ethereal dark
wave。Projekt与Attrition也有很长的联系，Attrition出现在该品牌最早的合辑中。另一个美国唱片公司是Tess
Records，其中有This Ascension、Faith and the Muse和重新组合的Clan of
Xymox。路易斯安那大学传播学教授Joshua Gunn将美国的dark
wave音乐类型描述为将相当有限的gothic曲目扩展到电子音乐，在某种程度上，美国对欧洲发展起来的 "ethereal "亚流派（如Dead Can
Dance）的回应。由Sam Rosenthal现在在纽约的厂牌Projekt所支撑的dark
wave音乐，少了摇滚，多了滚石，支持那些倾向于强调民谣曲艺、沉静人声、环境实验和合成音的乐队Projekt乐队，如Love Spirals
Downwards和Lycia是这个次世代中最受欢迎的曲目。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=316
