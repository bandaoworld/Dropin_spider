#Melodic Funk
##基本信息
###发源时间：1990s
###风格类型：Funk Carioca
##详情
Melodic funk(也被称为funk melody)是funk carioca和Latin freestyle的融合流派。



**历史**

DJ Marlboro的电台节目 "Big Mix "从80年代开始播出，普及了地下funk
carioca歌曲的软件版本。这些软本在巴西形成了一个浪漫的子流派，被称为melodic funk，在原始的、有节奏的funk曲调中加入了旋律和编曲。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Melodic_funk
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=291
