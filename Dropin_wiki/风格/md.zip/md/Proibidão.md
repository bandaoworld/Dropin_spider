#Proibidão
##基本信息
###发源时间：1990s
###风格类型：Funk Carioca
##详情
Proibidao的字面意思是 "强烈禁止"，是一种源自里约热内卢贫民窟的funk
carioca音乐的子流派，它始于1990年代初，是与该市许多贫民窟中的贩毒帮派增长并行的现象。贩毒团伙赞助DJ和baile
funks在他们控制的贫民窟传播尊重和爱他们的团伙以及仇恨其他团伙。由此产生的音乐就是proibidao。



Proibidao的特点是现场funk人声和Miami
bass结构的原始混合。明确的歌词通常会宣传MC所属的帮派、犯罪、吸毒和暴力。就像帮派成员一样，MC们也会说些不好听的话，每个毒品帮派都会在自己的贫民窟赞助自己的baile
funk，这就导致了每个MC以及每个帮派都有独特的声音。帮派的高度地域性使得proibidao在里约热内卢成为一种极其本地化的放funk形式。此外，在巴西，在歌词中宣扬犯罪是违法的，这使得大多数proibidao歌曲在电台表演或广播是非法的（因此被称为
"proibidao"）。这两个因素使得proibidao很少能在贫民窟的现场表演之外被听到。有一个特别强大的帮派，Comando
Vermelho（葡萄牙语，意为Red
Command）在他们的舞会上给贫穷的年轻人提供免费的女孩、饮料和娱乐，希望给里约的年轻人留下一个贩毒和帮派成员的正面形象。在Red
Command发行的CD中，他们的帮派标志--CV，横在标签上，代表的是社区和帮派，而不是艺人。Red
Command的影响力在1990年表现得淋漓尽致，当时的 "里约说唱之王 "William Santos de Souza 和Duda发布了一首名为《Rap
do Borel》的歌曲，向里约一个由帮派控制的贫民窟喊话。没有哪个帮派比Commando Vermelho更能代表Proibidao。



其他帮派也有著名的歌曲。例如，帮派Amigos dos Amigos（葡萄牙语''Friends of Friends''）以MC Cruel演唱的
"A.D.A do Chuck "而闻名。另一位Funk emcee MC Colibri在erotic funk方面非常成功，但他也已经为Terceiro
Comando Puro
Proibidao创作了音乐，对于里约的社会空间的获取有一些非常重要的意义。对于黑帮和毒枭来说，它代表了一种对应于领土统治的音乐表达形式。实际上，当这些帮派举办他们特定的bailes活动时，他们就会对敌对的帮派和国家执法部门维护自己的权威。由于Proibidao引起的犯罪生活方式和习惯性吸毒是其表演者的特点，警察自然会试图阻止bailes活动和Proibidao的相关传播。因此，尽管D.R.E(Divisao
de Repressao a Entorpecentes或Division of the Repression Against
Drugs)等国家计划努力制止，但每周仍有无数的bailes活动存在，这对帮派来说是一个明显的胜利。除了举办这些bailes活动外，帮派还招募城市青年，宣传他们的日常斗争，这使得贫民窟bailes活动成为帮派开展业务的重要社交场所。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Proibid%C3%A3o
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=292
