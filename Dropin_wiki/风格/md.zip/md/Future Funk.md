#Future Funk
##基本信息
###发源时间：
###风格类型：Vaporwave
##详情
Future funk是一种使用funk,
disco和日本音乐元素的音乐流派，具有怀旧的影响。它非常欢快、时髦，通常与90年代的动漫或消费文化的审美有关。它通常是对一首老的、不知名的日本流行歌曲进行类似disco的电子混音，它通常是以每分钟128拍为节奏。





###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=343
