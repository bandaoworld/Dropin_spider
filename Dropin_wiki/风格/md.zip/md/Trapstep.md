#Trapstep
##基本信息
###发源时间：late 2011 early 2012
###风格类型：Brostep
##详情
由Bigbry在2011年底提出的Dubstep子流派，结合了Dubstep/Brostep与Trap音乐的元素，如Trap风格的High*hat
Pattern和808低音。也叫ElecTrap。



###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/trapstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=155
