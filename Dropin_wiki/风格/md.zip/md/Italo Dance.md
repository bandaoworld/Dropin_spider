#Italo Dance
##基本信息
###发源时间：
###风格类型：Eurodance
##详情
Italo dance是Eurodance流派的一个分支，于20世纪90年代末至21世纪初在意大利流行开来，Eiffel 65的单曲《Blue (Da Ba
Dee)》发行后，它开始流行起来。1993年至1995年是这一流派的萌芽期，1999年至2005年是它的黄金时期。尽管Eiffel 65、Prezioso,
Gigi D'Agostino, Molella, Gabry Ponte和DJ
Lhasa等人的Italo热门歌曲仍在大量播放，但这种类型的音乐还远远没有成为今天的主流，主流则是electro和house音乐。Prezioso和Molella现在在制作house和electro音乐，许多其他艺术家也改变了他们的风格，然而Gigi
D'Agostino, Gabry Ponte和Luca Zeta仍然在制作Italo。



Italo
dance主要是在夜总会播放的音乐，源于意大利。这一流派从未真正成为整个欧洲市场的主流，但却在意大利广播电台，特别是舞蹈广播电台m2o，以及南欧和讲德语的欧洲国家得到了大量播放。







###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://ast.wikipedia.org/wiki/Italo_dance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=225
