#Andean New-age
##基本信息
###发源时间：
###风格类型：New-age
##详情
Andean new-age music是new-age
music与秘鲁长笛和巴拉圭竖琴音乐的融合流派。秘鲁起源于大约公元1200-1532年的印加(Inka)。秘鲁有两种重要的笛子：quena是一种很像普通笛的笛子，zampoña则是排箫。位于利马南部的帕拉卡斯（Paracas）文化，在公元前200年到公元300年之间创造了这种排箫。巴拉圭竖琴在外观和声音上与爱尔兰木琴相似。尽管秘鲁和巴拉圭的传统音乐流派对一些西方人来说都有new-
age的感觉，但它们实际上是非常古老的音乐形式。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Andean_new_age_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=243
