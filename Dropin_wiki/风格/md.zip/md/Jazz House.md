#Jazz House
##基本信息
###发源时间：
###风格类型：House
##详情
Jazz House是以House音乐节奏为框架，结合Jazz元素和氛围而形成的新颖别致的电子音乐风格，与Deep House密切相关。Larry
Heard被认为是首位在House作品中融入Jazz风格的制作人。



Jazz house相关作品多以爵士乐采样为基础，但有时也不排除使用现场乐器。Jazz
House的编曲手法多样，从简单的在House节奏中加入爵士乐氛围，到使用电子合成器完成爵士乐段Solo的展现，这种风格充分体现了自由与浪漫。



而当爵士乐技巧和乐器相较House音乐元素占主导地位时，则将此类音乐归类为Nu-Jazz（新爵士乐）。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=73
