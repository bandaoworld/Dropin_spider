#Garage House
##基本信息
###发源时间：Early 1980s
###风格类型：House
##详情
Garage House（原名 "garage"，当地的说法包括 "New York house "和 "Jersey
sound"）是一种舞蹈音乐风格，是与芝加哥House音乐一起发展起来的，这种风格在20世纪80年代在美国流行，90年代在英国流行，在那里发展成UK
Garage和Speed Garage。演奏Garage House风格的DJ包括Tony Humphries、Larry Levan和Junior
Vasquez。



**特点**

与其他形式的House音乐相比，Garage House包含更多受福音影响的钢琴即兴演奏和女性声乐。与Chicago
House相比，它有更多源自R&B的灵魂乐。



**历史**

Garage
House是在20世纪80年代初至中期，在美国纽约市的天堂车库夜总会和新泽西州纽瓦克的桑给巴尔俱乐部发展起来的。它和早期的House音乐有很多重合之处，使人很难将两者区分开来。它比芝加哥House的发展更早，根据《All
Music》的说法，它比其他舞曲风格相对更接近迪斯科。随着芝加哥House在国际上的流行，纽约的车库音乐圈也从 "House "的保护伞中被区分出来。



20世纪80年代的舞蹈音乐使用了电子乐器，如合成器、音序器和鼓机。这些乐器是车库音乐的重要组成部分.车库音乐的发展方向主要受到纽约市迪斯科舞厅Paradise
Garage的影响，在那里，以音乐多变和创新著称的DJ Larry Levan播放唱片。



根据Blues & Soul的说法，当代车库音乐始于Boyd Jarvis和Levan的The Peech
Boys.Jarvis使用Visual的绰号，1983年的唱片 "Somehow，Someway"（Prelude Records - PRL D
650）和 "The Music Got Me"（Prelude Records - PRL D
650）的背后，后者特别有影响力，后来被主流House音乐唱片制作人Robert Clivilles和C+C Music Factory的David
Cole采样。这种风格在英国的流行催生了一个衍生的流派，叫做UK Garage（英国车库）。



**代表艺人**

  * Adeva
  * Aly-Us
  * Blaze
  * Boris
  * Byron Stingily
  * Cevin Fisher
  * Change
  * Colonel Abrams
  * Crown Heights Affair
  * Danny Tenaglia
  * Experimental Products
  * François K
  * Joey Negro
  * Joi Cardwell
  * Junior Vasquez
  * Kerri Chandler
  * Loleatta Holloway
  * Larry Levan
  * Masters at Work
  * Oliver Cheatham
  * Peech Boys
  * Robin S
  * Romanthony
  * Roy Davis, Jr.
  * Todd Edwards
  * Todd Terry
  * Tony Humphries
  * Ultra Nate
  * Victor Calderone



**代表厂牌**

  * Strictly Rhythm Records
  * King Street Sounds Records
  * Nervous Records
  * ZRecords
  * Perfect Pair Records
  * Freeze Records
  * Streetside Records
  * Ministry of Sound

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Garage_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=66
