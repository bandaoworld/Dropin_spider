#Disco Polo
##基本信息
###发源时间：Late 1980s
###风格类型：Dance-pop
##详情
Disco polo 是波兰20世纪80年代后期产生的一种流行舞曲流派，最初被称为 "sidewalk music"（波兰语：muzyka
chodnikowa）或 "backyard music"（波兰语：muzyka podworkowa）。



《PWN词典》将这种音乐定义为波兰disco音乐的一种变体，旋律简单，歌词通常是risque。



这种形式的城市民间音乐在1995年到1997年之间达到顶峰，随后需求逐渐下降，然后在2007年复苏。



特点

经典disco
polo歌曲的特点是以最简单的和弦进行曲和旋律为基础，灵感来自于民间音乐中稳定的节奏，往往配以切分音的鼓点样本，并伴以细腻的合成器声音或键盘乐器。歌词经常是夸张的不幸福的爱情故事，虽然他们也很俏皮，有时以节日为主题。



历史

该体裁的根基
该体裁起源于在婚礼上由乐队演奏的音乐，曲目为波兰民间音乐和婚礼歌曲。随着时间的推移，出现了电子乐器替代传统声学乐器的变化，如电子键盘代替传统的声学键盘乐器。最常见的主题包括关于未实现的爱情。除了这些基础之外，这种风格还受到欧洲范围内其他流行音乐风格的影响，即意大利迪斯科（Italo
disco），这种音乐风格起源于意大利，主要产生于70年代末至80年代末。第一个代表这种风格的乐队是1984年11月19日成立的Bayer
Full.另一个流行团体Top
One成立于1986年。这两支乐队都是这种音乐类型的先驱。20世纪80年代末90年代初，出现了更多的乐队，如Akcent、Atlantis、Boys和Fanatic.Blue
Star是波兰第一家出版Disco Polo的官方唱片公司。sidewalk musi的主要中心，后来的disco
polp，是比亚韦斯托克和其他城市躺在Podlasie（大多数艺术家来自那里），Żyrardow，和华沙附近的Sochaczew.其中最著名的歌曲从这种流派衍生的是
"Mydełko Fa"1991年由Marek Kondrat和Marlena
Drozdowska记录;这首歌被其他音乐模仿，并变成了一个伟大的打击乐，促进了该流派的普及。这首歌甚至被当作Disco Polo音乐的国歌。the
Blue Star records的斯瓦沃米尔-斯克雷塔（Sławomir Skręta）提出了一个替代旧名词的名字--"人行道音乐"（piosenka
chodnikowa），这个名字源于20世纪90年代初其唱片的主要发行方式--
街道和集市上的人行道摊位。当时，在乡村野餐、县城车站、婚礼上，或者在波兰议会和总统选举的政治竞选活动中，大多可以听到Disco Polo的声音。



前总统亚历山大-克瓦希涅夫斯基（Aleksander
Kwaśniewski）是政治家在竞选总统时使用迪斯科马球的最著名的例子之一。从20世纪90年代到2002年 "迪斯科马球
"这个名字是由华沙附近Reguły的一家唱片公司Blue Star的老板Sławomir
Skręta在1993年创造的。与意大利迪斯科（80年代初的一种意大利音乐风格）相似，这个名字迅速流行起来，并有效地取代了早期的
"人行道音乐"。20世纪90年代前半期，音乐，普遍成为一种大众现象，但迪斯科马球几乎没有出现在媒体上。1992年2月29日，举行了专门针对这种流行音乐趋势的Gala
Piosenki Chodnikowej i
Popularnej（人行道和流行歌曲晚会），并由TVP1播出。波尔萨特电视台对这种风格进行了广泛的宣传，并在名为 "Disco
Relax"（1994年12月4日首播）和 "Disco Polo Live"（1996年2月3日在波尔萨特电视台和Radio
Eska广播电台首播）的电视节目中制作了自己的迪斯科马球热门名单。迪斯科马球当时也出现在Polonia
1电视台，这是一个较大城市地区的地方电视台网络和Polonia电视台。在其他媒体上，当时的音乐几乎没有缺席，并被主流媒体承认为俗气和原始主义的象征。在1995年总统选举之前，乐队和歌手在竞选期间使用Disco
Polo。90年代後期，傳統的樂器被鍵盤取代，使歌曲的風格略有改變，更像現代舞曲，尤其是歐洲舞曲。1995年12月31日，TVP 1播出了一个名为
"Karnawałowa Gala Disco Polo"（"嘉年华会Disco Polo"）的Disco Polo节目。1996年，Maria
Zmarz-Koczanowicz和Michał Arabudzkii执导了一部名为 "Bara Bara "的纪录片，探讨了Disco
Polo的趋势。同年，该片在TVP1电视台播出。1998年4月24日，Robert Glinski Fri.发行了一部电影 "Kochaj i rob co
chcesz"(Love and do what you
want))，片中主人公离开在俱乐部用钢琴演奏这种类型的音乐。在20世纪90年代，艺术家们开始将Disco Polo与其他音乐类型混合在一起，如dance
music, house music和 techno。



从1997年到2001年，该流派的音乐过剩，由于波兰和外国流行音乐、摇滚音乐、嘻哈音乐、舞蹈音乐和电子音乐的增长，Disco
Polo磁带和CD的销售量急剧下降。其在Eska电台、Polonia
1电视台和Polonia电视台等媒体平台上的播放量也随之减少。例如，2002年8月下旬，Polsat电视台取消了 "Disco Relax "和
"Disco Polo Live"，使许多乐队失业。一些观察家认为，Disco
Polo音乐人移居美国，一些艺术家在那里继续工作，也造成了这一流派人气的急剧下降。



2002年后

乐队Fanatic
在2002-2007年，一些乐队继续他们的活动（如Toples或Weekend）。在这期间，乐队推出了新的专辑，但由于当时国内媒体缺乏这种流派的音乐，这种努力未能给乐队带来人气。2004年8月12日，Wojciech
Orliński在Gazeta Wyborcza上发表了一篇题为 "Śmierć disco
polo"（迪斯科马球之死）的文章，描述了这一音乐流派在20世纪和21世纪之交的衰落。2006年8月6日，TVN播出了一档名为 "Attention!
Behind the scenes of the cycle of Fame"的节目，专门报道了Disco
Polo运动的复兴。该报道在网络投票中被公认为2006年最佳报道，12月31日再次播出。2007年，经过5年的中断，这个流派再次通过iTV电视台建立了自己的地位，该电视台每天播放一个名为
"Discostacja "的节目。此外，通过两个网络电台在互联网上进行推广。从2007年起，Disco
Polo乐队开始重新开始演出，演出次数逐年增加，唱片也开始销售，这意味着乐队又开始盈利。从2008年7月5日起，波兰卢布林广播电台重新推出了一档名为
"Nie tylko Barachołka"（"不仅仅是Barachołka"），也就是以前的 "Barachołka
"的节目。该节目在周五至周六晚间21:00至2:00之间播出。2009年上半年，Edusat频道在停止推广之前，对Disco
Polo音乐进行了三个月的宣传。



自2009年3月起，iTV电视台恢复了多年前的Disco Polo Live节目，但在2011年3月暂停播出。从2011年5月7日起，Disco Polo
Live节目开始在Polo TV播出。2009年10月4日，由Maciej Jamroz制作的新节目Disco Bandżo在Tele
5播出，时长约50分钟。目前，Disco Bandżo节目每天早上在Polonia 1播出。从2010年12月5日起，在VIVA波兰频道（VIVA
Poland）每周日播出一个名为 "Disco ponad wszystko"（"Disco above
all"）的舞蹈音乐节目。这个节目使该频道的收视率翻了一番，之后每集的收视率都在稳步上升，但在18个月后，这个节目从该频道删除。CSB电视台也曾播放过Disco
Polo，但该频道于2012年5月停播。2011年5月7日，一个专门播放Disco Polo音乐的电视频道--Polo
TV正式推出。自2011年12月19日起，该频道在数字电视和多路电视上播出，成为波兰收视率最高的音乐频道。2011年9月27日，TV.DISCO频道开播，该频道播出的音乐流派主要是disco,
dance music 和 electronic music，该频道一直播出到今天（截至2015年1月）。



90年代在Polsat上播出的《Disco Relax》节目本想在该频道恢复播出，但最终于2012年2月12日在Polo
TV上回归。2012年10月20日，由Wojciech Grodzki领导的Vipo Disco Polo Hits节目从TVS频道转到Polo
TV。每周六上午10点[41]播出，直到2017年12月30日。2011年，导演Maciej Bochniak制作了一部名为(A Billion Happy
People) （Miliard Szczęśliwych Ludzi）的纪录片，讲述了这一类型的乐队--Bayer
Full和他们在中国的演出。2012年12月1日，Polsat推出了一个名为 "Imperium Disco Polo"（"Disco Polo
Empire"）的新节目，专门介绍Disco Polo音乐，这些节目是Polsat Play的重播节目。然而，在2013年3月初，由于Pamiętniki
z Wakacji系列新剧集的出现，该节目从Polsat频道撤下，但新剧集仍可在有线电视网和Polsat
Play频道的数字平台上观看。从2013年4月21日至2013年6月，该节目在ATM Rozrywka上播出，从2013年8月3日起在Polsat
2上2:00播出。2013年4月8日至12月1日，Radio Plus推广了Disco Polo，并将其口号从 "Gentle hits"（Łagodne
Przeboje）改为 "Always in Rhythm"（Zawsze w Rytmie）。除了流媒体的Disco
Polo，还有80年代和90年代的舞曲。从2013年12月1日起，这些音乐被转移到了VOX FM电台。这一变化是由于Radio
Plus的听众和主教的抗议，他们是Radio Plus电台许可证的所有者。2013年8月17日，Telewizja Polsat广播了一场名为 "Disco
Pod Żaglami"（"Disco Under Sails"）的音乐会，由Disco
Polo明星Akcent、Shazza、Boys、Classic和Weekend参加。这是该台取消该类型节目10多年以来的第一场Disco
Polo音乐会，并保留了270万次观看。2014年5月1日，另一个专门播放Disco Polo的电视频道开通，名为 "Disco
Polo音乐"，隶属于Telewizja Polsat。2015年2月初，TV.DISCO频道从节目表中完全取消了Disco
Polo音乐。2015年2月27日，Maciej Bochniak的电影《Disco Polo》上映，该片讲述了一群音乐家登上Disco
Polo排行榜榜首的故事。 2015年2月26日，与该片上映有关，TVP Kultura当天播出了一集 "Hala odlotow"（Waiting
Area），专门介绍Disco Polo。



2017年12月4日，由于与ZPR媒体集团达成协议，Telewizja Polsat收购了Disco Polo台Polo TV和Vox Music
TV的广播公司Lemon Records的100%股份，从而成为两者的所有者。在YouTube上最受欢迎的两首波兰歌曲都是Disco
Polo风格的。在很长一段时间里，浏览量第一的歌曲是Weekend的 "Ona tańczy dla mnie"（《She dances for
me》）。2017年6月底，实现了超过1.06亿次的浏览量，由Akcent演唱的 "Przez twe oczy zielone"（"Through
your green
eyes"）打破了波兰歌曲浏览量最高的记录，将Weekend降至第二位。2002年以后，这种类型的歌曲经常与舞曲和其他类型的电子舞曲结合在一起，如power
dance、eurodance、nu-
electro和techno。2002年以后，这种类型的歌曲往往还包含了民乐和流行音乐的元素。2002年后获得高知名度的乐队和艺人主要有：。After
Party、Weekend、Andre、Czadoman、Tomasz Niecik、Eva Basta、Masters、DJ Disco ft. MC
Polo、Cliver、Effect和Power Play。Disco Polo在波兰以外的地方也很流行，特别是在波兰侨民中。有一些艺术家，如Disco
Polo Tomek，他们表演了Disco Polo音乐。最近，在2016年新年晚会之后，Disco
Polo音乐风格在波兰有了新的复兴，TVP2电视台邀请了最受欢迎的Disco Polo表演者之一的Akcent乐队主唱Akcent, Zenon
Martyniuk在主舞台上表演。波兰电视台台长Jacek Kurski也表示很高兴，因为Disco
Polo的表演得到了在场很多人的喜爱，不再被讽刺讨厌。波兰大众媒体中的disco音乐流派 Akcent乐队
从90年代中期到世纪之交，波兰电视台Polsat、Radio Eska、Polonia 1、TV
Polonia以及一些地区广播电台和地方有线电视网都播放了有关Disco Polo音乐的电视和广播节目。自2007年以来，人们对Disco
Polo的兴趣越来越大，这反映在一些媒体上这种音乐的存在感越来越强，音乐会的播放量也越来越大。但是，许多电台和电视频道仍然认为这种音乐类型是一种不良品味的象征，并不加以推广。2007年以后，宣传或推广Disco
Polo球的电视台包括Polo TV、iTV、Polsat 2、TVS、Polonia 1、Disco Polo音乐、TVR、VOX音乐电视、Power
TV、Polsat Play、Eska TV、TV.DISCO、VIVA Polska、Polsat、Puls 2、Tele 5、ATM
Rozrywka、Kino Polska Muzyka以及TV4和TV6。



一些广播电台和互联网网站也在推广这一流派，如FTB电台、Discoparty.pl、Disco-
Polo.fm、Discostacja和IRN，以及区域性电台--
包括Express电台、Hit电台Jard、Kaszebe电台、波兰Kielce电台、Leliwa电台、Polskie电台Lublin、Silesia电台和Radio
Plus电台，以及跨区域电台VOX
FM和WAWA电台。在线社交视频服务，如YouTube和2006年至2017年存在的网站Wrzuta.pl，也对大众对Disco
Polo的兴趣回归产生了重要的影响。在夏季，举办了几个Disco
Polo节，其中自1996年以来最大的是奥斯特罗达的国家音乐舞蹈节（最初在科沙林举行），从2011年开始是Disco Hit Festival
--科比尼卡，在科比尼卡附近的Kwakowo举行。波兰最大的舞曲明星在这些音乐节上表演，来自波兰各地的成千上万的歌迷参加。



Disco Polo的乐队和表演者还参加了许多慈善音乐会和活动，包括在Wielka Orkiestra Świątecznej Pomocy（Great
Orchestra of Christmas Charity）期间。2016年底和2017年初，Disco Polo的明星乐队Akcent（Zenon
Martyniuk和Ryszard Warot）首次在Zakopane的新年演出，由Telewizja Polska组织。TVP2还获得了 "25
years of disco polo "晚会的转播权，该晚会于2017年6月25日在华沙Polonia体育场举行。根据尼尔森观众测量，TVP2的 "25
years of disco polo"晚会将会有260万观众观看。



其他信息

在波兰，Disco
Polo的推广往往掌握在犯罪组织Pruszkow黑手党和Wołomińska黑手党领导人手中。1995-1997年，在这种音乐成功的高峰期，犯罪组织控制了大约70%的市场。Disco
Polo遭到了其他音乐流派支持者的严厉批评，他们指责它的音乐原始、抒情幼稚、表演水平低下和缺乏原创性（重复主题和设计，通常来自于60和70年代的波兰和外国音乐）。然而，这些批评并没有影响这种音乐的流行。这一流派的支持者和表演团体认为，目前Disco
Polo的专业化正在进步，歌词和音乐都有所改进，表演者也越来越多地避免了playback。同时，一些老一辈的表演者也参与了主流Disco
Polo的创建或受益于它的流行（如Janusz Laskowski、Marlena Drozdowska、Bohdan Smoleń、Andrzej
Rosiewicz、Stan Tutaj、Marek Kondrat、Piotr Pręgowski和Cabaret
OT.TO）。90年代初，Krzysztof Krawczyk演唱并录制了意大利disco风格的歌曲，这也是Disco
Polo诞生的基础。在一些媒体上，New Disco Polo这个词被用来形容一些艺人。这个词所指的创作者自己也指出，new disco polo具有
"old-school "，但与90年代的disco polo相比，有更好的制作和歌曲编排。2014年，在奥波莱举行的第51届全国波兰歌曲节的演出中，歌手
Maryla Rodowicz表演了她翻唱的这一音乐流派的歌曲。这些歌曲是 Boys乐队曲目中的"You're crazy" 和 "Long live
freedom" 以及 Weekend乐队的 "She dances for me" 。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=330
