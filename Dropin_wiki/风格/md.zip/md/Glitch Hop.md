#Glitch Hop
##基本信息
###发源时间：1997
###风格类型：Intelligent Dance Music
##详情
Glitch hop是Glitch的一个子流派。该类型典型地体现了与glitch相同的美学，但采用了更都市化的方法。Glitch
hop在1997年左右形成，它来自于早期Push Button Objects在公司Chocolate
Industries所做的工作。2001年，因为Merck Records、Warp Records和Ghostly
International等公司，该流派获得了流行。著名的glitch hop艺术家包括Machinedrum, Dabrye, Prefuse 73,
edIT, Jimmy Edgar, Lackluster和prowell。在2000年代后期，glitch
hop经历了内容创作的大幅下滑，因为该类型的从业者开始转向其他类型。在此期间，dubstep可以说是美国最赚钱的EDM类型。因此，许多glitch
hop艺术家开始制作一种新的电子音乐风格，使用与dubstep相同的美学，同时融入了glitch
hop的一些元素(低保真度操作、跳带、重复拍子、反转音调和剪切)。他们没有重新命名他们的新流派，而是沿用了glitch hop这个名字。现代的"glitch
hop"艺术家经常因为使用"glitch hop"这个词而受到批评，因为现在的这种音乐风格听起来并不像"glitch hop"或者instrumental
hip hop。尽管受到了传统glitch hop爱好者的批评，但许多glitch hop艺术家的职业都是赚钱的。比较受欢迎现代glitch
hop艺术家包括David Tipper, glitch Mob, KOAN Sound, Pegboard Nerds, Pretty Lights,
GRiZ, TheFatRat, JPEGMAFIA和Hefe Heetroc。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Glitch_(music)
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=234
