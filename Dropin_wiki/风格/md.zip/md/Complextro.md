#Complextro
##基本信息
###发源时间：2010年前后
###风格类型：Electro House
##详情
Complextro（复合电气）是由Electro House衍生的一种新的浩室舞曲风格，由Porter
Robinson等音乐人在2010年前后开创。如字面意思所示，这是一种呈现出较为"复杂花哨"听感的电子舞曲类型。Complextro融合了很多风格的元素，它以House的4/4鼓点为基础，通常会结合dubstep/brostep惯用的wobble音色，速度通常为100~128BPM，再加上一些混乱复杂的切片拼贴而形成。



Complextro的典型特征是通过快速连续地在乐器之间进行急剧切割而产生的混乱、复杂的基音和纹理。这个词是 "复杂 "和 "电子
"两个词的合成词，由Porter Robinson在2010年创造出来，用来描述他所做的音乐的声音。
他认为视频游戏的声音，或者说chiptunes，与1980年代的模拟合成音乐一起，对他的音乐风格产生了影响。其他的制作人包括Adventure Club,
Kill The Noise, Knife Party, Lazy Rich,The M Machine, Madeon, Mord Fustang,
Savant, Virtual Riot和Wolfgang Gartner。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro_house#Complextro
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=53
