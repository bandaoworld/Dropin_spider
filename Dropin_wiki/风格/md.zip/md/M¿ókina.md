#Mákina
##基本信息
###发源时间：Early 1990s
###风格类型：Happy Hardcore
##详情
Makina是hardcore techno的一个亚流派，起源于西班牙。与UK hardcore相似，它包括bouncy techno
和hardtrance的元素，tempo 从150到180 BPM不等。



**20世纪90年代初：起源**

1988年，acid
house的兴起使得西班牙的舞曲变得非常突出。Makina紧随这一趋势，起源于20世纪90年代初的西班牙瓦伦西亚。它源于另一种被称为bakalao的风格，bakalao实际上是85年后瓦伦西亚俱乐部中电子舞曲与流行、摇滚乐一起演奏的协会的名字。



**90年代中期：突破与成功**

1991年，西班牙制作人奇莫巴约（Chimo Bayo）推出了他的单曲《Asi Me Gusta A Mi（X-Ta Si，X-Ta
No）》，这一类型的音乐开始变得有名。这首歌在整个欧洲非常流行，该流派很快就有了知名度。从1995年到1997年，这一流派在整个西班牙非常流行，因为许多以玛基纳为导向的单曲在西班牙单曲排行榜上排名第一。西班牙makina团体EX-3在1995年和1996年分别推出了两首获得榜单第一的单曲"Extres"和"EX-
P-Cial"。或许美国知名度最高的makina单曲是Newton的《Streamline》，2006年由Jimmy
Fallon主演的百事可乐广告使该单曲更具传唱度。



从20世纪90年代末到2006年左右，这一流派作为主流成为了英格兰东北部和苏格兰狂欢节目。但最著名的场馆特别是New Monkey
nightclub关闭以后，它在这些地区的知名度逐渐下降，基本上被UK Bounce（也称为"Donk"或"Scouse
House"）所取代。尽管如此，它仍然保留着深厚的文化遗产。纽卡斯尔联队和桑德兰队客场比赛时，经常听到教练组在互相"问候"（注：纽卡斯尔和桑德兰是英超死对头）。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/M%C3%A1kina
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=208
