#Glitchstep
##基本信息
###发源时间：
###风格类型：Glitch Hop
##详情
Glitchstep起源于1975年左右，在2008年左右普及，是idm和Glitch-Hop的一个分支，它更侧重于步伐，broken beat和分散的
funk 节奏，这种节奏是"所有不符合hip hop节奏的跃动、不规则节奏的总称"。 第一个录制glitchstep的是giorgio
moroder的Percussiv。





###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://www.last.fm/tag/glitchstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=235
