#Brazilian Bass
##基本信息
###发源时间：2010s
###风格类型：Deep House
##详情
Brazilian Bass（巴西贝斯）是House音乐的的一种子风格，是从2010年代早期的主流deep house中演变而来，融合了来自Tech
House的元素并受到来自Bass
House的极简主义影响。该风格歌曲的节奏通常在120~125BPM，显著特色是具有极具辨识度的深沉有力的敲打感的Bassline，通常会使用降调和滤波效果的技术来实现。



Brazilian Bass是在2010年左右的巴西首都巴西利亚开创。但直到2016年，基于DJ Alok，Bruno
Martini和Sevenn等人的推广，才在国内和国际上产生了反响。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=47
