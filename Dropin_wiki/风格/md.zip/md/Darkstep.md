#Darkstep
##基本信息
###发源时间：
###风格类型：Drum and Bass
##详情
Darkstep是Drum and Bass的一种子风格，特点是快速的鼓点和暗黑氛围，其发展受到Dark
Ambient、Industrial和Hardcore音乐的影响。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Drum_and_bass#Heavy_drum_and_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=107
