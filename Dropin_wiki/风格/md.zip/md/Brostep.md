#Brostep
##基本信息
###发源时间：2011
###风格类型：Dubstep
##详情
Brostep是由Dubstep演变而来的一个电子音乐子风格，2011年前后在美国制作人Skrillex等艺术家的引领下发迹，并快速在全世界范围内流行，取得了巨大的商业成功。Brostep的出现极大丰富了Dubstep流派的大家族，成为新世纪重型电子音乐发展的重要里程碑，对21世纪10年代重型音乐和Bass
Music等新兴流派的发展和流行产生了深远影响。



**音乐特征**

Brostep深受传统英式Dubstep的影响，继承了其切分节奏的根基和标志性的Wobble
Bass，并加上花哨新颖的人声切片、啸叫等元素，最终以更加活跃疯狂的形式来表现，呈现出焕然一新的面貌。相比之下，Brostep音乐的音色，节奏，情绪，氛围都较传统Dubstep更为张扬和紧凑，给人以连续且高强度的听感刺激。



**起源**

2011年，Dubstep在美国市场获得了巨大的吸引力，凭借一种被称为Brostep的Post-dubstep风格，美国制作人Skrillex成为这一场景的
"海报男孩"（最受瞩目的旗帜人物）。2011年9月，《Spin》杂志的EDM专刊将brostep称为 "颠簸而激进
"的dubstep变体，在美国取得了商业上的成功。与传统的dubstep制作风格不同，传统的dubstep强调低音，而brostep则强调中间音域，并具有
"机械般的波动和金属式的侵略性"。根据Simon
Reynolds的说法，随着dubstep吸引了更多的听众，并从小型的俱乐部场所转移到了大型的户外活动，亚音速内容逐渐被失真的低音乐段所取代，这种即兴演奏与重金属中的电吉他大致相同。



Brostep这个词语诞生的准确源头目前尚无定论，比较流行的说法是基于这类风格是传统Dubstep的美式表达，与Dubstep之间有着兄弟般的关系，且美式英语的表达也中喜欢用"Bro"来表示兄弟，故将"Bro"和Dubstep中的"Step"结合而形成了"Brostep"的名称。Brostep这个风格名称也得到了相关制作人和艺术家们的认可和使用。



**争议**

Brostep诞生初期，大量乐迷就其与母风格Dubstep之间的关系产生了争议。Brostep源于UK
Dubstep，却也在这个框架里做出了颠覆性的改动；在商业效应上，广泛流行的Brostep又与地下低调的UK
Dubstep相冲突。这也导致了在流行市场环境下，很多新乐迷将时下流行的Brostep和Dubstep两种风格的定义画上了等号，这是导致这场争议的重要原因。



Brostep这个词在当时被一些人用来作为一种流行的美国化Dubstep风格的贬义描述。制作人Rusko在接受BBC Radio
1Xtra采访时声称："制作brostep是我的错，但现在我已经开始讨厌它的方式......。这就像有人在你脸上尖叫......你不希望这样"。根据BBC对他2012年专辑《Songs》的评论，这张唱片是Rusko试图将自己的音乐与
"Jamaican inheritance "重新调整，并与同时代制作的 "喷出的、咄咄逼人的、坚决的大男子主义
"的dubstep保持距离，这是一次的糊涂尝试。



在评论Skrillex等美国制作人的成功时，传统UK
Dubstep的代表人物Skream表示："我认为这伤害了这里（英国伦敦地区）的很多人，因为这是英国的声音，但正是有人在原声之外有影响力，才使它变得更大。不好的一面是，很多人只会说'dubstep等于Skrillex'。但说实话，我真的不介意。我喜欢他做的音乐。"



其他最初与Brostep声音相关的北美艺术家包括加拿大制作人Datsik和Excision。他们的制作风格被Mixmag描述为
"一种凶狠刺耳但又制作精良的声音，对Marilyn Manson和Nine Inch Nails的粉丝来说，比对UK
garage的爱好者来说更有吸引力"。Brostep的声音也吸引了metal bands的注意。Nu metal bands
Korn在2011年的专辑《The Path of Totality》中，与Skrillex和Excision等电子音乐制作人进行了多次合作。



**影响**

Brostep的出现是电子舞曲发展的重要里程碑，它标志着重型电子舞曲音乐开始走向大众和主流舞台。Brostep与流行乐、嘻哈音乐等主流形式进行了较好的结合，并开拓了在游戏、体育竞技、时尚等多个领域的使用场景，在商业化上作出了重要探索。



受Brostep的影响，2010年代以多类Bass Music为首的偏重型电子音乐风格得到了快速发展，包括Future Bass，Melodic
Dubstep/Bass，Riddim
Dubstep等，大批年轻有才华的艺术家涌入这些风格领域进行创作并吸引了世界各地的乐迷的关注，Dubstep系电子舞曲也成为当前电子音乐市场最为庞大且受欢迎的体系之一。Brostep的流行也为很多深居地下、小众、实验性的电子音乐类型打开了新的思路，Noise
Music、Glitch等风格受其发展轨迹的影响都应运而生了各自的变体。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Dubstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=151
