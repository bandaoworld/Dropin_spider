#Kawaii Future Bass
##基本信息
###发源时间：2015
###风格类型：Future Bass
##详情
Kawaii Future Bass (又简称 kawaii bass)，是Future
Bass的一个子流派，以其快乐可爱的音色和强烈的日本流行文化影响而闻名。通常，chiptune声音、柔和的方波、动漫或电子游戏的样本、打击乐器、门和床的吱吱声都会被融入到这类歌曲中。日本电子音乐制作人Snail's
House和其他制作人都曾制作过这一流派的曲目，前者在2015年发行了一张EP《Kirara》，后被誉为该流派的先驱。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Future_bass#Kawaii_future_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=158
