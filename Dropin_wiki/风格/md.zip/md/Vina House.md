#Vina House
##基本信息
###发源时间：2010s
###风格类型：Electro House
##详情
Vina House 是自越南发展起来的当地风格的 House 音乐。该类型速度大约为
140BPM，具有简单的节拍和较大音量的低音，通常由使用越南流行歌曲（主要是 V-Pop）的人声和旋律的混音组成。这种风格主要是用于 DJ
混音场景，这些作品通常在线分发，也可以在俱乐部现场演奏。Vina House也可以结合越南许多不同地方和情况的特色而拓展。该流派在发展过程中受到了主流
EDM 风格的影响，从最初的 Eurodance 开始，后来吸收了 Electro House、Melbourne
Bounce中非常的特点，并与邻近风格（如 Manyao）有一些共同特性。



Vina House 的根源是 1990 年代后期的 Eurodance 和 Euro House
，并由之演变而来，成为具有特色的当地场景分支，从其命名中也可以瞥见这种联系。这种流派被认为是从 DJ Hoang Trọc 和 Alan Tian
对歌曲"Tinh phai"的混音作品开创的。风格发展的一个重要节点发生在 2004 年，当时 DJ Hoang Anh 赢得了国际喜力 DJ
大赛，为这一流派带来了更多的曝光度。他也继续成为该风格中最受欢迎的 DJ，并在 2006 年创作了第一个正式发布的 vinahouse 混音作品。



2020年前后，Vina
House在中国国内通过网络短视频平台、自媒体等媒介得到广泛推广，并在俱乐部、夜店等场景受到欢迎，这也引发了国内电子音乐爱好者对相关现象的争议。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=59
