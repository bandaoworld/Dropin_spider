#Reggaestep
##基本信息
###发源时间：Late 2000s
###风格类型：Dubstep
##详情
Reggaestep是雷鬼音乐和Dubstep的融合子流派，在2010年代初在网上（特别是在SoundCloud上）开始流行。



**特点**

Reggaestep通常有类似于Reggae音乐中使用的鼓声采样，这些鼓点的节奏编排与Dubstep中典型的切分鼓点也相对应。其他来自Reggae音乐的影响包括offbeat（离拍）的加重和声，offbeat的节奏有时也会叠在更传统的Dubstep或Ragga旋律之上。曲速与典型Dubstep类似，往往在140
BPM。Reggaestep中的Drop与Dubstep中的Drop非常相似，同时多遵循与reggae相似的旋律模式。



**人气**

截至2013年，最受欢迎的Reggaestep音乐之一是美国著名电子音乐艺术家Skrillex的 "Make It Bun
Dem"，其音乐视频在YouTube上获得了超过400M的点击量，在SoundCloud上也获得了超过500万的点击量。尽管如此，这种风格相对来说并不为人所知，但在2010年代初，在SoundCloud上却相当盛行。The
Huffington Post在其关于 "Make It Bun Dem "的文章中承认Reggaestep音乐是一种音乐流派。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Reggaestep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=163
