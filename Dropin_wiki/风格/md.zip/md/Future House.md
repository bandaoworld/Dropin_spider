#Future House
##基本信息
###发源时间：2013
###风格类型：House
##详情
Future House（未来浩室）是2010年代在英国兴起的一种House音乐类型，融合了Deep House、UK
Garage，以及其他EDM类型的元素和技术。这类风格充满能量，通常由4/4节拍、着重的Drop组成并具有重低音的声音。



**起源**

"Future House"一词的创造者是一位法国DJ Tchami，他于2013年发布在SoundCLoud的重混作品《Go
Deep》是第一首被归类于此流派的作品。Tchami在使用这一术语时，并没有把"未来浩室"看作是一种流派，他在2015年的一次采访中表示："Future
House本应表示'任何一种尚未被发明的浩室音乐'，所以我没把它当成一种流派。我想人们之所以赋予它现在的含义，是因为我的音乐很特别，并且在浩室音乐与EDM间搭建了一座桥梁
----而这是个不赖的尝试。"



之后，2016年，在DJ间流行的在线音乐商店平台Beatport加入了Future House作为三个新增的音乐流派标签之一。Oliver
Heldens和Don Diablo也被认为是这一音乐流派的先驱之一。



**特征**

Future House是浩室音乐的子流派。这一流派的歌曲通常拥有柔和的旋律，包括金属的、弹性的Drop
Lead和频率调制的bassline。最常见的速度是125BPM，但也可以在120~130BPM间波动。



**人气**

2014年，Oliver Helden的《Gecko (Overdrive)》和《Last All Night
(Koala)》在世界各国的榜单中取得了成功，使Future House流派更加进入公众视野，也导致了他与Tchami在社交媒体上轻微的不和。而Don
Diablo、Mike Williams、Mesto、Brooks和Curbi在他们的作品中结合了Future
House，让一些评论者注意到这一风格的商业化。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Future_house
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=64
