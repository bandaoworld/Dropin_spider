#Electroclash
##基本信息
###发源时间：Late 1990s
###风格类型：Synthpop
##详情
Electroclash（又称synthcore、retro-electro、tech-pop、nouveau disco和new new
wave）是一种融合了1980年代electro, new wave和synth-
pop与1990年代techno、复古风格electropop和电子舞曲的音乐类型。它是由I-F、Miss Kittin和The
Hacker以及Fischerspooner等乐队首创的。



术语和特点

electroclash一词描述了一种结合了synthpop, techno, punk 和 performance
art的音乐运动。这种风格是对techno music僵化形式的反应，强调歌曲创作、表演性和幽默感，被《卫报》描述为 "近代舞曲史上最重要的两次动荡
"之一。electroclash 的视觉美学与1982年的cult film Liquid Sky.DJ
Hell被广泛认为是这一流派的发明者和命名者，而DJ和推广人Larry
Tee后来在美国普及了这一术语，以它的名字命名了2001年纽约的Electroclash音乐节。



历史作用

国际Deejay Gigolos Electroclash兴起于90年代末。由DJ Hell创立的慕尼黑厂牌International DeeJay
Gigolo Records被认为是电音的 "germ cell" 和 "THE
home"。Gigolo收录了许多早期的电音歌曲，例如1997年Christopher Just的I'm a Disco Dancer或Chris
Korda的Save the Planet, Kill
Yourself，这些歌曲原本甚至早在1993年就已发行。然后在1998年，Gigolo发行了法国录音组合Miss Kittin & The
Hacker的《1982》和《Frank
Sinatra》，这两首歌曲是新风格早期最成功的歌曲之一。随后，纽约二人组Fischerspooner的《Emerge》以及加拿大二人组Tiga &
Zyntherius对Corey Hart的《Sunglasses At Night》的重制版，都是在2001年由Gigolo发行的。DJ
Hell将新流派的艺术家们聚集在这个厂牌上，并作为他们的导师。但Hell自己发行的专辑，如1998年的《Munich
Machine》，也被认为是Electroclash流派的开山之作。在广为人知的电影纪录片25 years of electronic dance
music by European television network Arte的纪录片中，Kittin小姐描述了与DJ
Hell一起创作的第一首新风格歌曲的起源，并宣布他是Electroclash风格的发明者。由于DJ
Hell在慕尼黑的Gigolo聚集了新风格的国际艺术家，他们中的许多人在该市的夜总会进行了首次演出，因此慕尼黑被认为是 "如果不是发源地，也是重要的发展
"的城市。很快，这种新的音乐风格也传到了其他城市，如柏林、伦敦和纽约。其他早期的艺术家还有I-F在1998年由Disko B发行的歌曲 "Space
Invaders Are Smoking Grass"，其 "老式的歌词-副歌动态到爆裂的电音，在声码上向Atari时代的hi-
jinks致敬"，被认为是Electroclash风格的先锋曲目之一。另外早期的艺术家包括Chicks on
Speed、Peaches、ADULT.和Toktok vs. Soffy O与他们2000年的主打歌Missy Queen's Gonna
Die。早期，Ladytron有时会被贴上Electroclash的标签，但也有人表示他们并不完全是Electroclash，他们自己也拒绝这个标签。Goldfrapp的专辑Black
Cherry (2003)和Supernature (2005)中融入了Electroclash的元素。



影响

Felix da
Housecat的个别曲目也被描述为electroclash。在美国，当2001年10月Electroclash音乐节在纽约举行时，这个音乐流派引起了媒体的注意，"这个场景在当地取得了突破性的进展，展示了一组来自欧洲和美国的超级明星和先锋艺术家"。2002年，Electroclash音乐节再次举行，随后在2003年和2004年在美国和欧洲进行了现场巡演。其他在电音节和随后的巡演中演出的著名艺人包括
Scissor Sisters、ADULT.、Erol Alkan、Princess Superstar、Mignon、Mount
Sims、Tiga和Spalding Rockwell。



批评

在2000年代初，电音标签和围绕它的炒作受到了一些知名艺人的激烈批评。例如，I-F和其他艺术家签署了一份 "Anti-Electroclash-
Manifest"，他们抱怨那些会 "主导媒体浪潮 "的人利用这种风格，只 "卖旧情怀"。2002年，Toktok vs. Soffy
O.表示，当他们第一次被问及Electroclash时，他们只是认为。"这只不过是我们这5年来所知道的东西，而现在已经是第三次或第四次达到高峰"。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=331
