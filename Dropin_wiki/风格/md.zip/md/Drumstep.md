#Drumstep
##基本信息
###发源时间：
###风格类型：Drum and Bass
##详情
Drumstep是Drum and
Bass的一个子流派，主要特点是它的半拍节奏和受Dubstep等重型电子音乐影响的Bassline。这类风格通过突出地使用hihat节奏来保持Drum
and Bass的快速感觉。尽管在过去的几年里凭借Dubstep的成功而广受欢迎，但自从丛林乐时代以来，Drum and
Bass的半拍节奏就一直存在。Drumstep可以被比作是Jump Up Drum and Bass的一种更重的形式。



当区分Dubstep和Drumstep时，一个快速的经验法则是，Dubstep与House、Techno和Trance的节奏大致相同（约140
bpm），而Drumstep与Hip Hop的节奏和节拍结构（80-100 bpm）或明显的Drum & Bass的节奏（160-180 bpm）更为相似。

  
诸如Crissy Criss、Heist、Taxman、DJ Hazard、Rollz、Dub
Foundation和Bonkrooger等艺术家都将其融入到他们的声音中。其他艺术家如dBridge和instra:mental则制作了一种更简约的鼓点。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/drumstep
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=108
