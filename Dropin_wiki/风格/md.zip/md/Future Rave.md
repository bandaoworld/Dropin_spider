#Future Rave
##基本信息
###发源时间：2020年
###风格类型：Electro House
##详情
Future Rave是2020年前后出现和发展的电子音乐风格标签。



**历史**

法国制作人 David Guetta，丹麦制作人 MORTEN，荷兰制作人 Nicky Romero
等艺术家最早开始致力于推广这种类型，希望以复古融合创新的形式赋予对现代电子音乐和青年文化影响深远的 Rave Music
新的内容。2020年7月，Guetta与MORTEN合作发行的EP《New Rave》以及通过互联网和媒体的造势引入术语"Future
Rave"并快速推广，Guetta还获得了同年DJ Mag百大评选的冠军。



**音乐特征**

这种类型的音乐作品以 Four on the Floor 的 House
节奏为基础，通常以复古质感并带有高混响的锯齿波音色为Lead，具有空旷的空间感，并含有显著的 Electro 声音元素。



**争议**

作为一种新兴的类型，行业内对于Future Rave的理解和定义仍存在较大争议，主要围绕在Future
Rave的艺术价值，商业发展，以及是否应被称为独立的风格上。但毋庸置疑的是，在疫情笼罩的2020年里，Future
Rave是国内外电子音乐领域最受关注和讨论的话题之一。

###本词条内容来自 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=194
