#Reductionism
##基本信息
###发源时间：20世纪末
###风格类型：Ambient
##详情
Reductionism（简化主义）是20世纪末发展起来的一种即兴音乐形式。其音乐发展中心包括柏林、伦敦、东京和维也纳，该音乐的特点有微音调，扩展技术，非常柔和和安静的音效，安静，还有一些非传统的声音和音色。以伦敦为中心的Reductionism运动被称为是New
London Silence。



Reductionism有关的一些主要艺术家是Radu Malfatti,Toshimaru Nakamura, Axel Dorner和Rhodri
Davies。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Reductionism_(music)
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=246
