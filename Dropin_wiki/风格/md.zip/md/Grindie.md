#Grindie
##基本信息
###发源时间：early 2006
###风格类型：Grime
##详情
Grindie，又称Grime-indie或Grime Indie，是2006年初出现的一种音乐形式。它是独立摇滚或另类摇滚与grime音乐的融合。



**历史**

Grime制作人Statik最初将 "grindie
"这个名字作为一个玩笑，他是这个流派的主要支持者之一，也是第一个发行只包含grindie曲目的专辑的人，Grindie
Vol.1包含了60多首歌曲。Statik说他转向创造一种新的声音，因为他觉得当时的grime风格处于呆板的状态。Grindie最初受到了Grime乐迷的批评，他们认为该音乐是一种由杂志创造的时尚，而不是一个完全成熟的场景。



2004年签约Interscope唱片公司的Akira the Don发行了多张采样摇滚和独立音乐人的mixtape，包括 "Third Hand Wire
Riffs mixtape"，其中包括Elastica Big Narstie、Lethal Bizzle、The Boo Radleys的Martin
Carr等。



Jack Nimble和Marvin the Martian / Marv the Marsh创造了第一首grindie歌曲 "Stay Off The
Kane"，于2005年发行。这首歌是Art Brut的歌曲 "Emily Kane "的混音版。Art Brut后来邀请了Marvin和Jack
Nimble所在的团体Why Lout?作为他们在Koko的开场表演。2006年，他们在环球数码唱片公司发行了Hoods & Badges EP。Akira
the Don为Grime明星Big Narstie的 "What's The Story Brixton Glory
"mixtape制作了歌曲，其中有Oasis（乐队）和Arctic Monkeys的采样，后来被Ed Sheeran引用为影响。



Grime艺术家Lethal Bizzle成为了这个子流派的杰出艺术家，发布了多首由Akira the Don制作的前40名歌曲，这些歌曲采样了The
Clash、The Breeders和Sham 69，还与Statik、the Rakes、Babyshambles、Bloc Party和Test
Icicles合作。Lethal Bizzle当时由于俱乐部禁止他演出而陷入困境。Grindie让Lethal
Bizzle找到了一个新的，独立的，充满观众的平台。查理-XCX在她早期的职业生涯中被称为 "Grindie公主"。Hadouken！也与这个场景有关。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Grindie
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=130
