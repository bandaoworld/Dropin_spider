#Euro House
##基本信息
###发源时间：late 1980s
###风格类型：House
##详情
Euro House兴起于20世纪80年代末，是来自欧洲的一种Vocal House音乐风格。这种风格起源于以House音乐为背景的歌曲，受到Dance-
pop音乐的强烈影响。



Euro House在1990年代与Eurodance（以较高的BPM以及来自Techno和Hi-NRG的影响而脱颖而出）并行发展，一些Euro
House乐队（例如Cappella和The 4th Floor的2 Brothers）也致力于Eurodance或Italo Dance的发展 。



进入21世纪以来，流行的 Euro-Trance 风格对 Euro house 的影响是非常巨大，以至于这个时期的许多 Euro house
歌曲也可以，或至少在一定程度上被视为 Euro-trance 音乐。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/euro+house/wiki
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=61
