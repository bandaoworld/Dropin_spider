#Industrial Hardcore
##基本信息
###发源时间：
###风格类型：Hardcore
##详情
Industrial
Hardcore是Hardcore的一种子风格，以其不受音乐调式限制的Synth，粗暴的噪音节奏，暗黑的采样，毛刺的剪辑，失真的音效和底鼓为特色。它是一种听感十分暗黑，曲速较快的音乐类型，BPM可在140~250间。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://www.last.fm/tag/industrial+hardcore/wiki
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=209
