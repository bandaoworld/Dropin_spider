#Juke House
##基本信息
###发源时间：1990s
###风格类型：Ghetto House
##详情
Juke House是20世纪80年代末开始形成的Ghetto House的一种较快的变体。



2000年，芝加哥juke或juke house兴起，它是80年代末开始形成的Ghetto
House的一种较快的变体。芝加哥juke的歌曲一般在150-165
BPM左右，带有跳动的踢鼓，快速地敲击（有时非常稀疏），与噼里啪啦的小鼓、拍子和其他让人想起老式鼓机的声音同步。制作风格通常是明显的lo-
fi，很像baile funk。芝加哥Juke的发展是为了配合脚步舞，这种舞蹈风格诞生于芝加哥不同的贫民区、家庭聚会和地下舞蹈比赛。RP
Boo，一名前脚步舞者，一般被认为是制造了第一批属于典范的歌曲。



与juke音乐并存，"Footwork"是世界上流行的
"hood"舞音乐风格之一。与之同名的脚步舞是指双脚在高速状态下有控制的复杂移动，是现代的house舞蹈步法和霹雳舞步法。芝加哥juke和booty
house流派的制作人包括DJ Deeon、Dude 'n Nem、DJ Slugo、DJ Chip、DJ Nate、]DJ Tha Pope、DJ
Nehpets、DJ Rashad和Spinn。Teklife是一个Footwork组织。



2005年12月，DJ Gant-Man在哥伦比亚/索尼唱片公司为Beyonce的 "Check on It "与Slim
Thug的混音，成为第一个为主要歌手在主要唱片公司进行芝加哥Juke house混音的DJ/制作人，Gant-
Man也帮助发展了芝加哥Juke的声音.Missy Elliott是2005年第一个在BET的106 & Park节目中以她的歌曲 "Lose
Control "展示芝加哥舞蹈和音乐场景的艺术家。她聘请了一位来自芝加哥的女舞蹈编导为 "Lose Control
"音乐录影带做编舞。Elliott在芝加哥巡演时看电视发现了Chicago
juke。多年来，她在一些音乐活动中与芝加哥舞者同台演出，使芝加哥juke成为主流。



在欧洲，Juke在欧洲的俱乐部，特别是在巴黎、布鲁塞尔和西班牙流行了多年。英国厂牌Planet Mu的合集《Bangs and Works Volume
1》（2010）将芝加哥DJ的作品带给了更多的观众，引起了一些媒体的关注。Hyperdub厂牌一直是juke和footwork的支持者，发行了很多DJ
Rashad的作品。2013年，Deeon在法国著名的贫民区音乐厂牌 "Booty Call Records "推出了两个项目。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Ghetto_house#Chicago_juke
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=69
