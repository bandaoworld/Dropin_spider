#Schaffel
##基本信息
###发源时间：20世纪70年代
###风格类型：Techno
##详情
Schaffel（德文拼写，以配合英文 "shuffle "的发音）是一种融合了Techno和rock的风格，其中Minimal Techno的Kick
Drum编排经过shuffled后，突出了offbeat的节奏特性。Schaffel通常使用八分音符三连音来创造摇摆的节奏感。



**历史**

Schaffel起源于swing和R&B音乐，这种风格在极具魅力的摇滚艺人的作品如1971年T.Rex的 "Hot Love "和1972年Gary
Glitter的 "Rock and Roll Pt 2 "中得到了推广和喜爱



Schaffel一直在电子音乐流派中被使用，在Depeche Mode的 "Personal Jesus "等作品中也能找到。



Michael Mayer的厂牌Kompakt推出了一系列名为Schaffelfieber（"Schaffel Fever"）的合辑。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Schaffel
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=148
