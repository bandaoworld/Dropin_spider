#Snap Music
##基本信息
###发源时间：Late 1990s
###风格类型：Crunk
##详情
Snap music（又称ringtone rap或snap
rap）是嘻哈音乐的一个子流派，源于90年代末美国亚特兰大西部班克黑德的南方。它在整个2000年代中后期取得了主流的流行，但不久后就衰落了。受欢迎的snap艺术家包括D4L、Dem
Franchize Boys和K-Rab。



歌曲通常由808低音鼓、高拍、贝斯、啪啪声、一个主律动和声道。许多snap歌曲还可能加入口哨声。热门的snap歌曲包括Cherish的 "Do It to
It"、Dem Franchize Boys的 "Lean wit It, Rock wit It"、Lil Jon的 "Snap Yo
Fingers"、D4L的 "Laffy Taffy"、Yung Joc的 "It's Goin'Down "和Soulja Boy Tell 'Em的
"Crank That (Soulja Boy)"，被选为 "史上15首最佳snap音乐歌曲 "之一的是One Chance的 "Look at Her"。



Crunk被称为 "snap的前身"。Hip Hop DX杂志将snap音乐描述为 "其前身--crunk音乐的第二春"。



**历史**

据悉，snap
music在2000年左右出现在佐治亚州亚特兰大市Bankhead的一个犯罪猖獗的街区。Bankhead是一个贫富差距明显的地方，正如人们所描述的那样，"在所有的侵略事件中
"诞生了 "一种轻快的声音 "的snap music。"snap music在诞生后不久，就与亚特兰大的另一种音乐类型--
crunk音乐产生了联系。2003年，当时已经为当地俱乐部制作了一些snap歌曲的Dem Franchize
Boys被环球音乐集团签下。有人说，推广不力和环球音乐决定将Dem Franchize Boys的首张专辑和Nelly的 "Sweat and Suit
"在同一天推出，是他们第一张专辑不成功的原因。2005年，他们得到了Jermaine Dupri的关注，Jermaine Dupri对他们的单曲 "I
Think They Like Me "进行了混音，并将他们签给了So So Def。改编的 "I Think They Like Me
"在热门说唱/R&B歌曲排行榜上名列前茅，并在Billboard Hot 100中排名第15位。Jermaine Dupri后来被称为将snap
music带入主流的关键人物。另一个来自亚特兰大的团体D4L，当时与8Ball、Keyshia Cole和Slim Thug一起在亚特兰大的Vision
Nightclub and Lounge表演。2005年，他们制作的 "Laffy Taffy "占据了Billboard Hot
100排行榜的第一名。他们的首张专辑《Down for Life》获得了RIAA的金唱片认证。D4L和Dem Franchize
Boys因为谁开始创作snap music而开始竞争。正如D4L的Fabo所提到的，Dem Franchize Boys被社区成员看不起，在那里被称为
"标签妓女"。



然而，《纽约时报》指出，在亚特兰大，像T.I.和Young Jeezy这样以抒情为主的制作人比D4L这样的音乐人得到的尊重要多得多，在亚特兰大，snap
music被视为轻度的俱乐部音乐，而不是像T.I.这样的 "重度街头 "音乐，这种竞争还在继续，亚特兰大Pool Palace的驻场DJ，DJ
T-Roc声称K-Rab在Dem Franchize Boys和D4L之前很久就在制作snap。还有其他一些事实可以说明K-Rab可能是snap的最初创造者
--他制作了 "Laffy Taffy"，而且在早期的snap热门歌曲中可以听到他的声音，比如 "Do the Pool Palace "和 "Bubble
Gum"。2005年和2006年，snap music逐渐成为主流流行音乐。2006年1月12日，《纽约时报》对 "Laffy Taffy
"进行了评论。在分析这首歌的结构时，作者指出："在嘻哈的尺度上，像'Laffy Taffy'这样的傻傻的舞曲评分并不高。" 这篇评论还触及了snap
music这个更广泛的话题，结论是，各大唱片公司很难抓住这种声音，因为在作者看来，他们需要拥有比snap "更严肃 "的东西。还有人指出，snap
在数字下载系统中做得非常好，因为 "廉价 "的snap 和数字曲目的廉价成本（Laffy
Taffy99分）非常契合。2006年，还有一首用popping声代替小鼓的主打歌，登上了Billboard Hot 100的第三名，那就是Yung
Joc的《It's Goin' Down》。Billboard杂志称，不过，"It's Going Down
"的popping声，并不是小鼓的声音。Crunk制作人Lil Jon也通过发行单曲 "Snap Yo Fingers"，增加了snap
风格在主流音乐中的曝光率，该单曲在Billboard Hot 100中排名第7。2006年，《Vibe》杂志还提到了snap的子流派
"snap&B"，与Cherish专辑《Unappreciated》有关。Vibe表示，担心snap&B能否承接当时太流行的crunk&B。Vibe还指出了snap&B的一个特点，他说，与可能以snapping为特色的慢速爵士乐不同，一首歌曲也应该是
"流行 "的，才能称之为
"snap&B"。2007年，snap继续在Billboard主流榜单上保持强势。2007年底，当时年仅17岁的美国说唱歌手Soulja
Boy推出了他的主打歌《Crank That》，这首歌曲在Billboard Hot
100榜单上享受了7周的第一名，并获得了格莱美的提名，成为当年的主打歌之一，推进了snap
music在Billboard榜单上的影响力，同时也进一步深入到了crunk风格。同年，一些专门制作crunk
mixtape的网站开张，增加了该风格的曝光率。制作人T-Pain以他的snap&B主打歌 "Buy U a Drank (Shawty Snappin')
"进入Billboard Hot 100。这首歌曲也是热搜榜的第一名，并在滚石的 "2007年最佳歌曲
"榜单中名列第68位。2008年2月，亚特兰大说唱歌手V.I.C.推出了他的热门快闪单曲 "Get Silly"，这首单曲在Billboard Hot
100榜单上名列第29位，并获得了50万份的单曲销量。这种受欢迎程度甚至蔓延到了喜剧中，《The Boondocks》描绘了 "The Story of
Gangstalicious"，这位说唱歌手在剧中的热门歌曲是 "Homies Over Hoes"，这显然是对 "Laffy Taffy "的致敬。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Snap_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=283
