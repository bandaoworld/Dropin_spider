#Dark Electro
##基本信息
###发源时间：early 1990s
###风格类型：Electro-Industrial
##详情
Dark electro是Electro-industrial的变体，于上世纪90年代前期在中欧发展起来。这个术语描写的是诸如yelworC
和Placebo Effect之类的群体，并于1992年12月在yelworC的首张专辑Brainstorming发行时首次使用。这种风格的灵感来自The
Klinik和Skinny Puppy的音乐。作品包括哥特式恐怖主题，神秘主题、咕噜声或失真的人声。
yelworC是来自慕尼黑的乐队，成立于1988年。它们在1990年代初奠定了dark electro的基础，并且是德国唱片公司Celtic Circle
Productions的第一位艺术家。在随后的几年中，dark
electro被诸如aggrotech和futurepop等受techno影响的风格所取代。其他这种风格的乐队包括Das Ich, amGod,
Nurgul Jones, Trial, early Evil's Toy, Mortal Constraint, Arcana Obscura,
Splatter Squall, Seven Trees, Tri-State, GGFH (Disease)和Ice Ages。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Electro-industrial#Dark_electro
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=264
