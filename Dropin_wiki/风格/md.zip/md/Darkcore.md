#Darkcore
##基本信息
###发源时间：Early 1990s
###风格类型：Breakbeat Hardcore
##详情
Darkcore（又称darkside hardcore、darkside jungle或darkcore
jungle）是英国rave场景中breakbeat hardcore和jungle的一个音乐子流派，出现于1992年末。它被公认为是Drum and
Bass音乐流派的直接前身之一。



**起源**

到了1992年底，breakbeat
hardcore开始分化，darkcore就是其中一个出现的子流派，也是与4-beat相对应的。Darkcore的特点通常是黑暗主题的采样，如恐怖电影元素、呼救声、听起来很阴险的stabs和合成器音符，除了4-to-
the-floor beats 和低频basslines之外，还有切分音的breakbeats。此外，它还引入了诸如音调变换和时间拉伸等效果来营造气氛。



**著名作品**

值得注意的发行作品包括DJ Hype的 "Shot in the Dark"（Suburban Base，1993），Origin Unknown的
"Valley of the Shadows"（RAM Records，1993），Ed Rush的 "Bloodclot Artattack"（No U
Turn, 1993年）、Rufige Cru的 "终结者"（Reinforced Records，1992年）、Doc Scott的 "Here
Comes the Drumz"（Reinforced Records，1992年）和4hero的 "Journey from the
Light"（Reinforced Records，1993年）。其他在1993年发行 "darkside "曲目的厂牌还有Moving
Shadow和Basement Records。Basement的制作人/工程师Jack
Smooth说，Basement略微不同的darkcore风格的特点是 "4×4 kick，techno声音，丰富的的pads在重度切割的层层破音上"。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Darkcore
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=99
