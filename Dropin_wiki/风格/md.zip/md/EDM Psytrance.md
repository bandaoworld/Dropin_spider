#EDM Psytrance
##基本信息
###发源时间：2010s
###风格类型：Pop EDM
##详情
EDM
Psy是近年来的融合了主流EDM和PsyTrance的一种子类型，目前没有公认的音乐形式定义，仅作为一种乐迷和制作人评价的标签。特点是将PsyTrance的整体结构变得更加简短化，并遵循Bigroom
House的原则，时长一般在3-5分钟。有时Bass音色会采用Bigroom
House的音色，但其他部分如鼓组、节奏、和声等一般仍采用PsyTrance的标准。是主流电子音乐制作人试图将Psychedelic
Trance变得更加大众化的一种尝试。



**发展历程**

2013年，资深的PsyTrance组合Sesto Sento在成员Itai Spector离开以后重组为了Vini
Vici，并发行了多首单曲，包含了歌曲Divine Mode和Trust in a
Trance等，至2015年，大部分单曲的销量都成功排名到了电子舞曲流媒体平台Beatport的Top 100销量排名中，同年他们发行了专辑"Future
Classics"，获得了Beatport排名的第二，并受到了明星Trance制作人Armin van Buuren的关注，2016年他们发布了曲目Free
Tibet的混音版本，并与Armin van Buuren合作了曲目"Great
Spirit"。获得了数以千万的观看次数与收听量。并在之后继续与诸多明星制作人合作制作了如"100"(与Timmy Trumpet)、"The House
Of House" (与Dimitri Vegas & Like Mike) 以及 Moshi Moshi" (与Steve
Aoki)。均获得了此前PsyTrance制作人曲目未获得过的收听量与关注度，被认为是近年PsyTrance制作人的代表人物，获得了2018年DJ杂志(DJMAG)百大DJ评选的34名。



由Vini Vici与诸多明星制作人合作的新式PsyTrance音乐作品，由于明显缩减了PsyTrance标志性的氛围酝酿阶段，音色也与Bigroom
House有类同度，被许多制作人与听众称之为EDM
Psy，并引领了近年的PsyTrance主流化的趋势，扩大了PsyTrance的听众量，但也被其他流派的PsyTrance听众认为是太过商业化的无聊产物

###本词条内容来自 https://zh.wikipedia.org/wiki/迷幻出神
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=34
