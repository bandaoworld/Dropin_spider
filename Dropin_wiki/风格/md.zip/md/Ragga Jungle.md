#Ragga Jungle
##基本信息
###发源时间：20世纪90年代早期
###风格类型：Jungle
##详情
Ragga Jungle（拉贾丛林） 从Ragga音乐中衍生出来的一种Jungle/Drum and
Bass的子流派，通常以大量MC人声元素为主要特点。这种风格大约出现在1989-1990年，其主要先驱是Michael West（Rebel
MC，Congo Natty Label），以及Leenie De Ice，Ragga
Twins等。这种风格被认为是吸引黑人社区参与到Jungle音乐中来，并对英国国内的 "rude boy "亚文化做出了贡献。1995年以来，Ragga
Jungle乐在英国的受欢迎程度明显下降，部分原因是DJ开始减少这类音乐的曝光时间。Ragga
Jungle现在是一种偏小众的音乐风格，只有少数厂牌发行的音乐可以被归类为这种风格，但其主要也是对90年代记忆的重温。

###本词条内容由 @多频百科团队 编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=106
