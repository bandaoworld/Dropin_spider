#Birmingham Sound
##基本信息
###发源时间：early 1990s
###风格类型：Techno
##详情
Birmingham Sound是20世纪90年代初在英国伯明翰兴起的Techno的子流派。



Birmingham Sound的发展通常被认为与伯明翰当地的House of God俱乐部之夜、Downwards
Records厂牌以及当地的DJ和制作人Regis、Surgeon和Female有紧密的联系。它的特点是硬朗、快速和不妥协的风格，它将底特律和柏林的techno所特有的bassline
funk的音乐剥离出来，只留下 "大片的无情的不变的极简主义"。



Birmingham Sound标志着Techno发展的一个转折点，它的影响可以在柏林Techno场景的Berghain夜店和Ostgut
Ton厂牌中听到。它也构成了Regis和Female后来的Sandwell District项目的起点。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Birmingham_sound
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=138
