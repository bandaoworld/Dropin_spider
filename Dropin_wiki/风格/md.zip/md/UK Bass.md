#UK Bass
##基本信息
###发源时间：Mid-2000s
###风格类型：Dubstep
##详情
UK bass，又称bass music，是21世纪中期在英国出现的俱乐部音乐，受到House、Grime、dubstep、UK garage、R&B和UK
funky等不同流派的影响。当艺术家们开始模糊地融合这些已定义的流派的声音，同时又强调打击乐的、以贝斯为主导的节奏时，"UK bass "一词就开始使用了。



UK bass有时与bassline或post-dubstep混为一谈。它不能与hip hop和electro为基础的流派Miami
bass混为一谈，Miami bass有时也被称为 "bass music"。



**起源**

与UK Bass这个词相关的风格的广泛性使它无法成为一个特定的音乐流派。Pitchfork的作者Martin
Clark曾表示，"试图对我们所涵盖的领域进行松散定义的善意尝试是徒劳的，而且肯定是有缺陷的。这不是一个流派。然而，考虑到其中的联系、互动和自由流动的想法......你不能把所有这些行为都视为无关紧要。"
2011年9月，Dubstep制作人Skream在接受《独立报》采访时表示：



_"Dubstep。dubstep这个词被很多人使用，有很多人被贴上了dubstep的标签。他们不想被贴上标签，也不应该被贴上标签--
这不是他们所推崇的......。当我说'UK bass'的时候，每个英国人都会联想到，所以如果叫这个名字的话，会容易很多。"_



在英国，自2000年代末2010年代初以来，bass音乐取得了主流音乐的重大成功，如James
Blake、Benga、Example、Burial、Sophie Xeon、Zomby、Chase & Status、Skream、TNGHT、Ash
Bowles和Wretch 32等艺术家。post-dubstep "这个词一直被用来代指艺术家，如Blake、Mount Kimbie和Fantastic
Mr.Fox，他们的作品借鉴了UK garage, 2-step, 和其他形式的地下舞曲，以及ambient music 和早期 R&B。



在夜店之外，UK bass主要在Sub.FM和Rinse FM等网络电台上推广和播放。21世纪2010年代 2010年代末，UK
bass在美国迅速崛起。随着其他较重的流派如dubstep和trap在主流中开始衰落，西海岸贝斯先锋Bassnectar、G
Jones、Shades（由Eprom和Alix Perez组成）和CharlesTheFirst等艺术家。



UK Bass是一个宽泛的名词，指的是2009年和2010年从Dubstep和UK
Funky中产生的英国舞蹈音乐的某些风格发展。它强调Bass和Subbass，但倾向于实验结构和格式，以及bpm的变化。其他类型的影响，如Juke，Footwork，Techno，House，UK
Garage，Contemporary R&B和Wonky，经常被重新利用，并通过Dubstep和UK
Funky声音过滤。其结果是各种不同类型声音，不断延伸或打破了后一种风格的阻碍。诸如Night Slugs、Numbers.、Hessle
Audio和Swamp 81等厂牌，以及Ben UFO、Oneman和Pearson Sound等DJ，都对这种风格的流行产生了影响。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/UK_bass
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=156
