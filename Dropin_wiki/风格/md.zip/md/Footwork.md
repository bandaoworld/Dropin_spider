#Footwork
##基本信息
###发源时间：1990年代初期
###风格类型：Juke House
##详情
Footwork是90年代末起源于芝加哥的一种House舞/街舞风格。而Footwork音乐是一种从Ghetto
House衍生出来的混合电子舞曲风格，并加入了嘻哈元素，最早出现在90年代初的芝加哥。这种音乐风格是从早期的juke和Ghetto
House的快速节奏演变而来的，这种变化是由RP Boo开创的。曲目也经常采用说唱、流行音乐和其他来源的重度切分音样本，并且通常在160 bpm左右。



![](https://duopin-community.oss-cn-
shenzhen.aliyuncs.com/91oz7dmo0oi60yk3cmfb.jpg)

Footwork风格先驱RP Boo

By swimfinfan from Chicago - RP Boo @ Pitchfork, Chicago 7/16/2016, CC BY-SA
2.0, https://commons.wikimedia.org/w/index.php?curid=62363282



这种舞蹈涉及到脚步的快速移动，并伴随着扭曲和转弯，通常作为 "战斗 "的一部分。这种风格在芝加哥以外的地区流行起来，被收录到2007年Dude 'n
Nem的单曲 "Watch My Feet "的音乐视频中。



广播电台Afropop Worldwide在2011年对这一风格及其发展进行了评论。



_然而，House的最新发展是一种叫做 "footwork
"的声音。周五晚上，在地下轨道工厂，青少年们面对面地即兴表演脚步舞。他们的脚步以疯狂的速度飞舞，就像House舞、踢踏舞和霹雳舞之间的交叉。这看起来像是来自另一个空间的舞蹈。他们跳舞的音乐与juke有关，但它的空间更大，节奏更复杂。DJ
Rashad的 " Reverb"之类的曲目是彻头彻尾的实验性脉动噪音墙，会让John
Cage感到骄傲。所有这些风格都说明了一个事实，那就是House音乐从来没有像人们常说的那样，真正离开过芝加哥。它的风格继续在整个城市中回荡和变化。_



第一张国际公认的footwork音乐合集在Planet Mu厂牌上发行，分别为Bangs & Works
Vol.1和Vol.2.Vol.1的内文将这种风格描述为
"节奏感极强、抽象的舞曲，音调在160bpm左右，主要由剪接的样本和短语模板组成，这些样本和短语被扭曲成重复的节奏与形状，伴随着偏离节奏的鼓机模式和抽打的低音线"。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Footwork_(genre)
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=70
