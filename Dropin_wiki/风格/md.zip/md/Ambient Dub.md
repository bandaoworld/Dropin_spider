#Ambient Dub
##基本信息
###发源时间：1960s-1970s
###风格类型：Ambient
##详情
Ambient
Dub是Ambient与Dub（一种雷鬼音乐与电子音乐的融合风格）的融合。这个词最早是由伯明翰（Birmingham）现已停业的唱片公司"超越唱片"（Beyond
Records）于1990年代初创造的。该唱片公司发行了一系列专辑Ambient Dub Volume 1-4，启发了许多艺术家，包括Bill
Laswell，后者在他的音乐项目Divination中使用了相同的描述，在那里他与该类型的其他艺术家合作。Ambient Dub采用Tubby
King出名的Dub风格和其他1960年代至1970年代初的牙买加声音艺术家，都使用DJ启发的Ambient电子音乐，并具有所有固有的衰减，回声，均衡和迷幻的电子效果。它通常具有分层技术，并融合了世界音乐，深沉的低音线条和和声的元素。根据David
Toop的说法，"Ambient Dub就像漫长的回声延迟，随着时间的流逝而循环……将音乐序列的合理顺序变成了一片轰动的海洋。" 在Ambient
Dub风格之内著名的艺术家包括Dreadzone, Higher Intelligence Agency, The Orb, Gaudi, Ott,
Loop Guru, Woob and Transglobal Underground以及Banco de Gaia等。







###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Ambient_music#Ambient_dub
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=236
