#Neoclassical New-age
##基本信息
###发源时间：
###风格类型：New-age
##详情
Neoclassical New-age（新古典主义New-
age）音乐受到巴洛克或古典音乐的影响，并时常以其旋律和作曲方式为基础而创作。艺术家可能通过现代编排将古典风格和现代元素结合以创作出新的原创作品。这一流派中的许多艺术家多为受过古典训练的音乐家。尽管包含多样的个人风格，Neoclassical
New-age音乐通常会使用传统乐器和电子乐器来编排旋律，和声和器乐。



**特征**

Neoclassical new-age
music的风格从巴洛克/古典音乐中获得了很多灵感。这种类型的音乐主要是器乐，它大量地从古典音乐中提取元素，同时借鉴世界各地的宗教传统，给它更多的"神秘"氛围。新古典主义的新时代音乐也以其流畅和浪漫的声音为特征。



**艺术家和作曲家**

Neoclassical new-age music作曲家Chris
Field已经为多年来为许多电影预告片创造了这种音乐。其中包括《指环王》、《哈利波特与魔法石》、《爱丽丝梦游仙境》等预告片。Field还凭借专辑《潜意识》获得了2006年最佳neoclassical专辑奖。
Mannheim
Steamroller是一个非常成功的neoclassical乐队。他们的专辑销量超过4100万张，他们制作的圣诞专辑销量也达到了500万张。Mannheim
Steamroller在RIAA处已经获得了19金，8白金和4多白金荣誉。  

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自https://en.wikipedia.org/wiki/Neoclassical_new-age_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=244
