#Afroswing
##基本信息
###发源时间：Mid-2010s
###风格类型：Hip Hop Music
##详情
Afroswing主要是由它的旋律而不是特定的节奏来定义的。制作人Steel
Banglez表示，afroswing的关键元素是快乐或黑暗的和弦，"让你有一种特定的感觉"，"鼓的模式是整个声音中最重要的东西，是第三个出现的snare银。"在hip-
hop音乐中，它是第四个音。第三拍来自afrobeats。"
马丁*康纳声乐是旋律和说唱的专家，他分析描述类型的特点是"技术上在4/4拍,这是你听到的一次次的重复模式。由三个音符仍在重复4/4拍的框架，你可以从节奏中听到牙买加音乐的灵感，除了牙买加音乐没有bass
kick和snare，这些元素是属于hip hop，那是传统的rap。这就是文化的翻译在乐器中微妙地发生。但就歌词焦点和音乐视频而言，它仍具有一种hip
hop敏感性：汽车、金钱、真实性和硬度。"



**起源**

afroswing的兴起在很大程度上是由于英国人对源自非洲的声音接受缓慢。第一个真正接受非洲音乐影响并将其推向主流的流派是英国funky，通过艺术家如Donae'o，以及2010年代早期的afrobeats，艺术家如Mista
Silva, Kwamz, Fuse
ODG和Timbo通过他们的afrobeats声音获得了主流成功。大约在同一时间，Sneakbo和Timbo等艺术家将melodic
rap和加勒比元素融入他们的音乐中。这些艺术家共同为后来的afroswing奠定了基础，并推动了年轻人拥抱非洲音乐遗产。2010年，Sneakbo发行了《Touch
Ah Button》，这是dancehall和afrobeats融合的早期例子。2014年2月，Timbo和Mover发行了《Ringtone》，DJ
Kenny Allstar认为这首歌打开了"通往Afro-rap之桥和Afroswing演变的大门，这基本上是一个人在rap唱片上挂了一个钩"。
随着制作人Jae5、Blairy Hendrix、Joshua Beatz和说唱歌手J
Hus的崛起，这一风格开始脱颖而出，并不断壮大。他们融合了afrobeats、bashment和trap，以及从Road
rap衍生而来的粗犷抒情主题的旋律型rap风格。J Hus和Timbo都因开创这一流派而受到赞誉。
由于这是一种全新的类型，所以一开始对于如何称呼它存在一些困惑。这导致许多人将这一类型称为"afrobeats"，虽然它们有一些相似之处，但类型并不完全相同。同样，简单地把它与uk
rap混为一谈具有误导性，因为它虽然准确，但它忽视了流派有别于其他uk rap的独特性。Kojo
Funds明确表示，他并不试图被定义为一个afrobeats艺术家，而是将他的音乐称为afroswing。J Hus的制作人Blairy
Hendrix和Joshua
Beatz在2014年最初称他们的声音为"Traprobeats"，表明受到afrobeats和trap音乐的各种影响。与此同时，Jabz
Daniels也将自己的音乐命名为"Trapfrobeat"。 Afroswing这个名字最初是由说唱歌手Kojo
Funds创造的，同时也是由著名制作人Juls推动的。这个名字暗示着afro鼓(源自afrobeats)与R&B和dancehall鼓(在使用之间"摇摆")的混合。Afroswing最终被苹果音乐选为他们的声音的官方流派名称。而Spotify选择了AfroBashment这个词，这个词是BBC
1Xtra频道聘用的Austin Daboh创造的，融合了bashment和afrobeats风格。 2014年，J Hus在YouTube频道GRM
Daily上做了一个很受欢迎的freestyle，展示了他独特的风格。2015年，该类型的第一首著名歌曲《Dem Boy
Paigon》发布，这首歌迅速提升了J Hus的地位，成为俱乐部热门歌曲，不久之后，又迎来了一波创作类似音乐的艺术家浪潮。J Hus的声音是Ghanaian
afro-pop, afrobeats和British rap的独特融合。J
Hus的独特之处在于，他将饶舌与旋律性的歌唱结合在一起，这在当时的场景中是不常见的。2014年也出现了Mostack、Tion Wayne和Geko。
从2015年开始，许多新艺术家开始涌现，如Kojo Funds、Not3s、Don EE和ZieZie。Kojo
Funds创造了"afroswing"这个名字，并在2016年推出了热门单曲《Dun
Talkin'》。总部位于伯明翰的乐透Boyzz乐队也声名鹊起，决定将他们的声音命名为"afrobbean"，表示非洲和加勒比地区的声音融合在一起。



**成功**

这种音乐流派得到了GRM Daily、LinkUp TV和Mixtape
Madness等YouTube频道的支持，这些频道让艺术家们能够轻松地向潜在的数百万听众发布音乐视频，从而传播这种音乐流派。许多非洲裔艺术家如J
Hus、Not3s、EO和Ramz，都在排行榜上有非常成功的单曲，并凭借自己的能力成为主流艺人。Ramz的单曲《Barking》在英国单曲排行榜上排名第二，销量超过50万张。EO的单曲《German》排名第13,J
Hus的单曲《Did You See》排名第9，成为2017年流量最大的单曲。该流派的另一位主要艺术家Kojo Funds凭借与Abra
Cadabra合作的歌曲《Dun
Talkin'》获得了2017年MOBO大奖的"最佳歌曲奖"。Mostack、Not3s和Kojo基金在2017年都获得了榜单上的成功。
2015年，一个名为WSTRN的三人组合通过德雷克的OVO声音电台获得了国际关注，该电台在Beats1上播放了他们2015年的突破单曲"In2"。
2017年，J Hus发行了专辑《Common
Sense》。这张专辑获得了好评，在英国音乐排行榜上排名第10位，最终升至第6位，并在排行榜上停留了90多周。
杨在2018年发行了《勇敢者》。这首歌成为了热门歌曲，销量超过60万张，流媒体流量超过4000万次，在英国单曲排行榜上排名第13位。
2018年，WSTRN、Yxng Bane、Not3s和Hardy
Caprio等afroswing艺术家出现在德克萨斯州的SXSW音乐节上，这是该流派首次出现在音乐节上。







###本词条汉字内容由 @多频百科团队 翻译+编辑
参考链接：https://en.wikipedia.org/wiki/Afroswing
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=277
