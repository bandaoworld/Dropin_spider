#Afro House
##基本信息
###发源时间：
###风格类型：House
##详情
Afro-house是House音乐的子流派，是非洲音乐与House节拍的融合。



Afro-
house是House音乐的子流派，是非洲音乐与House节拍的混合。其主要发源自南非，融合了kwaito，Tribal，以及深沉和灵动的House音乐。它通常被归类于Deep
House或Soulful House，它有自己独特的声音，比如南非文化特色的原始打击乐声音和节奏，并反映在其音乐风格上。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Styles_of_house_music
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=37
