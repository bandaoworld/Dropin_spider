#Gqom
##基本信息
###发源时间：Early 2010s
###风格类型：Afro House
##详情
Gqom（Igqomu）是2010年代初从南非德班兴起的一种电子舞曲流派，主要由制作人DJ Lag、二人组Rudeboyz、Griffit
Vigo、Dominowe和Citizen
Boy开创，从南非的House音乐、Kwaito和Techno发展而来。与其他南非电子音乐不同的是，gqom的典型特征是极简、原始和重复的声音，重低音节拍，但没有四上八下的节奏模式。



**代表人物**

影响Gqom音乐风格国际影响力的音乐鉴赏家包括南非说唱歌手Okmalumkoolkat，意大利唱片厂牌Gqom Oh的主理人Malumz
Kole，包括音乐评论人和公共关系负责人Cherish Lala Mankai，以及唱片厂牌Afrotainment的主理人DJ Tira 和Babes
Wodumo。



**名称和特征**

gqom这个词源于isiZulu中敲击辅音的拟声词组合，意为击打鼓。它也表示为qgom，igqom，gqomu或其变体。
Gqom因其节拍而闻名，其节拍极少，原始且重复，低音沉重。它主要被描述为具有黑暗且催眠的俱乐部声音。节拍的风格没有使用其他室内音乐经常听到的四层节奏模式。典型的抒情主题包括夜生活。它通常使用一个短语或几行，在歌曲中重复多次。
Gqom是由D.I.Y.生产的年轻一代技术熟练的DJ开发的。使用FL
Studio之类的软件流行音乐，并经常在文件共享平台上自行分发音乐。从2010年代中期开始，该音乐流派在国外尤其是伦敦引起了关注。



**舞蹈动作**

Gqom音乐与许多独特的舞蹈动作相关，包括gwara gwara，vosho和bhenga。



Gwara gwara

Gwara
Gwara是通过使手臂和肘部旋转并摆动成一个圆圈来执行的，其中一条腿的动作随着手臂的节奏而运动。它与Stanky腿有些相似之处。由唱片骑师和制片人DJ
Bongz创作的舞步主要在2016年受到南非人和其他非洲人的模仿。由于编舞被著名音乐家采用，该舞步也得到了全球广泛的传播。蕾哈娜在2018年第60届格莱美奖颁奖典礼上演唱《野性的想法》时，表演了这一舞蹈动作。Childish
Gambino在他的歌曲 "This Is America "的视频中表演了这个舞蹈。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Gqom
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=39
