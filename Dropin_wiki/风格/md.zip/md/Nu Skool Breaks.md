#Nu Skool Breaks
##基本信息
###发源时间：1998~2002
###风格类型：Breakbeat
##详情
Nu skool breaks（有时也被称为nu
breaks）是起源于1998年至2002年期间的breakbeat的一个子流派。这种风格的特点通常是有更抽象、更有技术性的声音元素，有时也会融入其他类型的电子舞曲，包括UK
Garage、Electro和Drum and Bass。



**特征**

通常情况下，Nu skool breaks的节奏在每分钟125至140拍（BPM）之间，通常配有具主导性的Bassline。与Big
beat（breakbeat的另一个子流派）相比，Nu skool
breaks的声音较少由嘻哈采样和酸性声音组成，而是强调舞曲的友好性，以及使用合成器、效果处理器和计算机的现代制作技术所产生的 "新 "声音。



**起源**

"nu skool breaks "这个术语的诞生被广泛归功于Rennie Pilgrem和Adam
Freeland，他们用这个词来形容他们在1996年由Ian Williams在Bar Rumba发起的活动Friction之夜中的声音。



Uptown Connection的 "Renegades "和Boundarie Hunters的 "Double Impact
"被认为是最早正式采用这一风格的制作。



1998年，"Nu Skool Breaks "一词被用在两张合辑中，Nu Skool Breakz，Volume 1和2，由Rennie
Pilgrem混音，通过英国的Kickin Records发行。其中第一卷是在上述的伦敦俱乐部之夜Friction现场录制的。



早期发行Nu Skool Breaks的厂牌包括Botchit & Scarper、Fuel Records (UK)、Hard Hands、Marine
Parade Records、TCR和Ultimatum Breaks。



**代表艺人**

  * Aquasky
  * BLIM
  * Buckfunk 3000
  * Freq Nasty
  * Hybrid
  * Ils
  * Plump DJs
  * Stanton Warriors
  * Tipper
  * Hyper
  * Koma and Bones
  * Hexadecimal

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Nu_skool_breaks
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=102
