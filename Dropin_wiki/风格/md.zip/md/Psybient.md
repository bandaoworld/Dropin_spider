#Psybient
##基本信息
###发源时间：
###风格类型：Psychedelic Trance
##详情
Psybient（又称Psychedelic Ambient, Ambient Psy或Psychil）是一种电子音乐风格，包含psychedelic
trance、ambient, downtempo, dub, world music, new wave, ethereal wave以及IDM等元素。



Psybient一个为人熟悉的特点是它在不同时期有很多其他的名字。这个风格最早基于Ambient
House和Chillout音乐的发展形式被称为Psychill（Psychedelic Chillout, Psy Chillout），后来结合Goa
Trance和Psychedelic Trance的场景则被称为Ambient Psytrance或Ambient
Goa，而其在Dub音乐中的分支发展则被称为Psydub或Psystep。



Psybient的起源来自Goa Psytrance，艺术家以更慢的"冷却"歌曲来结束专辑。Shpongle1998年的版本Are You
Shpongled?被广泛认为是普及Psybient类型的关键专辑，虽然相关唱片在此前已经有艺术家发布。



Psybient作品的结构可以产生巨大的音景或"音乐之旅"。像Psytrance一样，它强调持续的节奏和节奏匹配。然而，为了产生有趣的音景，Psybient比它的父体裁更容易适应变化。



许多Psybient作品也包含了glith、dub及世界音乐的元素。主要是基于氛围及驰放音乐的基调，但音色更加偏向PsyTrance，整体氛围偏向舒缓地致幻。大部分Psybient还是基于电子技术进行制作，少部分会采用原声乐器及合成器进行演奏。较少有歌词，但有时会使用像Alan
Watts、Terence McKenna及Robert Anton Wilson等公众演讲家的采样[1]。



参考资料：

1. https://zh.wikipedia.org/wiki/迷幻出神

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Psychedelic_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=178
