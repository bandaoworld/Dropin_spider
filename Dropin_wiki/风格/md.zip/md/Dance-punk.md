#Dance-punk
##基本信息
###发源时间：Late 1970s
###风格类型：Dance-rock
##详情
Dance-punk （又称 disco-punk, punk-funk 或techno-punk）是20世纪70年代末兴起的一种post-punk
流派，与post-disco 和新浪潮运动密切相关。



**前辈**

post-punk时代的许多团体都采用了更适合跳舞的风格。这些乐队受到当时流行的Funk、Disco、New
Wave和其他舞曲的影响（同时也受到1970年代一些艺术家的参与，包括Sparks和Iggy Pop）。80年代有影响力的乐队包括Talking
Heads、Public Image Ltd.、New Order、Gang of Four、the Higsons、the Pop
Group、Maximum Joy、The Brainiacs、Big Boys、Minutemen和Red Hot Chili
Peppers。德国朋克歌手尼娜-哈根（Nina Hagen）在1983年以 "New York / N.Y.
"在地下舞坛大获成功，这首歌将她灼热的punk（和歌剧）歌声与disco节奏混合在一起。



**当代dance-punk**

在千禧年早期，一些garage rock/post-punk复兴的乐队中，特别是LCD Soundsystem、Clinic、Death from
Above、Liars、Franz Ferdinand、Yeah Yeah Yeahs、Bloc Party、You Say Party、the
Faint、the Rapture、Shout Out Out Out和Radio 4等乐队，还有一些以舞曲为主的乐队，他们采用了摇滚乐的声音，比如Out
Hud，或者加州的乐队，比如！！和Moving Units。在2000年早期，华盛顿特区有一个流行而显著的punk场景，灵感来自Fugazi，post-
punk，以及像Trouble Funk和Rare Essence这样的go-go表演，包括Q and Not U，Black
Eyes，以及巴尔的摩的Oxes，Double Dagger和Dope Body等乐队。在英国，indie music与Dance-
punk的结合在Klaxons的宣传中被称为新rave，而这个词也被《NME》选取并应用于包括Trash Fashion、New Young Pony
Club、Hadouken！、Late of the Pier、Test
Icicles和Shitdisco在内的乐队，形成了一个与早期rave类似的视觉美学场景。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=310
