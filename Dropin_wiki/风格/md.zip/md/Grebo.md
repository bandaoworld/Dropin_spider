#Grebo
##基本信息
###发源时间：1980s末-1990s初
###风格类型：Alternative dance
##详情
Grebo（或Grebo rock）是alternative rock的一个短暂的子流派，融合了punk rock, electronic dance
music, hip hop
和psychedelia的影响。在英国Britpop和grunge流行之前的80年代末和90年代初，这个场景已经占据了这一段时间。这个流派及其属性在很大程度上被
industrial rock所吸收， industrial rock在80年代末子流派消亡后出现，然后导致了90年代industrial
metal的发展。



历史和词源

"grebo "这个词最初是对bikers 和rock music 乐迷的一种俚语。这个词是由 "Pop Will Eat Itself
"组织重新设计的，该组织代表了20世纪80年代末和90年代初英国亚文化的一个品牌，主要是在英国中部地区。这个场景尤其以伯明翰为中心。这个场景中具有影响力的乐队有：Pop
Will Eat Itself（他们的歌曲名为 "Oh Grebo I Think I Love You "和 "Grebo Guru"），The
Wonder Stuff，Ned's Atomic Dustbin，以及伦敦乐队Carter USM和莱斯特乐队Crazyhead，The Bomb
Party，The Hunters Club，Scum Pups和Gaye Bykers on
Acid。这场运动虽然短暂，但在当时却很成功，并影响了后来的一些乐队。在一定程度上，它是音乐媒体的发明，就像 "positive punk
"一样，是英国独立杂志，特别是《NME》和《Melody Maker》所命名的场景和风格。



特征

Grebo乐队从不同的风格中吸取了影响，包括dance-rock, psychedelia,pop, hip hop, punk rock
和electronica。"Pop Will Eat Itself "采用了一种工业替代摇滚风格，结合了
"重金属和硬摇滚吉他重音、电舞节奏、采样和说唱人声。 "而Gaye Bykers on Acid对嘻哈和舞曲节拍的使用被认为是
"80年代中期alternative rock的重大创新"，而Ned的Atomic Dustbin则专注于"超朋克"，依靠
"朗朗上口的钩子和双低音的声音"。Grebo的艺术家和粉丝们都留着长发，扎着小辫子，穿着宽松的短裤。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=327
