#Budots
##基本信息
###发源时间：2009
###风格类型：Electro House
##详情
Budots是一种草根电子舞曲（EDM）流派，发源于菲律宾南部的达沃市，并最终在比萨亚语区传播。它以House音乐和土著Badjao节拍为基础，被认为是第一种
"菲律宾化 "的电子音乐，其特点是大量使用打击乐、催眠贝斯、高亢的 "tiw-ti-ti-tiw
"口哨钩子和环绕城市的有机噪音，它的产生是为了配合一种同名的自由式街舞形式。



起源

Budots是一个比萨亚语俚语，意思是 "懒汉"（塔加洛语：tambay）。 University of the Philippines
Mindanao发表的一篇本科论文表明，该俚语源于比萨亚语burot，意思是 "膨胀"，是对被称为 "rugby boys
"的吸胶少年犯的委婉说法。该刊物还称，rugby
boys跳舞的风格会被称为budots，以掩饰他们的吸毒行为。它也可以从比萨亚语tabudots中追溯出来，意思是 "一个人用不可预知的动作跳舞"。



Budots舞最终被游荡在达沃市的失业流浪汉所接受。这种风格看起来像 "虫子 "或 "布娃娃
"一样，一边扭动臀部，一边缓慢地移动手臂和腿。其特色动作之一是在低蹲时开合膝盖，手臂随意摇摆和指向。尽管是自由式的动作，但budots舞的姿势可能是受到Badjao人的启发，他们通过传统的Pangalay舞蹈或他们的本土武术，如Kuntaw和Langka
Baruwang的变化，作为街头流浪者进行表演。作家和音乐家Dominic
Zinampan声称，budots和Badjao人之间的联系仍然没有定论，因为很难说哪个影响了另一个。以前的budots舞都是用外国的电子舞曲来表演的，直到Sherwin
Calumpang Tuna，一位网吧经理，他的艺名是 "DJ Love "或 "Lablab"，他用Fruity Loops，也就是当地人所说的
"bistik"（Bisayang Tikno的缩写，"Visayan
techno"）创造了一种新的技术音乐类型，来补充这种舞蹈。他还为他的朋友们编排舞步，让他们在他的budots音乐视频中表演，这些视频自2009年2月3日起上传到他的YouTube频道。根据Vice的说法，budots舞蹈合辑视频的特点是
"Myspace时代的画面、自由奔放的舞蹈，以及'CamusBoyz'或'DJ
Love'的名字"。当地人对budots的印象是通过它与公开的性行为、帮派战争和青少年犯罪联系在一起，而DJ
Love则将自己和他的budots混音与这些困扰达沃市的问题保持距离。他的音乐视频中加入了诸如 "Yes to Dance; No to Drugs "或
"Yes to Dance; No to Riots "这样的标题。这种类型的音乐和它的创作者也成为了网络欺凌的受害者。



特征

Budots音乐的特点是衍生自电子音乐和House音乐。它的特点是140bpm的4-on-the-
floor模式，脉动的basslines，多层次的打击乐，失真和重复的人声样本，DJ填充物放在整个轨道和独特的高音调合成钩子，当地人习惯性地称为tiw
tiw。它与Eurodance也有相似之处，但没有煽情的人声、过于夸张的钢琴旋律，也没有表达情感上的脆弱，换来的是猥琐的笑话和叫嚣的派对。大多数budots的曲目并没有歌词、副歌、和弦行进等构成流行歌曲的常见元素。相反，精力充沛的节拍被黑胶划痕或花栗鼠的笑声等俗气的音效所支撑。同时，包含歌词的budots曲目是用任何一种Bisayan语言编写的。与大多数在夜总会播放的舞曲不同，budots是在篮球场等户外进行的，它还具有病毒性元素，因为它独特的重复声音和疯狂的舞蹈动作是许多菲律宾互联网meme的产生背景，如Hala
Mahulog! ("Oh no, it's about to fall!")视频和Taga-asa Ka/ Tagasaan Ka("Where are
you from?")挑战。菲律宾的音乐记者批评budots音乐缺乏形式、重复性、DIY质量和 "听起来很廉价
"的效果。相比之下，他们也承认达沃市的人们是如何重新诠释一种西方音乐类型，并根据自己的喜好进行改造的，同时也承认budots音乐的灵活性，即通过对当下任何流行歌曲的重新混音来保持自己的相关性。



流行文化中的描述

自从2008年Pinoy Big Brother: Celebrity Edition 2的冠军Ruben
Gonzaga在菲律宾主流媒体上出现后，Budots就出现在菲律宾主流媒体上，Ruben
Gonzaga在全国电视上表演了这种舞步。GMA网络的新闻杂志节目Kapuso Mo的一集，Jessica
Soho在2012年有一个关于budots的片段。为了向马尼拉市的电视观众解释一种地区性的亚文化，主持人杰西卡-
苏荷称budots舞是菲律宾与当时其他舞蹈热潮的对应物，如美国的dougie和韩国Psy的江南style中的 "马舞"，并将其描述为
"看起来像pandanggo一样的freestyle"。她还说，在某些情况下，表演者会跳 "SexBomb Girls "流行的
"spageti舞"，但他们大部分时间都是以蹲着的姿势在磨蹭，以至于被不熟悉这种风格的人认为是低俗的。



BuwanBuwan，一个菲律宾电子音乐团体，已经发布了2017年的budots音乐播放列表，作为他们对制作人的每月挑战的一部分。每首歌曲都有菲律宾总统罗德里戈-
杜特尔特（Rodrigo Duterte）的演讲节选，他是达沃市的居民。



D'Squared Cru是一个来自达沃市的街舞团体，在2018年的VIBE
PH舞蹈比赛中赢得了第二名，因为他们表演了一个以budots曲目为特色的节目，即Q-York的Budotz，Asukarap和Kiat Jud
Dai。他们为Kiat Jud Dai片段编排的舞蹈在TikTok和其他社交媒体上被多个内容创作者复制，在中国成为electric pendulum
dance，他们称之为 "电摆舞，dian bǎi wǔ"。中国名人王一博在湖南卫视《天天向上》综艺节目中跳起了《Kiat Jud
Dai》。2019年，D'Squared Cru参加了菲律宾World of Dance
Philippines第一季，也是以budot进行表演，但未能通过预选赛。随后，他们在同年飞往中国，参加深圳卫视的Dance In
Step。他们第一轮的表演以他们的病毒式budots编舞为主，给三位评委留下了深刻的印象。



纪录片

由Jay Rosas和Mark Paul Limbaga拍摄的纪录片《Budots: The Craze》探讨了这一音乐流派及其舞蹈风格，并对DJ
Love进行了采访。据达沃市太阳星报报道，这部纪录片 "提出了关于创意把关和所有权范围的问题"，因为DJ
Love的音乐在菲律宾电视网络上播放，没有适当的确认和补偿。他还声称，一名YouTuber声称拥有他的流行混音的所有权。该纪录片已于2019年在Cinemalaya菲律宾独立电影节上首映，并获得第43届Gawad
Urian奖最佳纪录片提名。



卡加延德奥罗市的一家餐厅，一旦打开迪斯科灯，服务员就会跟着budots跳舞。Lucky Me! Pancit
Canton在2019年的广告中，用budots作为其 "不排水烹饪 "方法的记忆装置。YouTub-
based音乐模仿团体Siivagunner以其诱饵式混搭和电子游戏声音曲目的混音而闻名，他们已经在几个视频中加入了budots
。Budots对流行歌曲的混音已经成为菲律宾节日、地方电台和圣诞派对的主流。它也成为一种 "不酷 "但不贬低的自我表达方式。



在菲律宾政治中的应用

在担任达沃市市长期间，Duterte在2015年两次被看到在budots上跳舞。其中一段视频中，Duterte与讲宿务语的美国人跳舞，来自Hey Joe
Show!
YouTube频道，而另一个片段则是他在一个公共公园与当地青少年跳舞。这些视频的传播可能帮助他赢得了2016年的总统选举。菲律宾迪利曼大学发表的一篇论述称，budots已经成为巩固Duterte作为一个面向大众的政治家的民粹主义姿态的工具，据称他深深地沉浸在Visayan文化中。在DJ
Love的budots舞蹈视频中发现的标题，如 "Yes to Dance/No to
Drugs"，可以被解读为支持Duterte对毒品犯罪化的强硬立场。一些菲律宾政客也试图利用budots来吸引选民，最著名的是2019年竞选参议员的Ramon
Bong Revilla
Jr.。他出现在一个全国性的电视广告上，伴随着budots音乐跳舞，批评者认为他在整个竞选过程中没有谈论任何治理计划。Revilla
赢得了第11个空缺的参议员席位（12个席位中），甚至在正式宣布后还跳了一段小舞。DJ
Love声称Revilla未经许可就使用了他的曲目，并要求普及该舞蹈编排的舞蹈团体Camus
Girls赔偿。Revilla的政治广告被列为2019年菲律宾最佳网络meme之一。Larry Faraon 在《每日论坛报》的专栏中写道，Revilla
仅靠跳budots的舞蹈就取得了胜利，这反映了菲律宾的选举文化。达沃市市长Sara Duterte-
Carpio(杜特尔特总统的女儿)对2019年东南亚运动会开幕式上菲律宾队阅兵式上使用1976年Hotdog的歌曲Manila
提出质疑。她声称这个标题是以资本为中心的，并不代表整个国家，甚至建议用budots代替，因为她的同胞Davaoeños "发明 "了它。

###本词条内容暂未完善仅供参考，多频百科小编正在火速赶来
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=374
