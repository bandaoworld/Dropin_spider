#Wartrance
##基本信息
###发源时间：2007
###风格类型：Trance
##详情
Wartrance 或 War Trance 是一种Trance音乐子流派，大约诞生于 2007 年，主要使用到来自 trance 的元素以及少量
Techno
的元素，其主要的特征是使用二战期间事件的声音和环境元素，混合阿道夫*希特勒、约瑟夫*斯大林、东条英机、约瑟夫*戈培尔、贝尼托*墨索里尼、伊奥尼斯*梅塔克萨索等领导人的声音，以及包括轰炸机、大炮、导弹发射器、武器、爆炸等的真实录音。这类音乐的主题钟往往含有明显的仇外心理、种族主义、法西斯主义和新纳粹主义元素。



尽管Wartrance风格非常多样化并且倾向于混合，其曲速范围在大约 125 到 200 BPM 之间波动，并且倾向于与其他子流派糅合，例如 Tech
trance、New Beat、Vocal trance、Digital hardcore、Hardcore techno
等。由于相关艺术家不同的创作或制作技术方式，用某种一般特性来归类Wartrance很复杂，但它仍有一些共通的主要形式，例如描绘战争或诸如大屠杀之类的悲惨事件，是这类风格探讨的最终目标，即展示如何通过战争和Trance的情绪（仇恨、骄傲、悲伤、遗憾），来打造一系列新感觉（例如欣快或宽宏大量），让听众从历史上回到事实，感受战争中Wartrance中的状态。尽管Wartrance的受欢迎程度不高，但它仍提供了无限的可能性。

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://second.wiki/wiki/wartrance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=185
