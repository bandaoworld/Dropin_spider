#Balearic Trance
##基本信息
###发源时间：1990s
###风格类型：Trance
##详情
Balearic Trance, 又称Ibiza trance，是由Balearic
beat演变而来的一种trance音乐亚流派。最早为人所知的Balearic trance作品可以追溯到1990年代，在Balearic
beat出现后的几年。



**历史**

它产生于20世纪80年代的Balearic House，并以Balearic island
Ibiza命名。不一致的是，这个风格的名字一直与trance和Balearic beat有关。



**特点**

Balearic trance与Balearic beat一样保持着 "Balearic "的音色，而Balearic
trance的特点是节奏较高，约为125 bpm至145 bpm，一般在130
bpm左右。由于以西班牙为基地，所以常从拉丁音乐中衍生出来。它主要关注氛围，使其在许多方面与dream
trance相似。"这种音乐似乎完美地捕捉到了柔和的地中海日落的情绪，也许是因为它使用了弦乐器，比如西班牙吉他和曼陀铃，以及与地中海相关的东西，比如海洋、鸟类和其他从ambient
trance中借鉴的东西。"

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Balearic_trance
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=166
