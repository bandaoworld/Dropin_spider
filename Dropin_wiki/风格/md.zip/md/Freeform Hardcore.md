#Freeform Hardcore
##基本信息
###发源时间：20世纪90年代中期
###风格类型：Hardcore
##详情
Freeform Hardcore，最初称为Trancecore，也可简称Freeform。它是Eurobeat、Happy Hardcore、UK
hardcore、Trance等风格融合衍生的电子音乐子流派。



Freeform Hardcore音乐通常为 4/4 拍，由器乐、Acid、hi-NRG和Hard Dance的声音元素组成。该流派最初是在Techno
Hardcore的音乐特征下发展起来的，然后逐渐倾向并扎根于Trance。这类音乐通常曲速极高（大于170BPM），带有Trance音乐的美学考量，会显著使用Acid音色。其与Happy
Hardcore等来源风格最显著的区别在于它的氛围通常更加暗黑，较少使用大调和弦[1]。



Freeform Hardcore在英国艺术家 Sharkey 在 Bonkers 合辑的混音中得到了显著发展。Thin 'n' Crispy、Nu
Energy Collective 和 FINRG 等唱片公司专注于这类音乐。有影响力的艺术家、品牌 Nu Energy 的总监 Kevin Energy
将所谓Freeform描述为一种精神状态；FINRG是来自芬兰的Freeform Hardcore唱片公司，其音乐的免费下载量超过
100,000。荷兰Trancecore是 psytrance、Acid和Hardcore的混合体[2]。



参考资料

1\. https://www.last.fm/tag/freeform/wiki

2\. https://fr.wikipedia.org/wiki/Freeform_hardcore

###本词条汉字内容由 @多频百科团队 翻译+编辑
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=202
