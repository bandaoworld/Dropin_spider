#Speed Garage
##基本信息
###发源时间：Early to mid-1990s
###风格类型：UK Garage
##详情
Speed garage（有时称为plus-8）是UK garage的一种子风格。



**特点**

Speed garage的特点是将纽约车库的4-to-the-
floor节奏与breakbeats相结合。Snares被放置在第2和第4个kickdrums的上方，所以与其他的鼓型有所不同。Speed
Garage的曲子有扭曲、沉重的低音，受到jungle和reggae音乐的影响。扫荡式的低音是Speed Garage的典型特征，Speed
Garage也有典型的故障分解。Speed Garage曲调有时以时间延伸的人声为特色。由于它深受jungle的影响，Speed
Garage大量使用jungle和dub的声音效果，如枪声和警报器。



**先驱**

唱片制作人、DJ和混音师Armand van Helden是Speed Garage的先驱，他在1996年对Sneaker Pimps的 "Spin
Spin Sugar "进行的Dark Garage混音将Speed Garage的风格带入了主流领域。



**著名的歌曲/混音**

以下是Speed Garage流派的一些著名的歌曲和官方混音，这些歌曲和混音不仅在Speed Garage风格中受欢迎，而且也风靡其他流派的音乐：



  * _"Spin Spin Sugar (Armand's Dark Garage Mix)" (1997) / "Digital (Armand Van Helden's Speed Garage Mix)" (1997) - Armand van Helden_
  * _"Dancing for Heaven" (1995) / "Saved My Life" (1996) - Todd Edwards_
  * _"Gunman" (1997) / "Kung-" (1997) Fu" (1998) - 187 Lockdown_
  * _"Deeper" (1997) / "God Is a DJ (Serious Danger Remix)" (1998) - Serious Danger_
  * _"Hype Funk (Dub)" (1997) - Reach & Spin _
  * _"RipGroove" (1997) - Double 99 "Vol. 1 (What You Want What You Need)" (1997) - Industry Standard_
  * _"Something Goin' On (Loop Da Loop Uptown / Downtown Mix)" (1997)- Loop Da Loop_
  * _"Superstylin'" (2001) - Groove Armada_

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://en.wikipedia.org/wiki/Speed_garage
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=132
