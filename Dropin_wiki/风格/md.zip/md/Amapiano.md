#Amapiano
##基本信息
###发源时间：Mid-2010s
###风格类型：Afro House
##详情
Amapiano是2012年在南非兴起的一种House音乐风格。Amapiano是Deep
House、Jazz和Lounge的混合体，其特点是合成器、空气感的pad和宽阔而有冲击力的basslines，并有高亢的钢琴旋律、Kwaito
basslines、低速的90年代南非House节奏和来自另一个当地House子流派Bacardi的打击乐元素。



**起源**

尽管该类型在Gauteng地区广受欢迎，但其起源却有很多歧义。
它起源于约翰内斯堡乡镇（Soweto，Alexandra，Vosloorus和Katlehong），早期由各种音乐风格组成。
由于该流派与Barcadi的相似之处，有人断言该类型始于比勒陀利亚地区的DJ Mujava，该DJ
Mujava是由比勒陀利亚出租车司机流行起来的，并且一直在争论Amapiano的起源问题.关于谁形成了这一流行流派的各种说法使其无法准确地确定其起源。



**人气**

该流派于2020年在整个非洲大陆获得了越来越高的知名度，在远离南非原产地的国家，数字流和排行榜的成功都有显著的增长。



**代表艺人**

Busiswa

Gaba Cannal

Kabza De Small

JazziDisciples

Mr JazziQ

DJ Maphorisa

Kamo Mphela

Nia Pearl

Moonchild Sanelly

Sha Sha

Samthing Soweto

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自  https://en.wikipedia.org/wiki/Amapiano
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=38
