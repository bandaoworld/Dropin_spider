#Rawstyle
##基本信息
###发源时间：2010s
###风格类型：Hardstyle
##详情
Rawstyle 是 Hardstyle 的一个相对较新的子流派。它通常结合了早期 Hardstyle 和 Hardcore 的特点，例如Reverse
Bass、较暗黑的旋律、更为不和谐的元素以及更强硬、失真的底鼓。



有一类 Rawstyle 则更像是一种独奏类型。它可以在 Warface、Dj Thera、Deetox 等艺术家的作品中听到。这种 Rawstyle
通常是用非常扭曲的Kick Drum制作的。它主要集中在"Punch（冲击）"（即Hardstyle Kick的"打击"）上，而Kick波形的尾部会比
Hardstyle 弱得多。



还有一类受 Rawstyle 影响的 Hardstyle。这类通常具有更扭曲的Kick，但它不像标准的 Rawstyle 那样专注于Punch。



Rawstyle 通常非常具有实验性，经常使用非常规的技术和方法来实现某种声音。例如，一些作品中的实验性 Rawstyle Kicks
比一些Hardcore或Hardstyle的作品要更现代、更干净。这类Kick的尾音更大，Bass Drum更湿润（在音乐后期制作处理中，常用"Dry -
Wet（干湿）"的概念表达音效使用或处理的程度），这在 Psycho Boys Club 的 Chaos Sound 中得到了证明，在他们制作的许多歌曲和
ID中都出现了类似的Kick。



**Rawstyle艺术家**

Rawstyle 领域中一些最著名的艺术家包括 Zatox、Adaro、Ran-D 和 Chain Reaction。有些艺术家并不是专门的
rawstyle 艺术家，但可能会制作 rawstyle 曲目以及另一种 hardstyle 子流派。这对于像 Headhunterz
这样的艺术家来说是正确的，他的单曲"Doomed"。



**Rawstyle厂牌**

一些最著名的 rawstyle 唱片公司包括 A² Records、Scantraxx、Theracords、Spoontech、Gearbox、Sys-X
Records、The Magic Show Records、Roughtstate、X-RAW、Anarchy、Nightbreed
Records、Loudness Recordings、End Of Line 和 Minus Is More .

###本词条汉字内容由 @多频百科团队 翻译+编辑
原文译自 https://hardstyle.fandom.com/wiki/Rawstyle
###http://dropinapp.hearinmusic.com/#/ency?typeId=13&dataId=190
